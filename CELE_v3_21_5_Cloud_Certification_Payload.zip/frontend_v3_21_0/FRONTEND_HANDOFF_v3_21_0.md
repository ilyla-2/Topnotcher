# CELE Topnotcher OS v3.21.0 — Native PDF/OCR Adapter Handoff

## Baseline

v3.21.0 continues from v3.20.0 Native Data Bridge. The browser compatibility stores and native generation/checkpoint model remain unchanged.

Frozen compiler: `CELE-PDF-COMPILER-v1.6.1`  
SHA-256: `3133e9ea5259afd12dfc8f2ba7b7cc3cdc8b4e2b089ad86bad40936e504d0ef5`

## Native document transport

`assets/js/00-native-document-transport-v3210.js` is loaded before the core application. In Tauri mode it routes document work to API v3:

- `document_adapter_status`
- `register_source_pdf`
- `render_source_pdf_page`
- `ocr_image_region`

The existing PDF intake/crop/layout/compiler code is preserved. Only the transport for source-PDF validation, exact page rendering, and OCR image recognition changes in desktop mode.

Standalone browser mode may still use `CELE_Local_PDF_OCR_Bridge_v3_21_0.ps1` through localhost. That PowerShell bridge is compatibility-only and is intentionally excluded from the Tauri payload.

## Invariants

Native document handling treats inputs as opaque bytes. It does not alter question data, trust states, domain classification, Coverage, Readiness, Study Next, analytics, engineering calculations, NSCP logic, or compiler semantics.

The clean public edition still ships with zero bundled questions/source PDFs.

## Gate state

`nativeAdapterQA` remains `pending`. The current authoring environment cannot compile or execute the Rust/Tauri/Windows adapter. Windows Cargo/Tauri build, WebView2 execution, native PDF render/OCR tests, installer tests, and crash/restart tests must be completed on the desktop builder before certification.
