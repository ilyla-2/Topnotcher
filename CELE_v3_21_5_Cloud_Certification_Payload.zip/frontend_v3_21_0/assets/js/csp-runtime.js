/* CELE Topnotcher OS v3.21.0 — strict-CSP compatibility runtime.
 * No eval/new Function. Former generated HTML event attributes are inert data attributes
 * interpreted only through an explicit action allowlist. Dynamic presentation uses CSSOM
 * rules in a same-origin external stylesheet instead of element style attributes.
 */
(()=>{
  'use strict';
  const STYLE_PROPS=new Set(["align-items", "align-self", "background", "border", "border-color", "border-radius", "color", "display", "flex-wrap", "font-family", "font-size", "font-weight", "gap", "grid-column", "height", "justify-content", "left", "line-height", "margin", "margin-bottom", "margin-left", "margin-right", "margin-top", "max-width", "min-height", "min-width", "opacity", "overflow", "padding", "position", "text-align", "text-decoration", "text-decoration-thickness", "top", "transform", "transition-duration", "white-space", "width"]);
  const dynRules=new Map(); let dynSeq=0;
  const fakeNot=':not(#csp-dyn-never-1):not(#csp-dyn-never-2):not(#csp-dyn-never-3):not(#csp-dyn-never-4):not(#csp-dyn-never-5):not(#csp-dyn-never-6)';
  function sheet(){return document.getElementById('cspRuntimeStyles')?.sheet||null}
  function propName(p){p=String(p||'').trim();if(p.startsWith('--'))return /^--[A-Za-z0-9_-]+$/.test(p)?p:'';return p.replace(/[A-Z]/g,m=>'-'+m.toLowerCase()).toLowerCase()}
  function safeValue(v){v=String(v??'').trim();if(/[{};<>]|@import|expression\s*\(|url\s*\(/i.test(v))throw new Error('Blocked unsafe dynamic style value');return v}
  function cspStyleSet(el,prop,value){
    if(!el||!el.setAttribute)return;
    const p=propName(prop); if(!p||(!p.startsWith('--')&&!STYLE_PROPS.has(p)))throw new Error('Blocked dynamic style property: '+prop);
    const v=safeValue(value);
    let id=el.getAttribute('data-csp-dyn-id'); if(!id){id='d'+(++dynSeq);el.setAttribute('data-csp-dyn-id',id)}
    const key=id+'|'+p; let rule=dynRules.get(key), sh=sheet(); if(!sh)return;
    if(!rule){const sel=`[data-csp-dyn-id="${id}"]${fakeNot}`;const idx=sh.cssRules.length;sh.insertRule(`${sel}{}`,idx);rule=sh.cssRules[idx];dynRules.set(key,rule)}
    if(v==='')rule.style.removeProperty(p); else rule.style.setProperty(p,v);
  }
  window.cspStyleSet=cspStyleSet;
  function applyDataStyle(el){
    const src=el?.getAttribute?.('data-csp-style'); if(!src)return;
    for(const decl of src.split(';')){const i=decl.indexOf(':');if(i<1)continue;const p=decl.slice(0,i).trim(),v=decl.slice(i+1).trim();if(p)cspStyleSet(el,p,v)}
  }
  function parseStringToken(t){
    const q=t[0];let out='';for(let i=1;i<t.length-1;i++){let c=t[i];if(c==='\\'&&i<t.length-1){const n=t[++i];if(n==='n')out+='\n';else if(n==='r')out+='\r';else if(n==='t')out+='\t';else out+=n}else out+=c}return out
  }
  function splitTop(src,sep){const out=[];let cur='',q='',esc=false,depth=0;for(let i=0;i<src.length;i++){const c=src[i];if(q){cur+=c;if(esc)esc=false;else if(c==='\\')esc=true;else if(c===q)q='';continue}if(c==='"'||c==="'"){q=c;cur+=c;continue}if(c==='('||c==='['||c==='{')depth++;else if(c===')'||c===']'||c==='}')depth=Math.max(0,depth-1);if(c===sep&&depth===0){out.push(cur.trim());cur='';}else cur+=c}if(cur.trim())out.push(cur.trim());return out}
  function parseArgs(src){if(!src.trim())return[];return splitTop(src,',').map(t=>{t=t.trim();if((t[0]==="'"&&t.at(-1)==="'")||(t[0]==='"'&&t.at(-1)==='"'))return parseStringToken(t);if(t==='null')return null;if(t==='true')return true;if(t==='false')return false;if(/^-?(?:\d+\.?\d*|\.\d+)$/.test(t))return Number(t);throw new Error('Blocked non-literal CSP action argument: '+t)})}
  function invokeAction(name,args){
    switch(name){
      case 'acceptAiDiagnosisV29': return acceptAiDiagnosisV29(...args);
      case 'acceptOpenAiJudgeV21': return acceptOpenAiJudgeV21(...args);
      case 'adaptiveReturnToRecommendedV211': return adaptiveReturnToRecommendedV211(...args);
      case 'askGeminiRemediationV29': return askGeminiRemediationV29(...args);
      case 'cancelAdaptiveVisualV211': return cancelAdaptiveVisualV211(...args);
      case 'closeExamResultV25': return closeExamResultV25(...args);
      case 'closeModal': return closeModal(...args);
      case 'confirmDiagnosisV29': return confirmDiagnosisV29(...args);
      case 'deleteFormula': return deleteFormula(...args);
      case 'deleteSet': return deleteSet(...args);
      case 'diagOpenItemV28': return diagOpenItemV28(...args);
      case 'discardSavedSession': return discardSavedSession(...args);
      case 'endSessionToSetup': return endSessionToSetup(...args);
      case 'exportOneSet': return exportOneSet(...args);
      case 'finalizeVisualKey': return finalizeVisualKey(...args);
      case 'finishAdaptiveVisualCycleV211': return finishAdaptiveVisualCycleV211(...args);
      case 'focusDiagnosisV212': return focusDiagnosisV212(...args);
      case 'leaveVisualUngraded': return leaveVisualUngraded(...args);
      case 'loadAdaptiveMockBlueprintV216': return loadAdaptiveMockBlueprintV216(...args);
      case 'markRepairCompleteV29': return markRepairCompleteV29(...args);
      case 'navTo': return navTo(...args);
      case 'nscpOpenSourceV350': return nscpOpenSourceV350(...args);
      case 'openDerivationReaderV27': return openDerivationReaderV27(...args);
      case 'openDerivationV23': return openDerivationV23(...args);
      case 'openImmersiveDerivationV310': return openImmersiveDerivationV310(...args);
      case 'openKeyManagerForSet': return openKeyManagerForSet(...args);
      case 'openReferenceFigureV22': return openReferenceFigureV22(...args);
      case 'openVisualSolution': return openVisualSolution(...args);
      case 'openWorkedSolutionV20': return openWorkedSolutionV20(...args);
      case 'openWorkedSourceReviewV20': return openWorkedSourceReviewV20(...args);
      case 'readerMoveV27': return readerMoveV27(...args);
      case 'renderRemediationV29': return renderRemediationV29(...args);
      case 'reopenError': return reopenError(...args);
      case 'resumeAdaptiveVisualV211': return resumeAdaptiveVisualV211(...args);
      case 'resumeExamV25': return resumeExamV25(...args);
      case 'resumeSavedSession': return resumeSavedSession(...args);
      case 'retryOne': return retryOne(...args);
      case 'retryWrongFromLast': return retryWrongFromLast(...args);
      case 'revealOpenSourceAfterAiV21': return revealOpenSourceAfterAiV21(...args);
      case 'reviewCompletedSession': return reviewCompletedSession(...args);
      case 'runAdaptiveInterventionV212': return runAdaptiveInterventionV212(...args);
      case 'runRepairActionV29': return runRepairActionV29(...args);
      case 'scheduleRetryV29': return scheduleRetryV29(...args);
      case 'selectRemediationV29': return selectRemediationV29(...args);
      case 'selfRateOpenV21': return selfRateOpenV21(...args);
      case 'startAdaptiveFollowupV211': return startAdaptiveFollowupV211(...args);
      case 'startAdaptiveVisualRepairV211': return startAdaptiveVisualRepairV211(...args);
      case 'startConceptDrillV24': return startConceptDrillV24(...args);
      case 'startDailyMissionV214': return startDailyMissionV214(...args);
      case 'startExamBlockV25': return startExamBlockV25(...args);
      case 'startLatestWrongReviewV30': return startLatestWrongReviewV30(...args);
      case 'startRehearsalBlockV25': return startRehearsalBlockV25(...args);
      case 'startRetentionDueV215': return startRetentionDueV215(...args);
      case 'studySet': return studySet(...args);
      case 'visualLabDeriveV210': return visualLabDeriveV210(...args);
      case 'visualLabFormulaV210': return visualLabFormulaV210(...args);
      case 'visualLabPracticeV210': return visualLabPracticeV210(...args);
      default: throw new Error('Blocked CSP action: '+name);
    }
  }
  function runStatement(stmt,el,event){
    stmt=stmt.trim();if(!stmt)return;
    if(stmt==='event.stopPropagation()'){event.stopPropagation();return}
    if(stmt==="this.parentElement.classList.toggle('open')"||stmt==='this.parentElement.classList.toggle("open")'){el.parentElement?.classList.toggle('open');return}
    let m=stmt.match(/^setTimeout\(\s*\(\)\s*=>\s*([A-Za-z_$][\w$]*)\((.*)\)\s*,\s*(\d+)\s*\)$/);if(m){const args=parseArgs(m[2]),delay=Number(m[3]);setTimeout(()=>invokeAction(m[1],args),delay);return}
    m=stmt.match(/^([A-Za-z_$][\w$]*)\((.*)\)$/);if(!m)throw new Error('Blocked CSP handler statement: '+stmt);invokeAction(m[1],parseArgs(m[2]));
  }
  function runHandler(code,el,event){try{for(const s of splitTop(String(code||''),';'))runStatement(s,el,event)}catch(err){console.error('[CELE CSP handler]',err,code)}}
  const boundClick=new WeakSet(),boundKey=new WeakSet();
  function bind(el){
    if(el?.hasAttribute?.('data-csp-onclick')&&!boundClick.has(el)){boundClick.add(el);el.addEventListener('click',e=>runHandler(el.getAttribute('data-csp-onclick'),el,e))}
    if(el?.hasAttribute?.('data-csp-onkeydown')&&!boundKey.has(el)){boundKey.add(el);el.addEventListener('keydown',e=>{const code=el.getAttribute('data-csp-onkeydown')||'';const m=code.match(/^if\(event\.key===((?:'[^']*')|(?:"[^"]*"))\)(.*)$/);if(m){if(e.key===parseStringToken(m[1]))runHandler(m[2],el,e)}else runHandler(code,el,e)})}
    if(el?.hasAttribute?.('data-csp-style'))applyDataStyle(el);
  }
  function scan(root){if(root?.nodeType===1)bind(root);root?.querySelectorAll?.('[data-csp-onclick],[data-csp-onkeydown],[data-csp-style]').forEach(bind)}
  new MutationObserver(ms=>{for(const m of ms){if(m.type==='childList')m.addedNodes.forEach(scan);else if(m.type==='attributes')bind(m.target)}}).observe(document,{subtree:true,childList:true,attributes:true,attributeFilter:['data-csp-style','data-csp-onclick','data-csp-onkeydown']});
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',()=>scan(document),{once:true});else scan(document);
})();
