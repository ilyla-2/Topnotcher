
function mathSlotV173(slots,html){const k=`§I${slots.length}§`;slots.push(html);return k}
function inlineMathV173(raw){return `<span class="eng-inline-math-v173">${engineeringMathHTMLV172(raw)}</span>`}
function displayMathV173(raw){return `<span class="eng-display-math-v173">${engineeringMathHTMLV172(raw)}</span>`}
function mixedEngineeringHTMLV173(raw,{allowDisplay=true}={}){
  let s=String(raw??''),slots=[];
  // Pull a differential equation out of prose when it is followed by a clause such as "given" or "where".
  if(allowDisplay){
    s=s.replace(/\b(d(?:2|\^2)?[A-Za-z]\s*\/\s*d[A-Za-z](?:2|\^2)?\s*=\s*[^,;\n.!?]{1,90})\s*,\s*((?:given|where|if|when|find|calculate|determine))\b/gi,(m,e,w)=>mathSlotV173(slots,displayMathV173(e.trim()))+w.charAt(0).toUpperCase()+w.slice(1));
    // A line that is essentially an equation may stand on its own without swallowing surrounding prose.
    s=s.replace(/(^|\n)\s*([A-Za-zγρστθεφΔ](?:_[A-Za-z0-9]+)?(?:\([^()\n]{0,20}\))?\s*=\s*[^\n,;.!?]{1,70})\s*(?=\n|$)/g,(m,p,e)=>p+mathSlotV173(slots,displayMathV173(e.trim())));
  }
  // High-confidence inline mathematical tokens only. Ordinary prose remains untouched.
  s=s.replace(/\b(?:gamma_w|gamma_sat|gamma_d|gamma|sigma|epsilon|tau|theta|phi|rho|Delta)\b/gi,m=>mathSlotV173(slots,inlineMathV173(m)));
  s=s.replace(/\b[A-Za-z]\([^\n()]{1,12}\)\s*=\s*[-+]?\d+(?:\.\d+)?\b/g,m=>mathSlotV173(slots,inlineMathV173(m)));
  s=s.replace(/\b[A-Za-z]\s*=\s*[-+]?\d+(?:\.\d+)?\b/g,m=>mathSlotV173(slots,inlineMathV173(m)));
  s=s.replace(/\b\d+(?:\.\d+)?\s*(?:kN|N|MPa|kPa|Pa)\s*\/\s*(?:m|cm|mm)[23]\b/g,m=>mathSlotV173(slots,inlineMathV173(m)));
  s=s.replace(/\b(?:x|y|z|t|L|M|V|P|Q|A|I)\^(?:-?\d+|\([^)]{1,12}\))/g,m=>mathSlotV173(slots,inlineMathV173(m)));
  let out=esc(s);
  slots.forEach((html,i)=>{out=out.replace(`§I${i}§`,html)});
  return out;
}
function applyMixedMathV173(el,allowDisplay=true){
  if(!el)return;
  const raw=el.dataset.rawTextV172||el.textContent||'';
  if(!raw.trim())return;
  el.dataset.rawTextV172=raw;
  el.innerHTML=mixedEngineeringHTMLV173(raw,{allowDisplay});
  el.dataset.engMathActiveV172='1';
  el.classList.remove('eng-math-v172');
  el.classList.add('eng-rich-v173');
}
function applyQuestionMathV173(){
  applyMixedMathV173($('#quizQuestion'),true);
  document.querySelectorAll('#quizChoices .choice>span:last-child').forEach(el=>applyMixedMathV173(el,false));
  document.querySelectorAll('#quizFeedback .worked-solution-view,#quizFeedback .muted').forEach(el=>applyMixedMathV173(el,true));
}
// Replace the v1.7.2 whole-line serif treatment while preserving the registry renderer itself.
applyQuestionMathV172=applyQuestionMathV173;
requestAnimationFrame(applyQuestionMathV173);
