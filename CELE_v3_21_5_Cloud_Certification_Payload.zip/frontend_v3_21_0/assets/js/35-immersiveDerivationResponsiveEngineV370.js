
/* v3.7.0 · Focus Mode Polish & Responsive Scene Engine
   This layer is presentation-only. It reads scene content and viewport geometry;
   it never writes CELE study evidence, mastery, readiness, errors, spacing, or calibration. */
(function(){
'use strict';
const V370={version:'3.7.0',levels:['normal','compact','dense','critical'],resizeTimer:null};
const LEVEL_CLASS={compact:'idf-fit-compact-v370',dense:'idf-fit-dense-v370',critical:'idf-fit-critical-v370'};
function words(v){return String(v||'').trim().split(/\s+/).filter(Boolean).length}
function textOf(v){return String(v||'').replace(/<[^>]*>/g,' ').replace(/\s+/g,' ').trim()}
function sceneScore(s,mobile){
  if(!s)return 0;
  const list=(s.list||[]).reduce((n,x)=>n+words(x?.b)+words(x?.t),0);
  let score=words(s.title)*1.6+words(s.body)+list+words(s.note)*.9+Math.min(55,textOf(s.eq).length/2.8);
  if(s.final)score+=11;
  if(mobile&&s.visual)score+=28;
  if((s.list||[]).length>=4)score+=12;
  return score;
}
function preferredLevel(s){
  const mobile=window.innerWidth<=850,score=sceneScore(s,mobile),h=window.innerHeight;
  let level='normal';
  if(mobile){if(score>126)level='critical';else if(score>92)level='dense';else if(score>62)level='compact'}
  else{if(score>188)level='critical';else if(score>138)level='dense';else if(score>92)level='compact'}
  if(h<700)level=V370.levels[Math.min(3,Math.max(V370.levels.indexOf(level),1)+1)];
  else if(h<780&&level==='normal')level='compact';
  return{level,score,mobile};
}
function setLevel(host,level){
  host.classList.remove(...Object.values(LEVEL_CLASS));
  if(LEVEL_CLASS[level])host.classList.add(LEVEL_CLASS[level]);
  host.dataset.fitLevel=level;
}
function markEquations(host){
  host.querySelectorAll('.idf-eq-v310').forEach(eq=>{
    eq.classList.remove('idf-eq-long-v370','idf-eq-verylong-v370','idf-eq-overflow-v370');
    const n=textOf(eq.textContent).length;
    if(n>115)eq.classList.add('idf-eq-verylong-v370');else if(n>70)eq.classList.add('idf-eq-long-v370');
    void eq.offsetWidth;
    if(eq.scrollWidth>eq.clientWidth+2)eq.classList.add('idf-eq-overflow-v370');
  });
}
function overflowState(host,main){
  const hr=host.getBoundingClientRect(),mr=main.getBoundingClientRect();
  const eq=[...host.querySelectorAll('.idf-eq-v310')];
  return{
    vertical:hr.bottom>mr.bottom+2||hr.top<mr.top-2||host.scrollHeight>main.clientHeight+3,
    horizontal:hr.right>mr.right+2||hr.left<mr.left-2||host.scrollWidth>main.clientWidth+3,
    equation:eq.some(x=>x.scrollWidth>x.clientWidth+3)
  };
}
function fitCurrent(){
  const box=document.getElementById('immersiveDerivationV310'),host=document.getElementById('idfSceneV310'),main=document.getElementById('idfAdvanceSurfaceV310');
  if(!box?.classList.contains('open')||!host||!main||typeof IDF_V310==='undefined'||!IDF_V310.scenes?.length)return null;
  const s=IDF_V310.scenes[Math.max(0,Math.min(IDF_V310.index,IDF_V310.scenes.length-1))],pref=preferredLevel(s);
  main.classList.remove('idf-scroll-fallback-v370');
  const start=Math.max(0,V370.levels.indexOf(pref.level));
  let result=null;
  for(let i=start;i<V370.levels.length;i++){
    const level=V370.levels[i];setLevel(host,level);markEquations(host);void host.offsetHeight;
    const o=overflowState(host,main);result={level,...o};
    if(!o.vertical&&!o.horizontal&&!o.equation)break;
  }
  if(result&&(result.vertical||result.horizontal)){
    main.classList.add('idf-scroll-fallback-v370');
    result.fallback=true;
  }else if(result)result.fallback=false;
  host.dataset.densityScore=String(Math.round(pref.score));
  host.dataset.fitStatus=result?.fallback?'scroll-fallback':'fit';
  box.dataset.fitStatus=host.dataset.fitStatus;
  box.dataset.fitLevel=result?.level||pref.level;
  return{formulaId:IDF_V310.formulaId,index:IDF_V310.index,score:pref.score,...result};
}
function scheduleFit(){requestAnimationFrame(()=>requestAnimationFrame(fitCurrent))}
function auditSceneModel(scene,width=1440,height=900){
  const mobile=width<=850,score=sceneScore(scene,mobile);
  let level=mobile?(score>126?'critical':score>92?'dense':score>62?'compact':'normal'):(score>188?'critical':score>138?'dense':score>92?'compact':'normal');
  if(height<700)level=V370.levels[Math.min(3,Math.max(V370.levels.indexOf(level),1)+1)];
  else if(height<780&&level==='normal')level='compact';
  return{score:Math.round(score),level,eqChars:textOf(scene?.eq).length,titleWords:words(scene?.title),bodyWords:words(scene?.body),listItems:(scene?.list||[]).length,hasVisual:!!scene?.visual};
}
function auditAllModels(width=1440,height=900){
  const out=[];
  for(const f of ((typeof state!=='undefined'&&state.formulas)||[])){
    let scenes=[];try{scenes=(typeof buildImmersiveScenesV310==='function'?buildImmersiveScenesV310(f):[])||[]}catch(e){out.push({formulaId:f.id,error:String(e)});continue}
    scenes.forEach((s,i)=>out.push({formulaId:f.id,formula:f.name||f.topic,index:i+1,total:scenes.length,...auditSceneModel(s,width,height)}));
  }
  return out;
}
function install(){
  if(typeof renderImmersiveDerivationV310!=='function')return setTimeout(install,60);
  if(window.__idfV370Installed)return;window.__idfV370Installed=true;
  const base=renderImmersiveDerivationV310;
  renderImmersiveDerivationV310=function(){const r=base.apply(this,arguments);scheduleFit();return r};
  window.renderImmersiveDerivationV310=renderImmersiveDerivationV310;
  window.addEventListener('resize',()=>{clearTimeout(V370.resizeTimer);V370.resizeTimer=setTimeout(scheduleFit,90)},{passive:true});
  document.addEventListener('fullscreenchange',scheduleFit,{passive:true});
  window.idfFitCurrentV370=fitCurrent;
  window.idfAuditSceneModelV370=auditSceneModel;
  window.idfAuditAllModelsV370=auditAllModels;
  window.V370=V370;
}
install();
})();

