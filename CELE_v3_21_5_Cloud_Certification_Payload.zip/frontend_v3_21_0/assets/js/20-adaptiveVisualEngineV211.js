
// ---------------- v2.11.0 · ADAPTIVE VISUAL REMEDIATION ----------------
// Guardrail: this layer recommends a visual only when local evidence is strong enough.
// It never changes answer keys, grades, mastery, or Error Bank resolution by itself.
const ADAPTIVE_VISUAL_V211={schema:1,saveTimer:null};
const ADAPTIVE_VISUAL_RULES_V211={
 'hydrostatic':{category:'HGE',phrases:['hydrostatic pressure','pressure at depth','pressure force','center of pressure','vertical gate','rectangular gate','fluid pressure','pressure triangle']},
 'buoyancy':{category:'HGE',phrases:['buoyancy','buoyant force','archimedes','floating block','floats freely','submerged volume','displaced volume','specific gravity','floatation','flotation']},
 'bernoulli':{category:'HGE',phrases:['bernoulli','energy grade line','hydraulic grade line','egl','hgl','velocity head','pressure head','head loss','venturi','energy equation','pipe energy']},
 'effective-stress':{category:'HGE',phrases:['effective stress','pore pressure','pore water pressure','water table','soil stress','total vertical stress','terzaghi stress']},
 'seepage':{category:'HGE',phrases:['seepage','hydraulic gradient','darcy law','darcy flow','hydraulic conductivity','permeability','flow net','seepage discharge']},
 'metacentric':{category:'HGE',phrases:['metacentric','metacenter','metacentre','metacentric height','floating stability','heel angle','restoring moment','unstable floating']},
 'inclined-hydro':{category:'HGE',phrases:['inclined gate','inclined surface','inclined plane surface','submerged plane','inclined hydrostatic','plane surface hydrostatic']},
 'sfd-bmd':{category:'PSAD',phrases:['shear force diagram','bending moment diagram','sfd','bmd','maximum moment','point load beam','uniformly distributed load','udl beam','beam reaction']},
 'mohr-circle':{category:'PSAD',phrases:["mohr's circle",'mohr circle','principal stress','principal stresses','plane stress','maximum in-plane shear','stress transformation','normal stress transformation']},
 'euler-buckling':{category:'PSAD',phrases:['euler buckling','buckling load','critical load','slenderness ratio','effective length','column buckling','euler load']},
 'truss-force':{category:'PSAD',phrases:['truss','method of joints','method of sections','member force','tension member','compression member','pin jointed']},
 'beam-deflection':{category:'PSAD',phrases:['beam deflection','elastic curve','slope and deflection','midspan deflection','double integration beam','deflection of beam']},
 'flexure':{category:'PSAD',phrases:['flexure formula','bending stress','normal stress in beam','section modulus','neutral axis','moment of inertia bending','beam flexure']},
 'torsion':{category:'PSAD',phrases:['torsion','shaft torsion','angle of twist','polar moment','torsional shear','circular shaft','torque shaft']},
 'simple-curve':{category:'MSTE',phrases:['simple circular curve','circular curve','horizontal curve','pc station','pt station','tangent length','external distance','middle ordinate','degree of curve']},
 'vertical-curve':{category:'MSTE',phrases:['vertical curve','crest curve','sag curve','grade intersection','g1','g2','pvi','high point','low point']},
 'leveling':{category:'MSTE',phrases:['differential leveling','leveling','levelling','backsight','foresight','height of instrument','elevation difference','reduced level']},
 'vector-resultant':{category:'MSTE',phrases:['vector resultant','resultant vector','vector components','x component','y component','force components','bearing components']},
 'integral-area':{category:'MSTE',phrases:['definite integral','integration','area under curve','area under the curve','integral area','midpoint rule','riemann']},
 'derivative':{category:'MSTE',phrases:['derivative','tangent slope','instantaneous slope','differentiation','rate of change','dy/dx','maximum minimum calculus']}
};
const ADAPTIVE_CHALLENGES_V211={
 'hydrostatic':'Change depth and width. Verify that pressure grows linearly with depth while resultant force grows with both area and centroid depth.',
 'buoyancy':'Change specific gravity and volume. Watch which variable changes percent submerged and which changes the absolute displaced volume.',
 'bernoulli':'Change velocity and head loss. Track how the gap between EGL and HGL follows velocity head while losses reduce total head.',
 'effective-stress':'Move the water table and target depth. Compare how total stress, pore pressure, and effective stress respond below the water table.',
 'seepage':'Change head difference and seepage length. Confirm that hydraulic gradient is driven by Δh/L before changing permeability.',
 'metacentric':'Change beam and KG. Find one stable and one unstable configuration and note what happens to GM.',
 'inclined-hydro':'Change inclination and centroid depth. Watch resultant magnitude and center-of-pressure location separately.',
 'sfd-bmd':'Change the point load and UDL. Identify which changes create SFD jumps and how the BMD peak moves.',
 'mohr-circle':'Change σx and τxy. Watch the circle center and radius respond differently and locate σ₁, σ₂, and τmax.',
 'euler-buckling':'Change effective length and section size. Compare their effect on slenderness and the critical buckling load.',
 'truss-force':'Change load and geometry. Watch which members remain in tension or compression and verify reaction symmetry when geometry is symmetric.',
 'beam-deflection':'Change span and section inertia. Notice the strong span sensitivity compared with the inverse dependence on EI.',
 'flexure':'Change moment and section depth. Compare how σ = Mc/I responds when depth changes the section inertia.',
 'torsion':'Change torque and diameter. Compare shear stress and angle of twist; diameter has a strong fourth-power effect through J.',
 'simple-curve':'Change radius and intersection angle. Watch tangent length, curve length, and PT station respond.',
 'vertical-curve':'Change entering and exiting grades. Create a crest and a sag case and observe whether the extremum lies inside the curve.',
 'leveling':'Change backsight and foresight. Check the sign of Δelevation and the resulting elevation of the next point.',
 'vector-resultant':'Change magnitude and direction of both vectors. Create reinforcement, cancellation, and a quadrant change.',
 'integral-area':'Change coefficient and reverse the integration bounds. Compare geometric shading with the signed definite integral.',
 'derivative':'Move x₀ and change the quadratic coefficient. Watch the tangent rotate as the instantaneous slope changes.'
};
function ensureAdaptiveVisualStateV211(){
 state.adaptiveVisualV211=state.adaptiveVisualV211||{schema:1,active:null,history:[]};
 state.adaptiveVisualV211.history=Array.isArray(state.adaptiveVisualV211.history)?state.adaptiveVisualV211.history:[];
 return state.adaptiveVisualV211;
}
function adaptiveSaveSoonV211(){clearTimeout(ADAPTIVE_VISUAL_V211.saveTimer);ADAPTIVE_VISUAL_V211.saveTimer=setTimeout(()=>save(),180)}
function adaptiveQuestionHayV211(q){return [q?.subject,q?.topic,q?.question,q?.explanation,q?.solutionText,q?.source].filter(Boolean).join(' ').toLowerCase().replace(/\s+/g,' ')}
function adaptiveFormulaMatchV211(q){
 if(!q||!Array.isArray(state.formulas)||typeof rankFormulaV22!=='function')return null;
 const ranked=state.formulas.map(f=>({f,s:rankFormulaV22(f,q)})).sort((a,b)=>b.s-a.s);
 const top=ranked[0];if(!top||top.s<13)return null;
 const mod=typeof visualModuleForFormulaV210==='function'?visualModuleForFormulaV210(top.f.id):null;
 return mod?{mod,formula:top.f,score:top.s}:null;
}
function adaptiveVisualRecommendationV211(q){
 if(!q||!['MSTE','HGE','PSAD'].includes(q.category))return null;
 const fm=adaptiveFormulaMatchV211(q),hay=adaptiveQuestionHayV211(q),topic=String(q.topic||'').toLowerCase(),subject=String(q.subject||'').toLowerCase();let best=null,second=null;
 for(const [id,rule] of Object.entries(ADAPTIVE_VISUAL_RULES_V211)){
  if(rule.category!==q.category)continue;let score=0,hits=[];
  for(const phrase of rule.phrases){const p=phrase.toLowerCase();if(!hay.includes(p))continue;const words=p.split(/\s+/).length;let w=4+Math.min(5,words*2);if(topic.includes(p))w+=5;if(subject.includes(p))w+=3;score+=w;hits.push(phrase)}
  const mod=visualModuleV210(id);if(!mod)continue;const row={module:mod,score,hits};if(!best||score>best.score){second=best;best=row}else if(!second||score>second.score)second=row;
 }
 const uniqueTopic=!!(best&&best.score>=10&&!(second&&second.score>0&&best.score-second.score<3));
 // A highly specific cue (e.g. "inclined gate") may distinguish two modules that share
 // the same governing formula. Prefer that specific native model over a generic formula link.
 if(uniqueTopic&&(best.score>=18||best.hits.length>=2)&&(!fm||best.module.id!==fm.mod.id))return{module:best.module,confidence:'HIGH',score:best.score,reason:`Specific topic cues · ${best.hits.slice(0,3).join(', ')}`,formulaId:null,method:'topic'};
 if(fm)return{module:fm.mod,confidence:'HIGH',score:100+fm.score,reason:`Verified formula match · ${fm.formula.name||fm.formula.topic||fm.formula.id}`,formulaId:fm.formula.id,method:'formula'};
 if(!uniqueTopic)return null;
 const confidence=best.score>=18?'HIGH':'MEDIUM';
 return{module:best.module,confidence,score:best.score,reason:`Topic cues · ${best.hits.slice(0,3).join(', ')}`,formulaId:null,method:'topic'};
}
function adaptiveMappedErrorsV211(){return Object.values(state.errors||{}).filter(e=>!e.resolved).map(e=>{const q=allQuestions().find(x=>x.id===e.questionId);if(!q)return null;const rec=adaptiveVisualRecommendationV211(q);return rec?{e,q,rec}:null}).filter(Boolean)}
function adaptiveCommitCurrentErrorCaptureV211(qid){
 if(!session||session.qs?.[session.index]?.id!==qid)return;const last=session.answers?.at(-1);if(last?.id!==qid||last.correct!==false)return;const e=state.errors?.[qid];if(!e)return;
 const t=session.selectedErrorType||'UNCLASSIFIED';e.types=e.types||{};e.types[t]=(e.types[t]||0)+1;const note=$('#errorNote')?.value?.trim();if(note){e.notes=e.notes||[];e.notes.push({at:Date.now(),text:note})}save();
}
function startAdaptiveVisualRepairV211(qid,source='error-bank'){
 const q=allQuestions().find(x=>x.id===qid);if(!q)return alert('Question not found.');const rec=adaptiveVisualRecommendationV211(q);if(!rec)return alert('No sufficiently reliable native visual match was found for this question.');
 if(session){adaptiveCommitCurrentErrorCaptureV211(qid);pauseAndSave()}
 const st=ensureAdaptiveVisualStateV211(),mod=rec.module,need=Math.min(2,Math.max(1,mod.controls?.length||1));
 st.active={id:uid('AVR'),questionId:q.id,moduleId:mod.id,source,startedAt:Date.now(),stage:'explore',changedKeys:[],interactions:0,requiredKeys:need,reason:rec.reason,confidence:rec.confidence,formulaId:rec.formulaId||null,followupQuestionId:null,followupAttempts:[],archived:false};
 ensureVisualLabStateV210();state.visualLabV210.selected=mod.id;state.visualLabV210.visits[mod.id]=(state.visualLabV210.visits[mod.id]||0)+1;VISUAL_LAB_V210.selected=mod.id;save();navTo('visuallab');
}
function adaptiveReturnToRecommendedV211(){const a=ensureAdaptiveVisualStateV211().active;if(!a)return;state.visualLabV210.selected=a.moduleId;VISUAL_LAB_V210.selected=a.moduleId;save();renderVisualLabV210()}
function cancelAdaptiveVisualV211(){const st=ensureAdaptiveVisualStateV211(),a=st.active;if(!a)return;if(!confirm('End this adaptive visual repair cycle? Your normal Error Bank data will remain unchanged.'))return;archiveAdaptiveVisualV211('cancelled');st.active=null;save();renderVisualLabV210()}
function archiveAdaptiveVisualV211(status){const st=ensureAdaptiveVisualStateV211(),a=st.active;if(!a||a.archived)return;a.status=status;a.endedAt=Date.now();a.archived=true;st.history.push(JSON.parse(JSON.stringify(a)));if(st.history.length>100)st.history=st.history.slice(-100)}
function adaptiveTrackControlV211(id,key){const a=ensureAdaptiveVisualStateV211().active;if(!a||a.moduleId!==id||!['explore','failed-explore'].includes(a.stage))return;a.interactions=(a.interactions||0)+1;a.changedKeys=Array.isArray(a.changedKeys)?a.changedKeys:[];if(!a.changedKeys.includes(key))a.changedKeys.push(key);if(a.changedKeys.length>=a.requiredKeys)a.stage='ready';adaptiveSaveSoonV211();renderAdaptiveVisualPanelV211()}
function adaptiveFollowupCandidateV211(a){
 const origin=allQuestions().find(x=>x.id===a.questionId),mod=visualModuleV210(a.moduleId);if(!origin||!mod)return null;
 const rows=[];for(const q of allQuestions()){
  if(q.id===origin.id||q.category!==origin.category||q.kind==='worked-problem'||q.kind==='term-card'||q.kind==='term'||!isAutoGradableKeyV100(q))continue;
  const r=adaptiveVisualRecommendationV211(q);if(!r||r.module.id!==a.moduleId)continue;let s=100+r.score; if(String(q.topic||'').toLowerCase()===String(origin.topic||'').toLowerCase())s+=28;if(String(q.subject||'').toLowerCase()===String(origin.subject||'').toLowerCase())s+=12;const p=getProgress(q.id);if(!(p.attempts||0))s+=14;else s+=Math.max(0,8-(p.attempts||0));if(state.errors?.[q.id]&&!state.errors[q.id].resolved)s-=4;rows.push({q,s});
 }
 rows.sort((x,y)=>y.s-x.s||String(x.q.id).localeCompare(String(y.q.id)));if(rows[0])return{q:rows[0].q,fallback:false};
 return isAutoGradableKeyV100(origin)?{q:origin,fallback:true}:null;
}
function startAdaptiveFollowupV211(){
 const st=ensureAdaptiveVisualStateV211(),a=st.active;if(!a)return;if(a.changedKeys.length<a.requiredKeys)return alert(`Change at least ${a.requiredKeys} different model variables first.`);const hit=adaptiveFollowupCandidateV211(a);if(!hit)return alert('No keyed follow-up problem from this concept family is currently available.');
 if(session)pauseAndSave();a.followupQuestionId=hit.q.id;a.followupFallback=!!hit.fallback;a.stage='followup';a.followupStartedAt=Date.now();save();navTo('study');if($('#studyMode'))$('#studyMode').value='learn';if($('#studyOrder'))$('#studyOrder').value='original';if($('#studySize'))$('#studySize').value='all';$('#studySetup')?.classList.add('hidden');startStudy([hit.q]);if(session){session.setTitle=`Adaptive transfer · ${visualModuleV210(a.moduleId)?.title||'Visual repair'}`;session.adaptiveVisualV211={cycleId:a.id,originQuestionId:a.questionId,moduleId:a.moduleId};autosaveSession('adaptive-followup')}
}
function completeAdaptiveFollowupV211(correct,skipped=false){
 const st=ensureAdaptiveVisualStateV211(),a=st.active;if(!a||a.stage!=='followup')return;const q=allQuestions().find(x=>x.id===a.followupQuestionId);a.followupAttempts=a.followupAttempts||[];a.followupAttempts.push({questionId:a.followupQuestionId,at:Date.now(),correct:!!correct,skipped:!!skipped});
 if(correct){a.stage='complete';a.completedAt=Date.now();archiveAdaptiveVisualV211('passed')}else{a.stage='failed';a.failedAt=Date.now()}save();
 const box=$('#quizFeedback');if(box){box.insertAdjacentHTML('beforeend',correct?`<div class="av-result-v211 good"><b>Adaptive transfer check passed.</b><br>The normal answer recorder supplied the mastery/Error Bank evidence; the visual layer added no extra credit. <button class="btn small" data-csp-style-id="s070" data-csp-onclick="finishAdaptiveVisualCycleV211()">Finish repair cycle</button></div>`:`<div class="av-result-v211 bad"><b>Transfer check not yet secure.</b><br>Return to <b>${esc(visualModuleV210(a.moduleId)?.title||'the visual')}</b>, change another relationship, then try another targeted check. <button class="btn small" data-csp-style-id="s070" data-csp-onclick="resumeAdaptiveVisualV211()">Return to visual</button></div>`)}
}
function resumeAdaptiveVisualV211(){const st=ensureAdaptiveVisualStateV211(),a=st.active;if(!a)return;if(session)pauseAndSave();a.stage='failed-explore';a.changedKeys=[];a.requiredKeys=1;a.followupQuestionId=null;save();state.visualLabV210.selected=a.moduleId;VISUAL_LAB_V210.selected=a.moduleId;navTo('visuallab')}
function finishAdaptiveVisualCycleV211(){const st=ensureAdaptiveVisualStateV211();if(st.active&&!st.active.archived)archiveAdaptiveVisualV211(st.active.stage==='complete'?'passed':'closed');st.active=null;save();if($('#view-visuallab')?.classList.contains('active'))renderVisualLabV210()}
function adaptiveInlineMissV211(q){
 if(!q||session?.mode==='mock')return;const rec=adaptiveVisualRecommendationV211(q),box=$('#quizFeedback');if(!rec||!box||box.querySelector('.av-inline-v211'))return;box.insertAdjacentHTML('beforeend',`<div class="av-inline-v211"><b>Suggested visual repair · ${esc(rec.module.title)}</b><div class="tiny">${esc(rec.reason)} · ${rec.confidence.toLowerCase()}-confidence local match. Opening it pauses and autosaves this study session.</div><div class="av-actions-v211"><button class="btn small primary" data-csp-onclick="startAdaptiveVisualRepairV211('${q.id}','miss-feedback')">Open visual repair</button><button class="btn small" data-csp-onclick="navTo('remediation');setTimeout(()=>renderRemediationV29('${q.id}'),0)">Open remediation</button></div></div>`)}
function adaptiveVisualStepsV211(a){const explore=['ready','followup','complete'].includes(a.stage)||a.changedKeys.length>=a.requiredKeys,follow=['complete'].includes(a.stage)||a.followupAttempts?.length;return`<div class="av-flow-v211"><span class="av-step-v211 done">1 · Miss identified</span><span class="av-step-v211 ${explore?'done':'active'}">2 · Explore visual</span><span class="av-step-v211 ${a.stage==='followup'?'active':follow?'done':''}">3 · Transfer problem</span><span class="av-step-v211 ${a.stage==='complete'?'done':''}">4 · Evidence recorded</span></div>`}
function renderAdaptiveVisualPanelV211(){
 const host=$('#visualLabV210');if(!host)return;host.querySelectorAll('.av-card-v211[data-adaptive-panel]').forEach(x=>x.remove());const st=ensureAdaptiveVisualStateV211(),a=st.active;
 let html='';if(a){const q=allQuestions().find(x=>x.id===a.questionId),mod=visualModuleV210(a.moduleId),selected=VISUAL_LAB_V210.selected,atRecommended=selected===a.moduleId,changed=a.changedKeys?.length||0,need=a.requiredKeys||2,pct=Math.min(100,Math.round(100*changed/Math.max(1,need))),ready=changed>=need;
  html=`<div class="av-card-v211" data-adaptive-panel="1"><div class="av-head-v211"><div><div class="tiny">ADAPTIVE VISUAL REPAIR · v2.11.0</div><h3>${esc(mod?.title||'Visual repair')}</h3><p>${esc(a.reason||'Mapped from the missed question.')}. This visual recommendation is advisory; normal graded attempts remain the only source of correctness/mastery evidence.</p></div><span class="av-match-v211 ${String(a.confidence||'MEDIUM').toLowerCase()}">${esc(a.confidence||'MEDIUM')} MATCH</span></div>${adaptiveVisualStepsV211(a)}${q?`<div class="av-question-v211"><b>Repairing:</b> ${esc(String(q.question||'').slice(0,260))}<div class="tiny" data-csp-style-id="s064">${esc(q.category)} · ${esc(q.subject||'')} · ${esc(q.topic||'')}</div></div>`:''}${atRecommended?`<div class="av-challenge-v211"><b>Manipulation task:</b> ${esc(ADAPTIVE_CHALLENGES_V211[a.moduleId]||'Change two variables and explain what physically changed before retrying a problem.')}</div><div class="av-progress-v211"><span data-csp-style="width:${pct}%"></span></div><div class="tiny" data-csp-style-id="s028">Distinct variables changed: <b>${changed}/${need}</b>${a.stage==='failed-explore'?' · one new relationship is required after the failed transfer check':''}</div><div class="av-actions-v211"><button class="btn small primary" data-csp-onclick="startAdaptiveFollowupV211()" ${ready?'':'disabled'}>${a.followupAttempts?.length?'Try another transfer problem':'Start targeted follow-up'}</button><button class="btn small" data-csp-onclick="cancelAdaptiveVisualV211()">End cycle</button></div>`:`<div class="av-challenge-v211"><b>Repair paused:</b> this cycle is mapped to ${esc(mod?.title||a.moduleId)}, but another module is currently open.</div><div class="av-actions-v211"><button class="btn small primary" data-csp-onclick="adaptiveReturnToRecommendedV211()">Return to recommended visual</button><button class="btn small" data-csp-onclick="cancelAdaptiveVisualV211()">End cycle</button></div>`}</div>`;
 }else{const rows=adaptiveMappedErrorsV211().sort((x,y)=>(y.e.misses||0)-(x.e.misses||0)||((y.e.lastMiss||0)-(x.e.lastMiss||0))).slice(0,3);if(rows.length)html=`<div class="av-card-v211" data-adaptive-panel="1"><div class="av-head-v211"><div><div class="tiny">ADAPTIVE REPAIR QUEUE · v2.11.0</div><h3>Turn a mistake into a visual transfer check</h3><p>${adaptiveMappedErrorsV211().length} unresolved Error Bank item${adaptiveMappedErrorsV211().length===1?'':'s'} currently have a sufficiently reliable native visual match. Weak or ambiguous matches are intentionally omitted.</p></div><span class="av-match-v211 high">LOCAL · DETERMINISTIC</span></div><div class="av-queue-v211">${rows.map(({e,q,rec})=>`<div class="av-queue-row-v211"><div><b>${esc(rec.module.title)}</b><div class="tiny">${esc(String(q.question||'').slice(0,150))} · ${e.misses||0} miss${(e.misses||0)===1?'':'es'} · ${esc(rec.reason)}</div></div><button class="btn small" data-csp-onclick="startAdaptiveVisualRepairV211('${q.id}','visual-queue')">Repair visually</button></div>`).join('')}</div></div>`}
 if(html)host.insertAdjacentHTML('afterbegin',html)
}
function renderErrorsAdaptiveV211(){
 const es=Object.values(state.errors),active=es.filter(e=>!e.resolved),due=active.filter(e=>e.nextRetry<=Date.now()),misses=es.reduce((s,e)=>s+e.misses,0),mapped=active.filter(e=>{const q=allQuestions().find(x=>x.id===e.questionId);return q&&adaptiveVisualRecommendationV211(q)}).length;
 $('#errorMetrics').innerHTML=[['Active errors',active.length],['Due now',due.length],['Visual mapped',mapped],['Total misses',misses],['Resolved',es.filter(e=>e.resolved).length]].map(([l,k])=>`<div class="card metric"><div class="k">${k}</div><div class="l">${l}</div></div>`).join('');let rows=es.slice();const f=$('#errorFilter').value;if(f==='due')rows=rows.filter(e=>!e.resolved&&e.nextRetry<=Date.now());if(f==='unresolved')rows=rows.filter(e=>!e.resolved);rows.sort((a,b)=>(a.resolved-b.resolved)||b.lastMiss-a.lastMiss);
 $('#errorTable').innerHTML=rows.length?`<div class="tablewrap"><table><thead><tr><th>Question</th><th>Misses</th><th>Why</th><th>Suggested visual</th><th>Retry streak</th><th>Status</th><th>Action</th></tr></thead><tbody>${rows.map(e=>{const q=allQuestions().find(x=>x.id===e.questionId);if(!q)return'';const types=Object.entries(e.types||{}).sort((a,b)=>b[1]-a[1]).map(([k,v])=>`${k}×${v}`).join(', ')||'Unclassified',rec=adaptiveVisualRecommendationV211(q);return`<tr><td><b>${esc(q.question).slice(0,150)}</b><div class="tiny">${q.category} · ${esc(q.topic)}</div></td><td>${e.misses}</td><td>${esc(types)}</td><td class="av-error-cell-v211">${rec?`<b>${esc(rec.module.title)}</b><div class="tiny">${esc(rec.confidence)} · ${esc(rec.method==='formula'?'verified formula link':'topic-cue match')}</div>`:'<span class="tiny">No reliable native match</span>'}</td><td>${e.retryCorrect||0}/3</td><td>${e.resolved?'Resolved':(e.nextRetry<=Date.now()?'Due':'Scheduled')}</td><td><button class="btn small" data-csp-onclick="retryOne('${q.id}')">Retry</button> ${rec?`<button class="btn small primary" data-csp-onclick="startAdaptiveVisualRepairV211('${q.id}','error-bank')">Visual repair</button>`:''} ${e.resolved?`<button class="btn small" data-csp-onclick="reopenError('${q.id}')">Reopen</button>`:''}</td></tr>`}).join('')}</tbody></table></div>`:'<div class="empty">Your Error Bank is empty.</div>'
}
function injectAdaptiveRemediationV211(qid){const host=$('#remediationWorkbenchV29');if(!host||!qid)return;host.querySelectorAll('.av-remed-v211').forEach(x=>x.remove());const q=allQuestions().find(x=>x.id===qid),rec=adaptiveVisualRecommendationV211(q);if(!rec)return;host.insertAdjacentHTML('beforeend',`<div class="av-remed-v211"><b>Native visual repair · ${esc(rec.module.title)}</b><div class="tiny" data-csp-style-id="s064">${esc(rec.reason)} · ${esc(rec.confidence)} match. Explore the mechanics before the scheduled retry.</div><div class="av-actions-v211"><button class="btn small primary" data-csp-onclick="startAdaptiveVisualRepairV211('${q.id}','remediation')">Open adaptive visual</button></div></div>`)}
function wireAdaptiveVisualV211(){
 ensureAdaptiveVisualStateV211();
 // Wrap Visual Lab rendering so the adaptive layer survives every native SVG re-render.
 if(typeof renderVisualLabV210==='function'&&!renderVisualLabV210.__adaptiveV211){const base=renderVisualLabV210;renderVisualLabV210=function(){base();renderAdaptiveVisualPanelV211()};renderVisualLabV210.__adaptiveV211=true;window.renderVisualLabV210=renderVisualLabV210}
 if(typeof visualLabControlV210==='function'&&!visualLabControlV210.__adaptiveV211){const base=visualLabControlV210;visualLabControlV210=function(id,key,value){base(id,key,value);adaptiveTrackControlV211(id,key)};visualLabControlV210.__adaptiveV211=true;window.visualLabControlV210=visualLabControlV210}
 if(typeof answerChoice==='function'&&!answerChoice.__adaptiveV211){const base=answerChoice;answerChoice=function(renderIndex){const q=session?.qs?.[session.index],mode=session?.mode;base(renderIndex);const last=session?.answers?.at(-1),a=ensureAdaptiveVisualStateV211().active;if(mode!=='mock'&&q&&last?.id===q.id&&last.correct===false){if(a?.stage==='followup'&&a.followupQuestionId===q.id)completeAdaptiveFollowupV211(false);else adaptiveInlineMissV211(q)}else if(mode!=='mock'&&q&&last?.id===q.id&&last.correct===true&&a?.stage==='followup'&&a.followupQuestionId===q.id)completeAdaptiveFollowupV211(true)};answerChoice.__adaptiveV211=true;window.answerChoice=answerChoice}
 if(typeof finalizeVisualKey==='function'&&!finalizeVisualKey.__adaptiveV211){const base=finalizeVisualKey;finalizeVisualKey=function(correctIndex){const q=session?.qs?.[session.index];base(correctIndex);const last=session?.answers?.at(-1),a=ensureAdaptiveVisualStateV211().active;if(q&&last?.id===q.id&&last.correct===false){if(a?.stage==='followup'&&a.followupQuestionId===q.id)completeAdaptiveFollowupV211(false);else adaptiveInlineMissV211(q)}else if(q&&last?.id===q.id&&last.correct===true&&a?.stage==='followup'&&a.followupQuestionId===q.id)completeAdaptiveFollowupV211(true)};finalizeVisualKey.__adaptiveV211=true;window.finalizeVisualKey=finalizeVisualKey}
 if(typeof nextQuestion==='function'&&!nextQuestion.__adaptiveV211){const base=nextQuestion;nextQuestion=function(){const q=session?.qs?.[session.index],wasAnswered=!!session?.answeredCurrent,a=ensureAdaptiveVisualStateV211().active,follow=!!(a?.stage==='followup'&&q?.id===a.followupQuestionId);base();if(follow&&!wasAnswered)completeAdaptiveFollowupV211(false,true)};nextQuestion.__adaptiveV211=true;window.nextQuestion=nextQuestion}
 renderErrors=renderErrorsAdaptiveV211;window.renderErrors=renderErrors;
 if(typeof renderRemediationWorkbenchV29==='function'&&!renderRemediationWorkbenchV29.__adaptiveV211){const base=renderRemediationWorkbenchV29;renderRemediationWorkbenchV29=function(qid){base(qid);injectAdaptiveRemediationV211(qid)};renderRemediationWorkbenchV29.__adaptiveV211=true;window.renderRemediationWorkbenchV29=renderRemediationWorkbenchV29}
 if($('#view-visuallab')?.classList.contains('active'))renderVisualLabV210();
}
window.startAdaptiveVisualRepairV211=startAdaptiveVisualRepairV211;window.startAdaptiveFollowupV211=startAdaptiveFollowupV211;window.resumeAdaptiveVisualV211=resumeAdaptiveVisualV211;window.finishAdaptiveVisualCycleV211=finishAdaptiveVisualCycleV211;window.cancelAdaptiveVisualV211=cancelAdaptiveVisualV211;window.adaptiveReturnToRecommendedV211=adaptiveReturnToRecommendedV211;window.adaptiveVisualRecommendationV211=adaptiveVisualRecommendationV211;window.renderAdaptiveVisualPanelV211=renderAdaptiveVisualPanelV211;
setTimeout(wireAdaptiveVisualV211,0);
