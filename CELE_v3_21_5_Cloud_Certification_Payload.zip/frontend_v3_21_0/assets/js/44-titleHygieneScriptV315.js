
/* v3.13.5 · Title Hygiene & Layout Polish
   Shortens UI headings only. Functional labels, formulas, question text, and stored data are untouched. */
(function(){
'use strict';
const MAP=new Map([
 ['One screen for the next decision','Command Center'],
 ['Topnotcher Command Center','Command Center'],
 ['Adaptive Mock Generator','Adaptive Mock'],
 ['Today’s Adaptive Queue','Adaptive Queue'],
 ['Learn each CELE topic through the tools it actually needs.','CELE Learning Bridge'],
 ['Run today’s evidence-built mission','Run Today’s Mission'],
 ['Today’s configured workload is complete','Daily Target Complete'],
 ['Clear due retention before adding fresh material','Clear Due Reviews'],
 ['Maintain breadth and spaced recall','Maintain Coverage'],
 ['Protect the configured rest day','Rest Day Protected'],
 ['Refresh exam-mode evidence','Refresh Mock Evidence'],
 ['Answer-Key & Deferred Grading','Answer Keys'],
 ['Smart Import Pipeline','Smart Import'],
 ['Continue import review','Resume Import'],
 ['PDF Intake Center','PDF Intake'],
 ['Scanned PDF / OCR lab','OCR Lab'],
 ['OCR review workbench','OCR Review'],
 ['Build a diagnostic mock from the evidence you already have','Diagnostic Mock Builder'],
 ['Generated blueprint history','Blueprint History'],
 ['Resume an autosaved session','Resume Session'],
 ['Build a study session','Study Session'],
 ['CELE Exam Simulation','Exam Simulation'],
 ['CELE Board Simulation','Board Simulation'],
 ['Mistake Remediation Engine','Mistake Repair'],
 ['Recurring failure modes','Failure Patterns'],
 ['Review Simulation Lab','Review Simulator'],
 ['CELE Study Blueprint & Coverage Map','Coverage Map'],
 ['CELE Study Readiness','Study Readiness'],
 ['Mock Exam Analytics','Mock Analytics'],
 ['Latest completed mock','Latest Mock'],
 ['Change vs prior mocks','Mock Trend'],
 ['Latest mock · category breakdown','Category Breakdown'],
 ['Time-management matrix','Time Management'],
 ['Post-mock review priorities','Review Priorities'],
 ['Long-Term Progress Intelligence','Progress Intelligence'],
 ['MSTE / HGE / PSAD evidence','Section Evidence'],
 ['Longitudinal snapshot','Progress Snapshot'],
 ['Exam rehearsal history','Exam Rehearsals'],
 ['Evidence-based observations','Evidence Notes'],
 ['Official-scope coverage, not just bank-topic coverage','CELE Syllabus Coverage'],
 ['Question-bank mapping audit','Bank Mapping'],
 ['Planning implications','Study Implications'],
 ['Today’s Daily Mission','Daily Mission'],
 ['Mission composition','Mission Mix'],
 ['Retention & Spacing','Retention'],
 ['Adaptive review schedule','Review Schedule'],
 ['Observed forgetting signals','Forgetting Signals'],
 ['Weekly CELE Planner','Weekly Planner'],
 ['Availability & daily targets','Daily Targets'],
 ['CELE Preparation Gaps','Preparation Gaps'],
 ['Largest open preparation gaps','Largest Gaps'],
 ['Gap audit by blueprint topic','Blueprint Gap Audit'],
 ['Gemini Answer-Key Engine','Gemini Answer Keys'],
 ['2 · Choose a keyless problem set','2 · Choose a problem set'],
 ['Import CELE Terms Trainer progress','Import Terms Progress'],
 ['Understand the code provisions your RCD and Steel modules actually use.','NSCP Code Guide'],
 ['Formula Library & Engineering References','Formula Library'],
 ['Settings & Setup','Settings'],
 ['Weekly study defaults','Study Defaults'],
 ['Setup & onboarding','Onboarding'],
 ['About this installation','Installation'],
 ['Reliability & Source Audit','Reliability Audit'],
 ['Golden-corpus guardrails','Corpus Guardrails'],
 ['Items requiring attention','Needs Attention'],
 ['Future-student framework','Student Framework'],
 ['Measure the bank before interpreting the student','Bank Coverage Audit'],
 ['Turn a mistake into a visual transfer check','Visual Repair'],
 ['Understand it → apply the code → design it → prove it.','Concept → Code → Design → Proof'],
 ['Start with the code decision, not the finished equation.','Code Decision Explorer'],
 ['Design the member. Watch the governing check emerge.','Structural Design Lab'],
 ['Continuous Beam & One-Way Slab Coefficient Explorer','Beam Coefficient Explorer'],
 ['Board Simulation Debrief','Exam Debrief']
]);
function normalize(s){return String(s||'').replace(/\s+/g,' ').trim()}
function polishTitles(root=document){
 root.querySelectorAll?.('h2,h3,h4,h5').forEach(el=>{
   const k=normalize(el.textContent),v=MAP.get(k);
   if(v&&k!==v){el.textContent=v;el.classList.add('title-short-v315');el.dataset.titleBeforeV315=k;}
 });
 root.querySelectorAll?.('#view-bank .section-title').forEach(st=>{
   const keyTitle=st.querySelector('h3');
   if(keyTitle&&normalize(keyTitle.textContent)==='Answer Keys'){
     const t=st.querySelector('.tiny');
     if(t&&normalize(t.textContent)==='Worked solutions are optional')t.textContent='Deferred grading when keys arrive later · worked solutions optional';
   }
 });
 const coverage=root.querySelector?.('#view-coverage .section-title h3');
 if(coverage&&normalize(coverage.textContent)==='Coverage Map'){
   const t=coverage.closest('.section-title')?.querySelector('.tiny');
   if(t&&t.textContent.includes('bank-derived exposure control'))t.textContent='CELE study blueprint · bank-derived exposure control';
 }
}
function compactContexts(){
 try{
  if(typeof CONTEXT_V15==='object'){
   if(CONTEXT_V15.adaptivemock)CONTEXT_V15.adaptivemock.title='Build a diagnostic mock';
   if(CONTEXT_V15.nscp)CONTEXT_V15.nscp.title='Use the NSCP Code Guide';
   if(CONTEXT_V15.bridge)CONTEXT_V15.bridge.title='Follow the Learning Bridge';
   if(CONTEXT_V15.bankaudit)CONTEXT_V15.bankaudit.title='Audit bank coverage';
  }
 }catch(e){}
}
function version315(){
 document.body.classList.add('title-hygiene-v315');
 document.title='CELE Topnotcher OS 3.13.5 · Engineering Studio';
 try{
   const old=document.querySelector('.release-current-v314');if(old)old.remove();
   const sidefoot=document.querySelector('.sidefoot');
   if(sidefoot&&!sidefoot.querySelector('.release-current-v315')){
     const r=document.createElement('div');r.className='release-row release-current-v315';
     r.innerHTML='<span class="release-dot"></span><span>v3.13.5 · Title Polish</span>';
     const first=sidefoot.querySelector('.release-row');if(first)sidefoot.insertBefore(r,first);else sidefoot.append(r);
   }
   document.querySelectorAll('#view-settings .settings-kv-v20 b').forEach(b=>{if(/^3\.13\.[1-4]$/.test(b.textContent.trim()))b.textContent='3.13.5'});
   const sh=document.querySelector('#view-settings .settings-hero-v20 .tiny');if(sh)sh.textContent='CELE TOPNOTCHER OS 3.13.5';
 }catch(e){}
}
version315();compactContexts();polishTitles();
setTimeout(version315,300);setTimeout(version315,1200);
let queued=false;
const obs=new MutationObserver(muts=>{
 if(queued)return;
 if(!muts.some(m=>m.addedNodes?.length))return;
 queued=true;requestAnimationFrame(()=>{queued=false;polishTitles();compactContexts();});
});
obs.observe(document.body,{childList:true,subtree:true});
window.polishTitlesV315=()=>polishTitles();
})();

