
(function(){
'use strict';
function sync317(){
  document.body.classList.add('visual-qa-v317');
  document.title='CELE Topnotcher OS 3.14.2 · Engineering Studio';
  try{
    document.querySelectorAll('.release-current-v316,.release-current-v315,.release-current-v314').forEach(x=>x.remove());
    const sidefoot=document.querySelector('.sidefoot');
    if(false&&sidefoot&&!sidefoot.querySelector('.release-current-v317')){
      const r=document.createElement('div');r.className='release-row release-current-v317';
      r.innerHTML='<span class="release-dot"></span><span>v3.13.7 · Autonomous Visual QA</span>';
      const first=sidefoot.querySelector('.release-row');if(first)sidefoot.insertBefore(r,first);else sidefoot.append(r);
    }
    const current=typeof APP_VERSION==='string'?APP_VERSION:'3.14.1';
    document.querySelectorAll('#view-settings .settings-kv-v20 b').forEach(b=>{if(/^3\.\d+\.\d+$/.test(b.textContent.trim()))b.textContent=current});
    const sh=document.querySelector('#view-settings .settings-hero-v20 .tiny');if(sh)sh.textContent=`CELE TOPNOTCHER OS ${current}`;
    document.querySelectorAll('.sdl-tabs-v390 button').forEach(b=>{if(!b.title)b.title=(b.textContent||'').replace(/\s+/g,' ').trim()});
    const rt=document.querySelector('#readinessTableV29 .tablewrap');if(rt){rt.setAttribute('role','region');rt.setAttribute('aria-label','Readiness blueprint table');rt.setAttribute('tabindex','0')}
  }catch(e){}
}
sync317();setTimeout(sync317,250);setTimeout(sync317,1100);setTimeout(sync317,2200);
const titleNode=document.querySelector('title');if(titleNode){new MutationObserver(()=>{if(document.title!=='CELE Topnotcher OS 3.21.0 · Native PDF/OCR Adapter')document.title='CELE Topnotcher OS 3.21.0 · Native PDF/OCR Adapter'}).observe(titleNode,{childList:true,subtree:true,characterData:true})}
let q=false;new MutationObserver(m=>{if(q||!m.some(x=>x.addedNodes?.length))return;q=true;requestAnimationFrame(()=>{q=false;sync317()})}).observe(document.body,{childList:true,subtree:true});
window.applyVisualQAV317=sync317;
})();
