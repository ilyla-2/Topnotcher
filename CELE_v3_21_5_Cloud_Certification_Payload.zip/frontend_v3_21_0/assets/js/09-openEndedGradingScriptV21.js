
// ---------------- v2.1 · WORKED / OPEN-ENDED GRADING ENGINE ----------------
// Deterministic quantity grading comes first. Gemini is optional and provisional.
const OPEN_GRADE_V21={schema:1,aiConfidenceMin:.75};
const UNIT_TABLE_V21={
  'm':{d:'L1',f:1},'cm':{d:'L1',f:.01},'mm':{d:'L1',f:.001},'km':{d:'L1',f:1000},'in':{d:'L1',f:.0254},'ft':{d:'L1',f:.3048},'yd':{d:'L1',f:.9144},
  'm2':{d:'L2',f:1},'cm2':{d:'L2',f:1e-4},'mm2':{d:'L2',f:1e-6},'ft2':{d:'L2',f:.09290304},'in2':{d:'L2',f:.00064516},
  'm3':{d:'L3',f:1},'cm3':{d:'L3',f:1e-6},'mm3':{d:'L3',f:1e-9},'ft3':{d:'L3',f:.028316846592},'in3':{d:'L3',f:1.6387064e-5},'l':{d:'L3',f:.001},'ml':{d:'L3',f:1e-6},
  'n':{d:'F',f:1},'kn':{d:'F',f:1000},'mn':{d:'F',f:1e6},'lbf':{d:'F',f:4.4482216152605},
  'pa':{d:'P',f:1},'kpa':{d:'P',f:1000},'mpa':{d:'P',f:1e6},'gpa':{d:'P',f:1e9},'psi':{d:'P',f:6894.757293168},
  'kg':{d:'M',f:1},'g':{d:'M',f:.001},
  's':{d:'T',f:1},'sec':{d:'T',f:1},'min':{d:'T',f:60},'h':{d:'T',f:3600},'hr':{d:'T',f:3600},
  'm/s':{d:'V',f:1},'km/h':{d:'V',f:1/3.6},'ft/s':{d:'V',f:.3048},
  'n*m':{d:'MOM',f:1},'kn*m':{d:'MOM',f:1000},'n-m':{d:'MOM',f:1},'kn-m':{d:'MOM',f:1000},
  'kg/m3':{d:'DENS',f:1},'g/cm3':{d:'DENS',f:1000},
  'n/m3':{d:'UW',f:1},'kn/m3':{d:'UW',f:1000},
  '%':{d:'PCT',f:.01},'deg':{d:'ANG',f:Math.PI/180},'rad':{d:'ANG',f:1}
};
function normalizeUnitV21(s=''){
  let u=String(s).trim().toLowerCase().replace(/[²]/g,'2').replace(/[³]/g,'3').replace(/\^/g,'').replace(/[·⋅×]/g,'*').replace(/\s+/g,'');
  u=u.replace(/°/g,'deg').replace(/liters?|litres?/g,'l').replace(/seconds?/g,'s').replace(/minutes?/g,'min').replace(/hours?/g,'h').replace(/meters?/g,'m').replace(/metres?/g,'m');
  u=u.replace(/kilonewtons?/g,'kn').replace(/newtons?/g,'n').replace(/kilopascals?/g,'kpa').replace(/megapascals?/g,'mpa').replace(/pascals?/g,'pa');
  u=u.replace(/cubicmeters?|cubicmetres?/g,'m3').replace(/squaremeters?|squaremetres?/g,'m2');
  return u.replace(/[.,;:)]+$/,'');
}
const UNIT_KEYS_V21=Object.keys(UNIT_TABLE_V21).sort((a,b)=>b.length-a.length);
function unitFromTailV21(tail=''){
  let raw=String(tail).trim().replace(/^[:=~≈\s]+/,'');
  if(!raw)return {raw:'',key:'',info:null};
  const compact=normalizeUnitV21(raw);
  for(const k of UNIT_KEYS_V21){if(compact.startsWith(k))return {raw:raw.slice(0,Math.max(1,raw.length)),key:k,info:UNIT_TABLE_V21[k]}}
  return {raw:'',key:'',info:null};
}
function prepQuantityTextV21(s=''){
  return String(s).replace(/[−–—]/g,'-').replace(/,/g,'').replace(/([0-9.]+)\s*[×x]\s*10\s*\^?\s*([+\-]?\d+)/gi,'$1e$2').trim();
}
function parseQuantityV21(s=''){
  const txt=prepQuantityTextV21(s);if(!txt)return null;
  const fm=txt.match(/([+\-]?(?:\d+(?:\.\d+)?|\.\d+))\s*\/\s*([+\-]?(?:\d+(?:\.\d+)?|\.\d+))/);
  let value,token,end;
  if(fm){const den=+fm[2];if(!den)return null;value=+fm[1]/den;token=fm[0];end=fm.index+fm[0].length}
  else{const m=txt.match(/[+\-]?(?:(?:\d+(?:\.\d*)?)|(?:\.\d+))(?:e[+\-]?\d+)?/i);if(!m)return null;value=+m[0];token=m[0];end=m.index+m[0].length}
  if(!Number.isFinite(value))return null;
  const tail=txt.slice(end),unit=unitFromTailV21(tail),dec=(token.match(/\.(\d+)/)||[])[1]?.length??0;
  return {value,token,decimals:dec,unitKey:unit.key,unitInfo:unit.info,unitRaw:unit.raw,raw:String(s)};
}
function answerSpecFromSourceV21(q){
  if(q?.answerSpecV21?.type==='numeric')return q.answerSpecV21;
  if(q?.kind!=='worked-problem'||(q.subparts?.length||0)>1)return null;
  const src=String(q.solutionText||'').trim();if(!src)return null;
  const patterns=[/(?:^|\n)\s*(?:final\s+answer|answer|ans\.?)[\s:=-]*([^\n]+)/gim,/(?:^|\n)\s*(?:therefore|thus)\s*[:,]?\s*([^\n]+)/gim];
  let candidates=[];for(let pi=0;pi<patterns.length;pi++){let m;while((m=patterns[pi].exec(src)))candidates.push({text:m[1].trim(),confidence:pi===0?.98:.88,label:pi===0?'explicit source answer':'source conclusion'})}
  if(!candidates.length)return null;const c=candidates.at(-1),qty=parseQuantityV21(c.text);if(!qty||c.confidence<.92)return null;
  return {type:'numeric',expectedRaw:c.text,value:qty.value,unitKey:qty.unitKey||'',unitRaw:qty.unitRaw||'',decimals:qty.decimals,confidence:c.confidence,source:c.label,derived:true};
}
function quantityToleranceV21(spec,expectedSI){
  const unitless=!spec.unitKey,integer=Math.abs(spec.value-Math.round(spec.value))<1e-12;
  if(unitless&&integer)return 1e-9;
  const step=spec.decimals>0?.5*Math.pow(10,-spec.decimals):(unitless?.000001:.5);
  const f=spec.unitKey&&UNIT_TABLE_V21[spec.unitKey]?UNIT_TABLE_V21[spec.unitKey].f:1;
  return Math.max(step*f,Math.abs(expectedSI)*.001,1e-12);
}
function gradeOpenNumericV21(q,response){
  const spec=answerSpecFromSourceV21(q);if(!spec)return {status:'unavailable',reason:'No high-confidence numeric final answer was found in the paired source solution.'};
  const got=parseQuantityV21(response);if(!got)return {status:'needs-review',spec,reason:'No numeric value could be read from your response.'};
  const ei=spec.unitKey?UNIT_TABLE_V21[spec.unitKey]:null,ui=got.unitKey?UNIT_TABLE_V21[got.unitKey]:null;
  let expectedSI=spec.value*(ei?.f||1),gotSI=got.value,unitAssumed=false;
  if(ei){if(ui){if(ui.d!==ei.d)return {status:'needs-review',spec,got,reason:`The units are not compatible (${got.unitKey} vs ${spec.unitKey}).`};gotSI=got.value*ui.f}else{gotSI=got.value*ei.f;unitAssumed=true}}
  else if(ui)return {status:'needs-review',spec,got,reason:'The source final answer has no recognized unit, but your response does.'};
  const tol=quantityToleranceV21(spec,expectedSI),diff=Math.abs(gotSI-expectedSI),correct=diff<=tol;
  return {status:correct?'correct':'wrong',spec,got,expectedSI,gotSI,tolerance:tol,diff,unitAssumed,reason:correct?'Numeric value is within the source-answer tolerance.':'Numeric value is outside the source-answer tolerance.'};
}
function openResponseV21(){return $('#workedResponseV20')?.value.trim()||''}
function openAnswerRecordV21(q,response,sec,correct,mode,extra={}){
  const a={id:q.id,correct,sec,picked:null,worked:true,openGraded:correct===true||correct===false,selfReviewed:true,response,ungraded:correct!==true&&correct!==false,recorded:false,itemType:'worked-problem',gradingMode:mode,...extra};
  session.answers.push(a);session.answeredCurrent=true;
  if(session.mode!=='mock'&&(correct===true||correct===false)){recordAnswer(q,correct,sec);a.recorded=true;a.gradedAt=Date.now()}
  autosaveSession('open-ended-grade');return a;
}
function openExpectedLabelV21(spec){return spec?String(spec.expectedRaw||spec.value):'—'}
function openDeterministicFeedbackV21(q,g,a){
  const fb=$('#quizFeedback');if(!fb)return;
  if(session.mode==='mock'){fb.innerHTML='<b>Final answer locked.</b><div class="tiny">Mock mode keeps grading and the source solution hidden until the session ends.</div>';fb.classList.remove('hidden');return}
  const good=g.status==='correct',unitNote=g.unitAssumed?'<div class="open-grade-unitwarn-v21">Value matched with the source unit assumed because no unit was entered.</div>':'';
  fb.innerHTML=`<div class="open-grade-result-v21 ${good?'good':'bad'}"><div class="open-grade-row-v21"><span class="open-grade-chip-v21 det">DETERMINISTIC</span><b data-csp-style="color:var(--${good?'good':'bad'})">${good?'Correct':'Incorrect'}</b></div><div data-csp-style-id="s014">Source final answer: <span class="open-grade-answer-v21">${esc(openExpectedLabelV21(g.spec))}</span></div><div class="open-grade-note-v21">${esc(g.reason)} · Time ${fmtTime(a.sec)}</div>${unitNote}<div class="open-grade-source-v21"><details><summary>Show paired source solution</summary><div class="worked-solution-view" data-csp-style-id="s008">${esc(q.solutionText||'No paired source solution.')}</div></details></div></div>`;
  fb.classList.remove('hidden');if(!good)$('#errorCapture').classList.remove('hidden');requestAnimationFrame(()=>{try{applyQuestionMathV172?.()}catch{};syncFocusStudyV17?.()});
}
async function checkOpenAnswerV21(){
  if(!session||session.answeredCurrent)return;const q=focusQuestionV17()||session.qs[session.index],response=openResponseV21();if(!response)return alert('Enter your final answer first.');const sec=Math.max(1,(Date.now()-session.questionStarted)/1000),g=gradeOpenNumericV21(q,response);
  if(g.status==='correct'||g.status==='wrong'){const a=openAnswerRecordV21(q,response,sec,g.status==='correct','DETERMINISTIC',{answerSpec:g.spec,unitAssumed:g.unitAssumed});openDeterministicFeedbackV21(q,g,a);return}
  await compareOpenWithGeminiV21(g);
}
function revealOpenSourceV21(){if(!session||session.answeredCurrent)return;lockWorkedResponseV20(true)}
async function compareOpenWithGeminiV21(localResult=null){
  if(!session||session.answeredCurrent)return;const q=focusQuestionV17()||session.qs[session.index],response=openResponseV21();if(!response)return alert('Enter your answer first.');if(!String(q.solutionText||'').trim())return revealOpenSourceV21();const fb=$('#quizFeedback');fb.innerHTML='<div class="open-grade-result-v21 warn"><b>Comparing with source solution…</b><div class="tiny">Gemini judgment is provisional and will not affect mastery unless you accept it.</div></div>';fb.classList.remove('hidden');
  try{const r=await aiFetchV32('/gemini/judge-open',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({question:q.question,sourceSolution:q.solutionText,userAnswer:response,category:q.category,subject:q.subject,topic:q.topic})});const verdict=String(r.verdict||'UNSURE').toUpperCase(),conf=Math.max(0,Math.min(1,+r.confidence||0));session.openAiPendingV21={qid:q.id,response,sec:Math.max(1,(Date.now()-session.questionStarted)/1000),verdict,confidence:conf,reason:r.reason||'',model:r.model||'Gemini'};const canAccept=conf>=OPEN_GRADE_V21.aiConfidenceMin&&['CORRECT','WRONG'].includes(verdict);fb.innerHTML=`<div class="open-grade-result-v21 warn open-grade-ai-v21"><div class="open-grade-row-v21"><span class="open-grade-chip-v21 ai">AI_PROVISIONAL</span><b>${esc(verdict)}</b><span class="tiny">${Math.round(conf*100)}% · ${esc(r.model||'Gemini')}</span></div><div data-csp-style-id="s014">${esc(r.reason||'Compared with the paired source solution.')}</div><div class="open-grade-note-v21">This is a provisional semantic comparison, not deterministic grading.</div><div class="open-grade-actions-v21">${canAccept?'<button class="btn primary small" data-csp-onclick="acceptOpenAiJudgeV21()">Accept judgment</button>':''}<button class="btn small" data-csp-onclick="revealOpenSourceAfterAiV21()">Reveal source solution</button><button class="btn small" data-csp-onclick="selfRateOpenV21('partial')">Mark partial</button></div></div>`;fb.classList.remove('hidden');autosaveSession('open-ai-provisional')}
  catch(e){fb.innerHTML=`<div class="open-grade-result-v21 warn"><b>AI comparison unavailable.</b><div class="tiny">${esc(e.message||e)} · You can still review against the source solution.</div><div class="open-grade-actions-v21"><button class="btn small" data-csp-onclick="revealOpenSourceAfterAiV21()">Reveal source solution</button></div></div>`;fb.classList.remove('hidden')}
}
function acceptOpenAiJudgeV21(){const p=session?.openAiPendingV21,q=focusQuestionV17();if(!p||!q||p.qid!==q.id||session.answeredCurrent)return;const correct=p.verdict==='CORRECT';const a=openAnswerRecordV21(q,p.response,p.sec,correct,'AI_CONFIRMED',{aiVerdict:p.verdict,aiConfidence:p.confidence,aiModel:p.model,aiReason:p.reason});session.openAiPendingV21=null;const fb=$('#quizFeedback');fb.innerHTML=`<div class="open-grade-result-v21 ${correct?'good':'bad'}"><div class="open-grade-row-v21"><span class="open-grade-chip-v21 ai">AI CONFIRMED BY USER</span><b data-csp-style="color:var(--${correct?'good':'bad'})">${correct?'Correct':'Incorrect'}</b></div><div data-csp-style-id="s014">${esc(p.reason||'')}</div><div class="open-grade-note-v21">You accepted a provisional Gemini comparison. This action, not the AI alone, updated mastery.</div><details data-csp-style-id="s008"><summary class="tiny">Show source solution</summary><div class="worked-solution-view" data-csp-style-id="s008">${esc(q.solutionText||'')}</div></details></div>`;if(!correct)$('#errorCapture').classList.remove('hidden');autosaveSession('open-ai-accepted');syncFocusStudyV17?.()}
function revealOpenSourceAfterAiV21(){session.openAiPendingV21=null;if(!session||session.answeredCurrent)return;const q=focusQuestionV17(),response=openResponseV21(),sec=Math.max(1,(Date.now()-session.questionStarted)/1000);const a=openAnswerRecordV21(q,response,sec,null,'SELF_REVIEW',{selfReviewed:true});const fb=$('#quizFeedback');fb.innerHTML=`<b>Source worked solution</b><div class="worked-solution-view" data-csp-style-id="s008">${esc(q.solutionText||'No paired source solution.')}</div><div class="tiny" data-csp-style-id="s008">Self-review only; no automatic grade was recorded.</div>`;fb.classList.remove('hidden');addSelfRatingUiV17?.();requestAnimationFrame(()=>{try{applyQuestionMathV172?.()}catch{}})}
function selfRateOpenV21(rating){if(!session||session.answeredCurrent)return;const q=focusQuestionV17(),response=openResponseV21(),sec=Math.max(1,(Date.now()-session.questionStarted)/1000);const a=openAnswerRecordV21(q,response,sec,null,'SELF_REVIEW',{selfRating:rating});session.openAiPendingV21=null;revealOpenSelfRatingV21(q,a)}
function revealOpenSelfRatingV21(q,a){const fb=$('#quizFeedback');fb.innerHTML=`<div class="open-grade-result-v21 warn"><b>Self-rated: ${esc(String(a.selfRating||'review').toUpperCase())}</b><div class="tiny">Partial/self-review results do not affect automatic mastery.</div><details data-csp-style-id="s008" open><summary class="tiny">Source solution</summary><div class="worked-solution-view" data-csp-style-id="s008">${esc(q.solutionText||'')}</div></details></div>`;fb.classList.remove('hidden')}
function lockOpenMockV21(){if(!session||session.answeredCurrent)return;const q=focusQuestionV17(),response=openResponseV21();if(!response)return alert('Enter your final answer first.');const sec=Math.max(1,(Date.now()-session.questionStarted)/1000),g=gradeOpenNumericV21(q,response);if(g.status==='correct'||g.status==='wrong')openAnswerRecordV21(q,response,sec,g.status==='correct','DETERMINISTIC',{answerSpec:g.spec,unitAssumed:g.unitAssumed});else openAnswerRecordV21(q,response,sec,null,'SELF_REVIEW');$('#quizFeedback').innerHTML='<b>Final answer locked.</b><div class="tiny">Mock mode keeps the result and source solution hidden until the session summary.</div>';$('#quizFeedback').classList.remove('hidden')}
function enhanceWorkedGraderV21(){
  if(!session)return;const q=focusQuestionV17();if(q?.kind!=='worked-problem'||!$('#workedResponseV20'))return;const field=$('#workedResponseV20');field.classList.add('open-grade-working-v21');field.placeholder='Enter your final answer (for example: 0.488 m³). You can keep working notes in the Scratchpad.';const lab=field.closest('.field')?.querySelector('label');if(lab)lab.textContent=session.mode==='mock'?'Final answer / concise response':'Final answer / concise response';const row=field.closest('div[style*="width:100%"]')?.querySelector('.btnrow');if(!row)return;const spec=answerSpecFromSourceV21(q);if(session.mode==='mock')row.innerHTML='<button class="btn primary" id="openLockV21">Lock final answer</button>';else row.innerHTML=`<button class="btn primary" id="openCheckV21">${spec?'Check final answer':'Check / compare answer'}</button><button class="btn" id="openRevealV21">Reveal source solution</button>`;$('#openLockV21')?.addEventListener('click',lockOpenMockV21);$('#openCheckV21')?.addEventListener('click',checkOpenAnswerV21);$('#openRevealV21')?.addEventListener('click',revealOpenSourceV21);if(spec&&!session.mode==='mock'){};const meta=$('#quizFeedback');if(spec&&meta?.classList.contains('hidden')){field.closest('div[style*="width:100%"]')?.insertAdjacentHTML('beforeend',`<div class="open-grade-note-v21" data-csp-style-id="s055">A source-labeled numeric final answer was detected, so CELE OS can grade this locally. Unit conversion is supported for common CE units.</div>`)}
}
const renderQuestionBeforeOpenV21=renderQuestion;renderQuestion=function(preserveClock=false){const r=renderQuestionBeforeOpenV21(preserveClock);if(session?.qs?.[session.index]?.kind==='worked-problem')requestAnimationFrame(enhanceWorkedGraderV21);return r};
const finishSessionBeforeOpenV21=finishSession;finishSession=function(){const snap=session,qs=snap?.qs?.slice()||[],answers=snap?.answers||[];if(snap){for(const a of answers){if(!a?.openGraded||a.recorded||!(a.correct===true||a.correct===false))continue;const q=qs.find(x=>x.id===a.id);if(q){recordAnswer(q,a.correct,a.sec||0);a.recorded=true;a.gradedAt=Date.now()}}}finishSessionBeforeOpenV21();if(!snap)return;const og=answers.filter(a=>a.openGraded&&(a.correct===true||a.correct===false)),oc=og.filter(a=>a.correct===true).length,ai=answers.filter(a=>a.gradingMode==='AI_CONFIRMED').length,det=answers.filter(a=>a.gradingMode==='DETERMINISTIC').length,last=(state.sessions||[]).at(-1);if(last){last.openEndedGraded=og.length;last.openEndedCorrect=oc;last.openEndedDeterministic=det;last.openEndedAiConfirmed=ai;last.answerRecords=answers.map(a=>({...a}));save()}const result=$('#sessionResult');if(result&&og.length){const card=result.querySelector('.debrief-v17')||result.querySelector('.card');card?.insertAdjacentHTML('beforeend',`<div class="open-grade-summary-v21"><span><b>${oc}/${og.length}</b> open-ended correct</span><span><b>${det}</b> deterministic</span>${ai?`<span><b>${ai}</b> AI judgment${ai===1?'':'s'} accepted</span>`:''}</div>`)}const notice=[...result?.querySelectorAll('.notice')||[]].find(x=>/only MCQs use automatic grading|not automatically scored/i.test(x.textContent||''));if(notice)notice.innerHTML='<b>v2.1 grading:</b> source-labeled numeric worked problems may be graded deterministically with unit conversion. Other worked/term items remain self-reviewed unless you explicitly accept a provisional Gemini comparison.'};
window.gradeOpenNumericV21=gradeOpenNumericV21;window.answerSpecFromSourceV21=answerSpecFromSourceV21;window.checkOpenAnswerV21=checkOpenAnswerV21;window.compareOpenWithGeminiV21=compareOpenWithGeminiV21;window.acceptOpenAiJudgeV21=acceptOpenAiJudgeV21;window.revealOpenSourceAfterAiV21=revealOpenSourceAfterAiV21;window.selfRateOpenV21=selfRateOpenV21;
