
const DIAG_V28={last:null,selfTest:null};
function diagNormV28(s){return String(s||'').toLowerCase().replace(/\s+/g,' ').replace(/[^a-z0-9]+/g,' ').trim()}
function diagIsPdfImportedV28(q){return ['ocr-generic','pdf-import'].includes(q?.kind)||/PDF Intake|OCR Intake/i.test(q?.source||'')}
function diagnosticAuditV28(){
  const qs=state.questions||[],sets=state.sets||[],issues=[];
  const add=(severity,type,q,detail)=>issues.push({severity,type,qid:q?.id||'',setId:q?.setId||'',label:q?.sourceQuestionNo?`Q${q.sourceQuestionNo}`:(q?.id||'record'),detail,question:q?.question||''});
  const seen=new Map();
  for(const q of qs){
    const choices=Array.isArray(q.choices)?q.choices:[];
    if(!String(q.question||'').trim())add('critical','EMPTY_STEM',q,'Question stem is empty.');
    if(!['MSTE','HGE','PSAD'].includes(q.category))add('critical','BAD_CATEGORY',q,`Category is ${q.category||'missing'}.`);
    if(choices.length && (choices.length!==4||choices.some(x=>!String(x||'').trim())))add('critical','BAD_CHOICES',q,'MCQ choices are incomplete or not exactly four.');
    if(choices.length===4 && new Set(choices.map(diagNormV28)).size<4)add('warn','DUPLICATE_CHOICES',q,'Two or more answer choices normalize to the same text.');
    if(q.correctIndex!=null && !(Number.isInteger(q.correctIndex)&&q.correctIndex>=0&&q.correctIndex<4))add('critical','BAD_KEY_INDEX',q,`correctIndex=${q.correctIndex} is outside A–D.`);
    if(q.keyStatus==='AI_CONFLICT')add('critical','AI_CONFLICT',q,'First-pass and verifier answers disagreed; automatic grading is disabled.');
    else if(q.keyStatus==='AI_PROVISIONAL')add('warn','AI_PROVISIONAL',q,'AI key is provisional and should not be trusted as source-verified.');
    else if(q.correctIndex==null && choices.length===4)add('warn','UNKEYED',q,'MCQ has no answer key yet.');
    if(diagIsPdfImportedV28(q)){
      if((q.ocrConfidence??1)<0.75)add('warn','LOW_OCR_CONFIDENCE',q,`OCR confidence is ${Math.round((q.ocrConfidence||0)*100)}%.`);
      if(q.ocrReviewed===false)add('warn','OCR_UNREVIEWED',q,'OCR-derived question was imported without a recorded human review.');
      if(!q.sourcePage)add('info','NO_SOURCE_PAGE',q,'Imported item has no source page recorded.');
      if(q.figureDependent && !q.visualAssetKey && !q.visualCrop)add('warn','MISSING_FIGURE',q,'Question is figure-dependent but has no stored visual source.');
    }
    const raw=`${q.question||''} ${(q.choices||[]).join(' ')}`;
    if(/\byw\b/i.test(raw))add('warn','AMBIGUOUS_GAMMA_W',q,'Literal “yw” appears in source text. CELE OS leaves it unchanged; review whether OCR intended γw.');
    if(/\b(?:x|y|z)\d\b/i.test(raw) && !/[\^²³⁴]/.test(raw))add('info','POSSIBLE_LOST_EXPONENT',q,'A variable immediately followed by a digit may be source text or a lost exponent; review before editing.');
    const k=`${q.setId||''}|${diagNormV28(q.question)}`;if(diagNormV28(q.question).length>20){if(seen.has(k))add('warn','DUPLICATE_STEM',q,`Question appears to duplicate ${seen.get(k)} in the same set.`);else seen.set(k,q.sourceQuestionNo?`Q${q.sourceQuestionNo}`:q.id)}
  }
  const keyed=qs.filter(q=>q.correctIndex!=null).length,verified=qs.filter(q=>['SOURCE_VERIFIED','LECTURER_VERIFIED','USER_VERIFIED','AI_VERIFIED'].includes(q.keyStatus)).length;
  const audit={at:Date.now(),sets:sets.length,questions:qs.length,keyed,verified,unkeyed:qs.length-keyed,critical:issues.filter(x=>x.severity==='critical').length,warn:issues.filter(x=>x.severity==='warn').length,info:issues.filter(x=>x.severity==='info').length,issues};
  DIAG_V28.last=audit;return audit;
}
function diagRowV28(label,value,status='info',detail=''){return `<div class="diag-row-v28"><div><b>${esc(label)}</b>${detail?`<div class="tiny">${esc(detail)}</div>`:''}</div><span class="diag-status-v28 diag-${status}-v28">${esc(String(value))}</span></div>`}
function renderDiagnosticsV28(){
  const a=diagnosticAuditV28();
  const m=$('#diagMetricsV28');if(m)m.innerHTML=[['Problem sets',a.sets],['Imported questions',a.questions],['Verified keys',a.verified],['Needs attention',a.critical+a.warn]].map(([l,k])=>`<div class="card metric"><div class="k">${k}</div><div class="l">${l}</div></div>`).join('');
  const sourceIssues=a.issues.filter(x=>['LOW_OCR_CONFIDENCE','OCR_UNREVIEWED','NO_SOURCE_PAGE','MISSING_FIGURE','DUPLICATE_STEM','DUPLICATE_CHOICES','AMBIGUOUS_GAMMA_W','POSSIBLE_LOST_EXPONENT','EMPTY_STEM','BAD_CATEGORY','BAD_CHOICES'].includes(x.type));
  const keyIssues=a.issues.filter(x=>['AI_CONFLICT','AI_PROVISIONAL','UNKEYED','BAD_KEY_INDEX'].includes(x.type));
  $('#diagSourceV28').innerHTML=diagRowV28('Source-fidelity flags',sourceIssues.length,sourceIssues.some(x=>x.severity==='critical')?'bad':sourceIssues.length?'warn':'ok',sourceIssues.length?'Review before treating the bank as source-clean.':'No structural source flags detected.')+diagRowV28('Figure-dependent without asset',sourceIssues.filter(x=>x.type==='MISSING_FIGURE').length,sourceIssues.some(x=>x.type==='MISSING_FIGURE')?'warn':'ok')+diagRowV28('Suspicious notation',sourceIssues.filter(x=>['AMBIGUOUS_GAMMA_W','POSSIBLE_LOST_EXPONENT'].includes(x.type)).length,sourceIssues.some(x=>['AMBIGUOUS_GAMMA_W','POSSIBLE_LOST_EXPONENT'].includes(x.type))?'warn':'ok','Reported only; never auto-corrected.');
  $('#diagKeysV28').innerHTML=diagRowV28('Verified gradable keys',a.verified,'ok')+diagRowV28('Unkeyed MCQs',keyIssues.filter(x=>x.type==='UNKEYED').length,keyIssues.some(x=>x.type==='UNKEYED')?'warn':'ok')+diagRowV28('AI conflicts',keyIssues.filter(x=>x.type==='AI_CONFLICT').length,keyIssues.some(x=>x.type==='AI_CONFLICT')?'bad':'ok')+diagRowV28('AI provisional',keyIssues.filter(x=>x.type==='AI_PROVISIONAL').length,keyIssues.some(x=>x.type==='AI_PROVISIONAL')?'warn':'ok');
  const gold=typeof OCR_GOLDEN_DATA!=='undefined'?Object.entries(OCR_GOLDEN_DATA):[];
  $('#diagGoldenV28').innerHTML=gold.length?gold.map(([k,v])=>diagRowV28((v?.meta?.title||k),`${v?.questions?.length||0} items`,(v?.questions?.length||0)>0?'ok':'bad',`${v?.meta?.pages||'—'} pages · ${v?.meta?.cat||k.toUpperCase()}`)).join(''):'<div class="empty">No embedded golden corpus found.</div>';
  $('#diagIssueCountV28').textContent=String(a.critical+a.warn+a.info);
  const list=[...a.issues].sort((x,y)=>({critical:0,warn:1,info:2}[x.severity]-({critical:0,warn:1,info:2}[y.severity])));
  $('#diagIssuesV28').innerHTML=list.length?list.slice(0,250).map(x=>`<div class="diag-issue-v28"><span class="diag-severity-v28 ${x.severity}">${x.severity.toUpperCase()}</span><div class="diag-q-v28"><b>${esc(x.type)} · ${esc(x.label)}</b><div class="tiny">${esc(x.detail)}</div><div class="tiny">${esc((x.question||'').slice(0,220))}</div></div><button class="btn small" data-csp-onclick="diagOpenItemV28('${x.qid}')">Inspect</button></div>`).join(''):'<div class="notice good"><b>No audit flags.</b> The current local bank has no structural, source-fidelity, or key-integrity warnings under the v2.8 rules.</div>';
  if(DIAG_V28.selfTest)renderDiagServicesV28(DIAG_V28.selfTest);
}
function diagOpenItemV28(qid){const q=(state.questions||[]).find(x=>x.id===qid);if(!q)return alert('Question record not found.');const set=state.sets.find(s=>s.id===q.setId);$('#modalTitle').textContent=`Source audit · ${q.sourceQuestionNo?'Q'+q.sourceQuestionNo:q.id}`;$('#modalBody').innerHTML=`<div class="notice"><b>${esc(set?.title||q.setTitle||'Problem set')}</b><div class="tiny">${esc(q.category||'')} · ${esc(q.subject||'')} · ${esc(q.topic||'')}</div></div><div data-csp-style-id="s007"></div><div class="listitem"><b>Stored source text</b><div class="tiny" data-csp-style-id="s068">${esc(q.question||'')}</div></div>${Array.isArray(q.choices)&&q.choices.length?`<div class="listitem"><b>Choices</b>${q.choices.map((c,i)=>`<div class="tiny">${'ABCD'[i]||i+1}. ${esc(c)}</div>`).join('')}</div>`:''}<div class="listitem"><b>Provenance</b><div class="tiny">Kind: ${esc(q.kind||'—')} · page ${esc(q.sourcePage||'—')} · OCR ${q.ocrConfidence!=null?Math.round(q.ocrConfidence*100)+'%':'—'} · key ${esc(q.keyStatus||'UNKEYED')}</div><div class="tiny">${esc(q.source||'No source reference')}</div></div><div class="btnrow" data-csp-style-id="s009"><button class="btn" data-csp-onclick="closeModal();navTo('bank')">Open Question Bank</button><button class="btn" data-csp-onclick="closeModal();navTo('intake')">Open PDF Intake</button></div>`;openModal()}
async function runSelfTestV28(){
  const rows=[];const push=(name,ok,detail)=>rows.push({name,ok,detail});
  try{const k='cele_diag_v28_'+Date.now();localStorage.setItem(k,'ok');const ok=localStorage.getItem(k)==='ok';localStorage.removeItem(k);push('Local storage',ok,ok?'Read/write round-trip passed.':'Round-trip failed.')}catch(e){push('Local storage',false,e.message||String(e))}
  try{await openAssetDB();push('IndexedDB assets',true,'Local PDF/visual asset database opened successfully.')}catch(e){push('IndexedDB assets',false,e.message||String(e))}
  try{const j=await window.CELEDocumentIO?.status?.();push('PDF/OCR adapter',!!j?.ok&&!!j?.rendererAvailable,`${j?.transport==='tauri-native'?'native desktop':'local compatibility'} · renderer ${j?.rendererAvailable?'ready':'unavailable'} · OCR ${j?.ocrAvailable?'ready':'unavailable'}`)}catch(e){push('PDF/OCR adapter',false,'Native/local PDF-OCR services are offline or unreachable.')}
  if(window.CELE_PUBLIC_EDITION_V3180){push('Cloud AI bridge',true,'Not included in the local-first public edition.')}else{try{const j=await aiFetchV32('/gemini/status');push('Gemini bridge',!!j.configured, j.configured?`Configured · ${j.model||'Gemini'}`:'Bridge reachable but API key is not configured.')}catch(e){push('Gemini bridge',false,'Bridge offline or unreachable.')}}
  push('Math fidelity guardrail',!engineeringMathHTMLV172('yw = 9.81').includes('γ'),'Literal “yw” is no longer normalized to γw automatically.');
  const a=diagnosticAuditV28();push('Database structural audit',a.critical===0,a.critical?`${a.critical} critical issue(s) found.`:'No critical structural issue found.');
  DIAG_V28.selfTest={at:Date.now(),rows};renderDiagServicesV28(DIAG_V28.selfTest);return DIAG_V28.selfTest;
}
function renderDiagServicesV28(t){const el=$('#diagServicesV28');if(!el)return;el.innerHTML=t.rows.map(r=>diagRowV28(r.name,r.ok?'PASS':'CHECK',r.ok?'ok':'warn',r.detail)).join('')+`<div class="tiny" data-csp-style-id="s008">Last run ${new Date(t.at).toLocaleString()}</div>`}
function exportDiagnosticsV28(){const a=diagnosticAuditV28(),report={app:'CELE Topnotcher OS',version:APP_VERSION,type:'reliability-audit',exportedAt:new Date().toISOString(),audit:a,selfTest:DIAG_V28.selfTest,guardrail:'Diagnostic report only. No source text, answer key, or mastery record is automatically changed by the audit.'};download(`CELE_Reliability_Audit_${new Date().toISOString().slice(0,10)}.json`,report)}
function wireDiagnosticsV28(){const a=$('#diagRunV28');if(a)a.onclick=renderDiagnosticsV28;const s=$('#diagSelfTestV28');if(s)s.onclick=async()=>{s.disabled=true;s.textContent='Testing…';try{await runSelfTestV28()}finally{s.disabled=false;s.textContent='Run app self-test'}};const e=$('#diagExportV28');if(e)e.onclick=exportDiagnosticsV28}
setTimeout(()=>{wireDiagnosticsV28()},0);
