
// v1.7.4 fidelity guardrails, folded into v1.8.
const atomMathBaseV174=atomMathV172;
const applyMixedMathBaseV174=applyMixedMathV173;
applyMixedMathV173=function(el,allowDisplay=true){if(el?.classList?.contains('raw-source-v174'))return;return applyMixedMathBaseV174(el,allowDisplay)};
atomMathV172=function(s){
  // Deliberately do NOT infer the ambiguous OCR token "yw" as gamma_w.
  let x=esc(String(s??''));
  x=x.replace(/\b(?:gamma_w|gammaw|γw)\b/gi,'<span class="eng-symbol-v172">γ<sub>w</sub></span>')
    .replace(/\bgamma_sat\b/gi,'<span class="eng-symbol-v172">γ<sub>sat</sub></span>').replace(/\bgamma_d\b/gi,'<span class="eng-symbol-v172">γ<sub>d</sub></span>')
    .replace(/\bgamma\b/gi,'<span class="eng-symbol-v172">γ</span>').replace(/\bsigma\b/gi,'<span class="eng-symbol-v172">σ</span>').replace(/\bepsilon\b/gi,'<span class="eng-symbol-v172">ε</span>')
    .replace(/\btau\b/gi,'<span class="eng-symbol-v172">τ</span>').replace(/\btheta\b/gi,'<span class="eng-symbol-v172">θ</span>').replace(/\bphi\b/gi,'<span class="eng-symbol-v172">φ</span>')
    .replace(/\brho\b/gi,'<span class="eng-symbol-v172">ρ</span>').replace(/\bmu\b/g,'<span class="eng-symbol-v172">μ</span>').replace(/\bnu\b/g,'<span class="eng-symbol-v172">ν</span>')
    .replace(/\bpi\b/gi,'<span class="eng-symbol-v172">π</span>').replace(/\bDelta\b/g,'<span class="eng-symbol-v172">Δ</span>').replace(/\bsum\b/g,'<span class="eng-symbol-v172">Σ</span>').replace(/\bintegral\b/gi,'<span class="eng-symbol-v172">∫</span>');
  x=x.replace(/([A-Za-zγσρετθφρμνΔ])_([A-Za-z0-9]+)\b/g,'$1<sub>$2</sub>').replace(/\^\(([^()]+)\)/g,'<sup>$1</sup>').replace(/\^(-?\d+)/g,'<sup>$1</sup>');return x
};
function mathFidelityRiskV174(raw){const s=String(raw||'');const flags=[];if(/\byw\b/i.test(s))flags.push('ambiguous yw kept literal');if(/[�]/.test(s))flags.push('replacement glyph');if(/\b(?:O|l)\d{1,2}\b/.test(s))flags.push('possible OCR character confusion');return flags}
function toggleRawSourceV174(){const el=$('#quizQuestion');if(!el)return;const raw=el.dataset.rawTextV172||focusQuestionV17()?.question||el.textContent||'';const on=el.classList.toggle('raw-source-v174');if(on){el.dataset.renderedHtmlV174=el.innerHTML;el.textContent=raw}else{el.classList.remove('raw-source-v174');applyMixedMathV173(el,true)}closeFocusToolsMenuV171()}
function wireMathFidelityV174(){ensureFocusUiV17();const menu=$('#focusToolsMenuV171');if(menu&&!menu.querySelector('[data-focus-tool-v174="raw"]')){const btn=document.createElement('button');btn.className='btn small';btn.type='button';btn.dataset.focusToolV174='raw';btn.innerHTML='≡&nbsp;&nbsp;Raw source text';const exit=menu.querySelector('[data-focus-tool-v171="exit"]');menu.insertBefore(btn,exit||null);btn.onclick=toggleRawSourceV174}requestAnimationFrame(()=>{const el=$('#quizQuestion');if(el)el.title='Rendered from the stored source text only. Formula suggestions never modify the question.'})}
const renderQuestionBaseV174=renderQuestion;renderQuestion=function(preserveClock=false){const r=renderQuestionBaseV174(preserveClock);requestAnimationFrame(wireMathFidelityV174);return r};
wireMathFidelityV174();
window.mathFidelityRiskV174=mathFidelityRiskV174;window.toggleRawSourceV174=toggleRawSourceV174;
