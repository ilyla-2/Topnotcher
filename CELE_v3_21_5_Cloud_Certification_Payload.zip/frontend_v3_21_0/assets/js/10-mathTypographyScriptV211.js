
(function(){
  const previousAtom=window.atomMathV172||atomMathV172;
  function superTextV211(s){const map={'⁰':'0','¹':'1','²':'2','³':'3','⁴':'4','⁵':'5','⁶':'6','⁷':'7','⁸':'8','⁹':'9','⁻':'−','⁺':'+'};return [...s].map(c=>map[c]??c).join('')}
  window.atomMathV172=atomMathV172=function(s){
    let x=esc(String(s??''));
    // Greek / standard CE notation from explicit source tokens only.
    x=x.replace(/\b(?:gamma_w|gammaw|γw)\b/gi,'<span class="eng-symbol-v172">γ<sub>w</sub></span>')
      .replace(/\bgamma_sat\b/gi,'<span class="eng-symbol-v172">γ<sub>sat</sub></span>')
      .replace(/\bgamma_d\b/gi,'<span class="eng-symbol-v172">γ<sub>d</sub></span>')
      .replace(/\bgamma\b/gi,'<span class="eng-symbol-v172">γ</span>')
      .replace(/\bsigma\b/gi,'<span class="eng-symbol-v172">σ</span>')
      .replace(/\bepsilon\b/gi,'<span class="eng-symbol-v172">ε</span>')
      .replace(/\btau\b/gi,'<span class="eng-symbol-v172">τ</span>')
      .replace(/\btheta\b/gi,'<span class="eng-symbol-v172">θ</span>')
      .replace(/\bphi\b/gi,'<span class="eng-symbol-v172">φ</span>')
      .replace(/\brho\b/gi,'<span class="eng-symbol-v172">ρ</span>')
      .replace(/\bmu\b/g,'<span class="eng-symbol-v172">μ</span>')
      .replace(/\bnu\b/g,'<span class="eng-symbol-v172">ν</span>')
      .replace(/\bpi\b/gi,'<span class="eng-symbol-v172">π</span>')
      .replace(/\bDelta\b/g,'<span class="eng-symbol-v172">Δ</span>')
      .replace(/\bsum\b/g,'<span class="eng-symbol-v172">Σ</span>')
      .replace(/\bintegral\b/gi,'<span class="eng-symbol-v172">∫</span>');
    // Explicit logarithm base notation. log10(...) and log_10(...) mean base ten; no base is invented for plain log(...).
    x=x.replace(/\blog_(\d{1,3}|[A-Za-z])\b/g,'<span class="eng-fn-v211">log<sub>$1</sub></span>')
      .replace(/\blog(10|2)\b/g,'<span class="eng-fn-v211">log<sub>$1</sub></span>');
    // Explicit subscripts such as x_1, M_cr, f_c. Apostrophes in the base are preserved.
    x=x.replace(/\b([A-Za-z][A-Za-z0-9']{0,10})_([A-Za-z0-9]{1,8})\b/g,'$1<sub>$2</sub>');
    // Scientific multiplication is normalized only when explicitly written before 10^n.
    x=x.replace(/(\d+(?:\.\d+)?)\s*[xX*]\s*(?=10\^)/g,'$1 × ');
    // Explicit caret exponents. Supports x^3, 10^-6, e^x, x^(n-1).
    x=x.replace(/\^\(([^()]{1,30})\)/g,'<sup>$1</sup>')
      .replace(/\^\{([^{}]{1,30})\}/g,'<sup>$1</sup>')
      .replace(/\^(-?\d+(?:\.\d+)?|[A-Za-z][A-Za-z0-9]*)/g,'<sup>$1</sup>');
    // Preserve already supplied Unicode superscript digits but render them consistently.
    x=x.replace(/([⁰¹²³⁴⁵⁶⁷⁸⁹⁻⁺]+)/g,(m)=>'<sup>'+superTextV211(m)+'</sup>');
    return x;
  };
  // Rebind core renderer so it uses the upgraded atom function.
  window.engineeringMathHTMLV172=engineeringMathHTMLV172=function(raw){
    let s=String(raw??''),slots=[];const hold=h=>{const k=`§M${slots.length}§`;slots.push(h);return k};
    s=s.replace(/\bd2([A-Za-z])\s*\/\s*d([A-Za-z])2\b/g,(m,a,b)=>hold(fracV172(`d^2${a}`,`d${b}^2`)));
    s=s.replace(/\bd([A-Za-z])\s*\/\s*d([A-Za-z])\b/g,(m,a,b)=>hold(fracV172(`d${a}`,`d${b}`)));
    s=s.replace(/sqrt\(([^()\n]{1,80})\)/gi,(m,a)=>hold(`<span class="eng-root-v172"><span class="rad">√</span><span class="body">${atomMathV172(a)}</span></span>`));
    s=s.replace(/\b([A-Z][A-Za-z0-9_^]{0,8}|\d+(?:\.\d+)?[A-Za-z][A-Za-z0-9_^]{0,7}|[A-Za-z][A-Za-z0-9_^]{0,4})\s*\/\s*\(([^()\n]{1,30})\)/g,(m,a,b)=>/\b(?:and|or)\b/i.test(a)?m:hold(fracV172(a,b)));
    s=s.replace(/\b([A-Z]{1,4}[A-Za-z0-9_^]{0,5})\s*\/\s*([A-Z][A-Za-z0-9_^]{0,7})\b/g,(m,a,b)=>hold(fracV172(a,b)));
    let out=atomMathV172(s);slots.forEach((h,i)=>{out=out.replace(`§M${i}§`,h)});
    out=out.replace(/\b(kN|N|MPa|kPa|Pa)\s*\/\s*(m|cm|mm)(?:\^?3|³)\b/g,'<span class="eng-unit-v172">$1/$2<sup>3</sup></span>')
      .replace(/\b(kN|N|MPa|kPa|Pa)\s*\/\s*(m|cm|mm)(?:\^?2|²)\b/g,'<span class="eng-unit-v172">$1/$2<sup>2</sup></span>')
      .replace(/\b(m|cm|mm)(?:\^?4|⁴)\b/g,'<span class="eng-unit-v172">$1<sup>4</sup></span>')
      .replace(/\b(m|cm|mm)(?:\^?3|³)\b/g,'<span class="eng-unit-v172">$1<sup>3</sup></span>')
      .replace(/\b(m|cm|mm)(?:\^?2|²)\b/g,'<span class="eng-unit-v172">$1<sup>2</sup></span>');
    return out;
  };
  // Extend the prose-aware slotting layer. Only notation explicitly present in source gets transformed.
  window.mixedEngineeringHTMLV173=mixedEngineeringHTMLV173=function(raw,{allowDisplay=true}={}){
    let s=String(raw??''),slots=[];
    if(allowDisplay){
      s=s.replace(/\b(d(?:2|\^2)?[A-Za-z]\s*\/\s*d[A-Za-z](?:2|\^2)?\s*=\s*[^,;\n.!?]{1,90})\s*,\s*((?:given|where|if|when|find|calculate|determine))\b/gi,(m,e,w)=>mathSlotV173(slots,displayMathV173(e.trim()))+w.charAt(0).toUpperCase()+w.slice(1));
      s=s.replace(/(^|\n)\s*([A-Za-zγρστθεφΔ](?:_[A-Za-z0-9]+)?(?:\([^()\n]{0,20}\))?\s*=\s*[^\n,;.!?]{1,70})\s*(?=\n|$)/g,(m,p,e)=>p+mathSlotV173(slots,displayMathV173(e.trim())));
    }
    s=s.replace(/\b(?:gamma_w|gamma_sat|gamma_d|gamma|sigma|epsilon|tau|theta|phi|rho|Delta)\b/gi,m=>mathSlotV173(slots,inlineMathV173(m)));
    // Explicit log bases and standard log function calls.
    s=s.replace(/\blog_(?:\d{1,3}|[A-Za-z])\s*(?:\([^()\n]{1,50}\))?/g,m=>mathSlotV173(slots,inlineMathV173(m)));
    s=s.replace(/\blog(?:10|2)\b\s*(?:\([^()\n]{1,50}\))?/g,m=>mathSlotV173(slots,inlineMathV173(m)));
    // Scientific notation is captured before generic powers so the whole expression stays together.
    s=s.replace(/\b\d+(?:\.\d+)?\s*[xX*×]\s*10\^-?\d+\b/g,m=>mathSlotV173(slots,inlineMathV173(m)));
    // Explicit exponent notation: variable, coefficient+variable, parenthesized base, or powers of ten. Never infer x3 as x^3.
    s=s.replace(/\b(?:\d+(?:\.\d+)?)?[A-Za-z][A-Za-z0-9_']{0,12}\^(?:\([^()\n]{1,30}\)|\{[^{}\n]{1,30}\}|-?\d+(?:\.\d+)?|[A-Za-z][A-Za-z0-9]*)/g,m=>mathSlotV173(slots,inlineMathV173(m)));
    s=s.replace(/\b\d+(?:\.\d+)?\^(?:\([^()\n]{1,30}\)|-?\d+(?:\.\d+)?|[A-Za-z][A-Za-z0-9]*)/g,m=>mathSlotV173(slots,inlineMathV173(m)));
    s=s.replace(/\([^()\n]{1,30}\)\^(?:\([^()\n]{1,30}\)|-?\d+|[A-Za-z])/g,m=>mathSlotV173(slots,inlineMathV173(m)));
    // Explicit subscript notation.
    s=s.replace(/\b[A-Za-z][A-Za-z0-9']{0,12}_[A-Za-z0-9]{1,8}\b/g,m=>mathSlotV173(slots,inlineMathV173(m)));
    // Common function powers/inverses, e.g. sin^2(theta), sin^-1(x).
    s=s.replace(/\b(?:sin|cos|tan|sec|csc|cot)\^(?:-?\d+)\s*(?:\([^()\n]{1,40}\)|[A-Za-z]+)?/gi,m=>mathSlotV173(slots,inlineMathV173(m)));
    s=s.replace(/\b[A-Za-z]\([^\n()]{1,12}\)\s*=\s*[-+]?\d+(?:\.\d+)?\b/g,m=>mathSlotV173(slots,inlineMathV173(m)));
    s=s.replace(/\b[A-Za-z]\s*=\s*[-+]?\d+(?:\.\d+)?\b/g,m=>mathSlotV173(slots,inlineMathV173(m)));
    s=s.replace(/\b\d+(?:\.\d+)?\s*(?:kN|N|MPa|kPa|Pa)\s*\/\s*(?:m|cm|mm)(?:\^?[234]|[²³⁴])\b/g,m=>mathSlotV173(slots,inlineMathV173(m)));
    let out=esc(s);slots.forEach((html,i)=>{out=out.replace(`§I${i}§`,html)});return out;
  };
  // Re-render current question/formulas after patch installation.
  requestAnimationFrame(()=>{try{applyQuestionMathV173();renderFormulas();renderFocusFormulasV17()}catch(e){console.warn('v2.1.1 typography refresh',e)}});
})();
