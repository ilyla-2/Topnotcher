
/* v3.13.6 · Interface Consistency & Density */
(function(){
'use strict';
const PAGE_TITLES_V316={command:'Command Center',dashboard:'Home',bank:'Question Bank',intake:'PDF Intake',adaptivemock:'Adaptive Mock',study:'Study / Mock',exam:'Exam Simulation',errors:'Error Bank',remediation:'Mistake Repair',mastery:'Concept Mastery',coverage:'Coverage Map',readiness:'Study Readiness',mockanalytics:'Mock Analytics',longterm:'Progress Intelligence',syllabus:'Syllabus Coverage',dailymission:'Daily Mission',retention:'Retention',planner:'Weekly Planner',gaps:'Gap Analysis',visuallab:'Visual Concept Lab',concepts:'Concept Mastery',nscp:'NSCP Understanding',designlab:'Structural Design Lab',bridge:'Learning Bridge',formulas:'Formula Library',derivations:'Derivation Reader',bankaudit:'Bank & Source Audit',settings:'Settings',diagnostics:'Reliability Audit',data:'Data & Backup',help:'How to Use'};
function syncPageTitle316(v){const t=PAGE_TITLES_V316[v];const el=document.querySelector('#pageTitle');if(t&&el&&el.textContent!==t)el.textContent=t}
function syncActiveTitle316(){const v=document.querySelector('.view.active')?.id?.replace(/^view-/,'');if(v)syncPageTitle316(v)}
function apply316(){
  document.body.classList.add('interface-consistency-v316');
  syncActiveTitle316();
  document.title=`CELE Topnotcher OS ${typeof APP_VERSION==='string'?APP_VERSION:'3.14.1'} · Engineering Studio`;
  try{
    document.querySelectorAll('.release-current-v315,.release-current-v314,.release-current-v316').forEach(x=>x.remove());
    const sidefoot=document.querySelector('.sidefoot');
    /* Legacy consistency maintenance must not re-add an obsolete release marker. */
    if(false&&sidefoot&&!sidefoot.querySelector('.release-current-v316')){
      const r=document.createElement('div');r.className='release-row release-current-v314 release-current-v316';
      r.innerHTML='<span class="release-dot"></span><span>v3.13.6 · Interface Polish</span>';
      const first=sidefoot.querySelector('.release-row');if(first)sidefoot.insertBefore(r,first);else sidefoot.append(r);
    }
    const current=typeof APP_VERSION==='string'?APP_VERSION:'3.14.1';
    document.querySelectorAll('#view-settings .settings-kv-v20 b').forEach(b=>{if(/^3\.\d+\.\d+$/.test(b.textContent.trim()))b.textContent=current});
    const sh=document.querySelector('#view-settings .settings-hero-v20 .tiny');if(sh)sh.textContent=`CELE TOPNOTCHER OS ${current}`;
  }catch(e){}
}
function tidy316(root=document){
  root.querySelectorAll?.('.section-title').forEach(el=>{
    const title=el.querySelector('h3,h4');if(!title)return;
    title.setAttribute('title',title.textContent.trim());
  });
  root.querySelectorAll?.('button:disabled').forEach(b=>b.setAttribute('aria-disabled','true'));
}
try{if(typeof navTo==='function'){const baseNavV316=navTo;navTo=function(v){const out=baseNavV316(v);syncPageTitle316(v);setTimeout(()=>syncPageTitle316(v),0);setTimeout(()=>syncPageTitle316(v),60);return out}}}catch(e){}
const activeV316=document.querySelector('.view.active')?.id?.replace(/^view-/,'');if(activeV316)syncPageTitle316(activeV316);
apply316();tidy316();
setTimeout(()=>{apply316();tidy316()},250);
setTimeout(()=>{apply316();tidy316()},1100);
setTimeout(()=>{apply316();tidy316()},1500);
setTimeout(()=>{apply316();tidy316()},2400);
let queued=false;
const obs=new MutationObserver(m=>{if(queued||!m.some(x=>x.addedNodes?.length))return;queued=true;requestAnimationFrame(()=>{queued=false;apply316();tidy316();syncActiveTitle316()})});
obs.observe(document.body,{childList:true,subtree:true});
window.applyInterfaceConsistencyV316=apply316;
})();
