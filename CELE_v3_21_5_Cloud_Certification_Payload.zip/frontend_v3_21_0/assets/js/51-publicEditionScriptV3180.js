
(()=>{
  window.CELE_PUBLIC_EDITION_V3180=true;
  const refresh=()=>{
    try{
      document.documentElement.classList.add('public-edition-v3180');
      const n=(typeof allQuestions==='function'?allQuestions().length:0);
      document.getElementById('publicEmptyBankV3180')?.classList.toggle('hidden',n!==0);
      document.querySelectorAll('.settings-card-v20').forEach(card=>{if(/Gemini answer keys/i.test(card.textContent||''))cspStyleSet(card,'display','none')});
      const diag=document.getElementById('diagServicesV28');
      if(diag&&/Gemini bridge/i.test(diag.textContent||'')){}
    }catch(e){console.warn('Public-edition UI refresh skipped',e)}
  };
  addEventListener('DOMContentLoaded',()=>{refresh();setTimeout(refresh,400);setTimeout(refresh,1200)});
  const base=window.renderDashboard; if(typeof base==='function')window.renderDashboard=function(){const r=base.apply(this,arguments);refresh();return r};
})();
