
/* v2.12.0 · Adaptive Concept Diagnosis
   Advisory routing only. This layer never records correctness, modifies answer keys,
   resolves an Error Bank item, or grants mastery. */
const AD212_SIGNATURES={
 CONCEPT_MODEL:{label:'Conceptual model failure',short:'Concept model'},
 FORMULA_SELECTION:{label:'Formula-selection failure',short:'Formula selection'},
 SETUP_MODELING:{label:'Setup / modeling failure',short:'Setup / modeling'},
 SIGN_CONVENTION:{label:'Sign-convention failure',short:'Sign convention'},
 UNITS_CONVERSION:{label:'Units / conversion failure',short:'Units / conversion'},
 ALGEBRA_MANIPULATION:{label:'Algebra / manipulation failure',short:'Algebra'},
 CALCULATOR_EXECUTION:{label:'Calculator execution failure',short:'Calculator'},
 READING_CONDITION:{label:'Reading / condition failure',short:'Reading condition'},
 TIME_PRESSURE:{label:'Time-pressure failure',short:'Time pressure'},
 CARELESS_EXECUTION:{label:'Careless execution failure',short:'Careless execution'},
 UNKNOWN:{label:'Needs diagnosis',short:'Needs diagnosis'}
};
const AD212_ROUTES={
 VISUAL:{label:'Native visual model',verb:'Open visual repair'},
 DERIVATION:{label:'Full derivation',verb:'Read derivation'},
 FORMULA_RECALL:{label:'Formula recall',verb:'Open formula recall'},
 MICRO_DRILL:{label:'Focused micro-drill',verb:'Run focused audit'},
 SOURCE_REVIEW:{label:'Source-condition review',verb:'Review conditions'},
 DIRECT_RETRY:{label:'Immediate graded retry',verb:'Retry now'},
 MANUAL_DIAGNOSIS:{label:'Confirm diagnosis first',verb:'Open diagnosis'}
};
function ensureAdaptiveDiagnosisStateV212(){
 state.adaptiveDiagnosisV212=state.adaptiveDiagnosisV212&&typeof state.adaptiveDiagnosisV212==='object'?state.adaptiveDiagnosisV212:{history:[]};
 if(!Array.isArray(state.adaptiveDiagnosisV212.history))state.adaptiveDiagnosisV212.history=[];
 return state.adaptiveDiagnosisV212;
}
function ad212TopType(e){const rows=Object.entries(e?.types||{}).filter(([k,v])=>k!=='UNCLASSIFIED'&&+v>0).sort((a,b)=>b[1]-a[1]);return rows[0]?.[0]||null}
function ad212Notes(e){return (e?.notes||[]).map(n=>String(n?.text||'')).join(' ').toLowerCase()}
function ad212TypeToSignature(type){return ({CONCEPT:'CONCEPT_MODEL',FORMULA:'FORMULA_SELECTION',SETUP:'SETUP_MODELING',ALGEBRA:'ALGEBRA_MANIPULATION',CALCULATOR:'CALCULATOR_EXECUTION',UNITS:'UNITS_CONVERSION',MISREAD:'READING_CONDITION',TIME:'TIME_PRESSURE',CARELESS:'CARELESS_EXECUTION'})[type]||'UNKNOWN'}
function ad212ConfidenceBand(x){return x>=.84?'HIGH':x>=.62?'MEDIUM':'LOW'}
function adaptiveConceptDiagnosisV212(q,e=state.errors?.[q?.id]){
 if(!q||!e)return{signature:'UNKNOWN',confidence:.2,band:'LOW',evidence:['No Error Bank evidence'],route:'MANUAL_DIAGNOSIS',reason:'No mistake record is available.'};
 const evidence=[],notes=ad212Notes(e),latest=typeof latestAttemptV29==='function'?latestAttemptV29(q.id):null;
 const rec=e.remediationV29||{},confirmed=rec.diagnosis&&rec.diagnosis!=='UNCLASSIFIED'&&rec.diagnosis!=='UNSURE';
 const typed=ad212TopType(e);let baseType=confirmed?rec.diagnosis:typed;let confidence=confirmed?(rec.source==='manual'?0.99:0.94):(typed?0.93:0.35);let source=confirmed?(rec.source||'confirmed'):(typed?'miss-tag':'local');
 if(confirmed)evidence.push(`confirmed ${String(rec.diagnosis).toLowerCase()} diagnosis`);else if(typed)evidence.push(`miss tag: ${String(typed).toLowerCase()}`);
 const signRe=/sign convention|sign error|wrong sign|positive|negative|clockwise|counter.?clockwise|compression|tension|sagging|hogging|upward|downward|left|right|datum/;
 const unitRe=/\bunit|convert|conversion|dimension|mm\b|cm\b|meter|metre|kpa|mpa|kn\b|newton|degree|radian/;
 const algebraRe=/algebra|transpose|rearrang|simplif|arithmetic|quadratic|solve for|isolate/;
 const formulaRe=/wrong formula|formula selection|formula|equation|relation/;
 const setupRe=/setup|model|fbd|free.?body|control volume|diagram|datum|geometry/;
 let sig=ad212TypeToSignature(baseType);
 if(signRe.test(notes)&&(sig==='SETUP_MODELING'||sig==='CARELESS_EXECUTION'||sig==='UNKNOWN')){sig='SIGN_CONVENTION';confidence=Math.max(confidence,.84);evidence.push('note mentions sign/direction convention')}
 else if(unitRe.test(notes)&&(sig==='UNKNOWN'||sig==='CARELESS_EXECUTION')){sig='UNITS_CONVERSION';confidence=Math.max(confidence,.80);evidence.push('note mentions units/conversion')}
 else if(algebraRe.test(notes)&&sig==='UNKNOWN'){sig='ALGEBRA_MANIPULATION';confidence=.78;evidence.push('note mentions symbolic manipulation')}
 else if(formulaRe.test(notes)&&sig==='UNKNOWN'){sig='FORMULA_SELECTION';confidence=.78;evidence.push('note mentions formula choice')}
 else if(setupRe.test(notes)&&sig==='UNKNOWN'){sig='SETUP_MODELING';confidence=.76;evidence.push('note mentions setup/modeling')}
 if(sig==='UNKNOWN'&&typeof heuristicDiagnosisV29==='function'){
   const h=heuristicDiagnosisV29(e,q);
   if(h?.source==='repeat-miss-heuristic'){evidence.push(`${e.misses||0} repeated misses; cause remains ambiguous`);confidence=Math.max(confidence,.48)}
   else if(h?.type&&h.type!=='UNCLASSIFIED'){sig=ad212TypeToSignature(h.type);confidence=Math.max(confidence,Math.min(.79,+h.confidence||.6));source=h.source||'heuristic';evidence.push(h.reason||'local remediation heuristic')}
 }
 if(q.targetSec&&latest?.sec){const ratio=latest.sec/Math.max(1,q.targetSec);if(ratio>1.35){evidence.push(`solve time ${Math.round(ratio*100)}% of target`);if(sig==='UNKNOWN'){sig='TIME_PRESSURE';confidence=.72;source='timing'}}}
 if((e.misses||0)>=2)evidence.push(`${e.misses} recorded misses`);
 const formulaCandidate=typeof bestFormulaForQuestionV29==='function'?bestFormulaForQuestionV29(q):null;
 const formulaScore=formulaCandidate&&typeof rankFormulaV22==='function'?rankFormulaV22(formulaCandidate,q):(formulaCandidate?8:0);
 const formula=formulaScore>=8?formulaCandidate:null;
 const visual=typeof adaptiveVisualRecommendationV211==='function'?adaptiveVisualRecommendationV211(q):null;
 if(formula)evidence.push(`verified formula match available${Number.isFinite(formulaScore)?` · score ${formulaScore}`:''}`);
 if(visual)evidence.push(`native visual: ${visual.module.title}`);
 let route='MANUAL_DIAGNOSIS',reason='Evidence is too weak to choose a repair path automatically.';
 if(confidence>=.55&&sig!=='UNKNOWN'){
   if(sig==='CONCEPT_MODEL'){if(visual){route='VISUAL';reason='The miss points to physical/conceptual understanding and a matched native model is available.'}else if(formula){route='DERIVATION';reason='Rebuild the governing idea from assumptions through the verified derivation.'}else{route='SOURCE_REVIEW';reason='Reconstruct the governing model from the source conditions.'}}
   else if(sig==='FORMULA_SELECTION'){if(formula){route='FORMULA_RECALL';reason='The failure is choosing the governing relation, so condition-based formula recall is the shortest repair.'}else{route='SOURCE_REVIEW';reason='No sufficiently matched verified formula card exists; review the source conditions before retrying.'}}
   else if(sig==='SETUP_MODELING'){if(visual){route='VISUAL';reason='The setup error can be rebuilt spatially with the matched native model.'}else if(formula){route='DERIVATION';reason='Trace assumptions and model construction before substituting numbers.'}else{route='MICRO_DRILL';reason='Use a givens → unknown → model checklist before the next graded attempt.'}}
   else if(['SIGN_CONVENTION','UNITS_CONVERSION','ALGEBRA_MANIPULATION','CALCULATOR_EXECUTION'].includes(sig)){route='MICRO_DRILL';reason='This is an execution-layer failure; a short targeted audit is more efficient than rereading the whole concept.'}
   else if(sig==='READING_CONDITION'){route='SOURCE_REVIEW';reason='The repair should focus on givens, qualifiers, and the requested unknown before any calculation.'}
   else if(['TIME_PRESSURE','CARELESS_EXECUTION'].includes(sig)){route='DIRECT_RETRY';reason='The evidence favors execution under test conditions; use a graded retry rather than a long content detour.'}
 }
 return{signature:sig,confidence:Math.max(0,Math.min(1,confidence)),band:ad212ConfidenceBand(confidence),source,evidence:[...new Set(evidence)].slice(0,6),route,reason,formula,visual};
}
function ad212Record(qid,event,extra={}){const st=ensureAdaptiveDiagnosisStateV212();st.history.unshift({at:Date.now(),questionId:qid,event,...extra});st.history=st.history.slice(0,250);save()}
function ad212MicroChecklist(sig){
 if(sig==='SIGN_CONVENTION')return['State the positive axis / moment convention before writing equations.','Mark every force, pressure, slope, stress, or rotation direction on the sketch.','Carry signs symbolically; do not change a sign because the numerical answer “looks wrong.”','Interpret the final sign physically before selecting the choice.'];
 if(sig==='UNITS_CONVERSION')return['Write the required final unit first.','Convert all givens to one coherent unit system before substitution.','Track dimensions through the governing equation.','Do an order-of-magnitude and final-unit sanity check.'];
 if(sig==='ALGEBRA_MANIPULATION')return['Start from the accepted governing equation.','Isolate the unknown symbolically before inserting values.','Perform one transformation per line.','Substitute the result back or independently recompute the last step.'];
 if(sig==='CALCULATOR_EXECUTION')return['Confirm DEG/RAD and scientific-notation mode.','Enter grouped numerators/denominators with explicit parentheses.','Estimate the expected order of magnitude before pressing equals.','Re-enter the calculation once using a different grouping or intermediate value.'];
 return['List givens and the exact unknown.','State the governing condition/model in one line.','Solve only after the setup is internally consistent.','Sanity-check sign, units, and magnitude.'];
}
function openDiagnosticMicroDrillV212(qid,sig){const q=allQuestions().find(x=>x.id===qid);if(!q)return;ad212Record(qid,'micro-drill-open',{signature:sig});$('#modalTitle').textContent=`Focused audit · ${AD212_SIGNATURES[sig]?.short||'Repair'}`;$('#modalBody').innerHTML=`<div class="ad212-micro-note"><b>Non-graded repair.</b> Checking these boxes records no mastery and does not resolve the Error Bank item. The evidence comes from the graded retry.</div><div class="ad212-checklist">${ad212MicroChecklist(sig).map((x,i)=>`<label class="ad212-check"><input type="checkbox" data-ad212-check="${i}"><span>${esc(x)}</span></label>`).join('')}</div><div class="tiny">Problem: ${esc(String(q.question||'').slice(0,300))}</div><div class="ad212-actions"><button class="btn" data-csp-onclick="closeModal()">Close</button><button class="btn primary" data-csp-onclick="closeModal();retryOne('${qid}')">Start graded retry</button></div>`;openModal()}
function openSourceReviewV212(qid){const q=allQuestions().find(x=>x.id===qid);if(!q)return;ad212Record(qid,'source-review-open');const txt=q.solutionText||q.explanation||'';$('#modalTitle').textContent='Source-condition review';$('#modalBody').innerHTML=`<div class="ad212-micro-note"><b>Read before solving:</b> identify qualifiers, datum/reference, requested unknown, and any condition that changes the governing relation.</div><div class="listitem"><b>Question</b><div class="tiny" data-csp-style-id="s071">${esc(q.question||'')}</div></div>${Array.isArray(q.choices)?`<div class="listitem"><b>Choices</b>${q.choices.map((c,i)=>`<div class="tiny">${'ABCD'[i]||i+1}. ${esc(c)}</div>`).join('')}</div>`:''}${txt?`<div class="listitem"><b>Stored source explanation</b><div class="tiny" data-csp-style-id="s071">${esc(txt)}</div></div>`:''}<div class="ad212-actions"><button class="btn" data-csp-onclick="closeModal()">Close</button><button class="btn primary" data-csp-onclick="closeModal();retryOne('${qid}')">Start graded retry</button></div>`;openModal()}
function focusDiagnosisV212(qid){navTo('remediation');setTimeout(()=>{renderRemediationV29(qid);const s=$('#remediationDiagnosisSelectV29');if(s){s.focus();s.scrollIntoView({behavior:'smooth',block:'center'})}},0)}
function runAdaptiveInterventionV212(qid){const q=allQuestions().find(x=>x.id===qid),e=state.errors?.[qid];if(!q||!e)return;const d=adaptiveConceptDiagnosisV212(q,e);ad212Record(qid,'route-start',{signature:d.signature,route:d.route,confidence:d.confidence});if(d.route==='VISUAL'&&d.visual){startAdaptiveVisualRepairV211(qid,'diagnostic-route');return}if(d.route==='DERIVATION'&&d.formula){openImmersiveDerivationV310(d.formula.id);return}if(d.route==='FORMULA_RECALL'&&d.formula){navTo('formulas');const s=$('#formulaSearch');if(s){s.value=d.formula.name||d.formula.topic||'';renderFormulas()}return}if(d.route==='MICRO_DRILL'){openDiagnosticMicroDrillV212(qid,d.signature);return}if(d.route==='SOURCE_REVIEW'){openSourceReviewV212(qid);return}if(d.route==='DIRECT_RETRY'){retryOne(qid);return}focusDiagnosisV212(qid)}
function adaptiveDiagnosisCardHtmlV212(qid){const q=allQuestions().find(x=>x.id===qid),e=state.errors?.[qid];if(!q||!e)return'';const d=adaptiveConceptDiagnosisV212(q,e),sig=AD212_SIGNATURES[d.signature]||AD212_SIGNATURES.UNKNOWN,route=AD212_ROUTES[d.route]||AD212_ROUTES.MANUAL_DIAGNOSIS;return`<div class="ad212-card" data-ad212-card="1"><div class="ad212-head"><div><div class="ad212-kicker">Adaptive Concept Diagnosis · v2.12.0</div><h3>${esc(sig.label)}</h3><p>${esc(d.reason)}</p></div><span class="ad212-confidence ${d.band.toLowerCase()}">${d.band} · ${Math.round(d.confidence*100)}%</span></div><div class="ad212-grid"><div class="ad212-panel"><div class="ad212-kicker">Evidence used</div><div class="ad212-evidence">${d.evidence.map(x=>`<span>${esc(x)}</span>`).join('')||'<span>insufficient evidence</span>'}</div><div class="ad212-guard">Diagnosis is advisory and local. It does not alter the answer key, correctness record, mastery, or Error Bank resolution.</div></div><div class="ad212-panel"><div class="ad212-kicker">Recommended next intervention</div><div class="ad212-route">${esc(route.label)}</div><div class="tiny" data-csp-style-id="s044">${d.visual&&d.route==='VISUAL'?esc(d.visual.module.title):d.formula&&['DERIVATION','FORMULA_RECALL'].includes(d.route)?esc(d.formula.name||d.formula.topic||'Verified formula'):esc(d.reason)}</div><div class="ad212-actions"><button class="btn small primary" data-csp-onclick="runAdaptiveInterventionV212('${qid}')">${esc(route.verb)}</button><button class="btn small" data-csp-onclick="focusDiagnosisV212('${qid}')">Change diagnosis</button></div></div></div></div>`}
function injectAdaptiveDiagnosisV212(qid){const host=$('#remediationWorkbenchV29');if(!host||!qid)return;host.querySelectorAll('[data-ad212-card]').forEach(x=>x.remove());host.insertAdjacentHTML('afterbegin',adaptiveDiagnosisCardHtmlV212(qid))}
function renderErrorsAdaptiveV212(){const es=Object.values(state.errors||{}),active=es.filter(e=>!e.resolved),due=active.filter(e=>(+e.nextRetry||0)<=Date.now()),diagnosed=active.filter(e=>{const q=allQuestions().find(x=>x.id===e.questionId);return q&&adaptiveConceptDiagnosisV212(q,e).signature!=='UNKNOWN'}).length;$('#errorMetrics').innerHTML=[['Active errors',active.length],['Due now',due.length],['Diagnosed',diagnosed],['Needs diagnosis',Math.max(0,active.length-diagnosed)],['Resolved',es.filter(e=>e.resolved).length]].map(([l,k])=>`<div class="card metric"><div class="k">${k}</div><div class="l">${l}</div></div>`).join('');let rows=es.slice(),f=$('#errorFilter')?.value||'all';if(f==='due')rows=rows.filter(e=>!e.resolved&&e.nextRetry<=Date.now());if(f==='unresolved')rows=rows.filter(e=>!e.resolved);rows.sort((a,b)=>(a.resolved-b.resolved)||(b.lastMiss||0)-(a.lastMiss||0));$('#errorTable').innerHTML=rows.length?`<div class="tablewrap"><table><thead><tr><th>Question</th><th>Misses</th><th>Diagnosis</th><th>Next intervention</th><th>Retry streak</th><th>Status</th><th>Action</th></tr></thead><tbody>${rows.map(e=>{const q=allQuestions().find(x=>x.id===e.questionId);if(!q)return'';const d=adaptiveConceptDiagnosisV212(q,e),sig=AD212_SIGNATURES[d.signature]||AD212_SIGNATURES.UNKNOWN,route=AD212_ROUTES[d.route]||AD212_ROUTES.MANUAL_DIAGNOSIS;return`<tr><td><b>${esc(q.question).slice(0,150)}</b><div class="tiny">${esc(q.category)} · ${esc(q.topic||'')}</div></td><td>${e.misses||0}</td><td><div class="ad212-table-sig">${esc(sig.short)}</div><div class="tiny">${d.band} · ${Math.round(d.confidence*100)}%</div></td><td class="ad212-table-route"><b>${esc(route.label)}</b><div class="tiny">${esc(d.reason)}</div></td><td>${e.retryCorrect||0}/3</td><td>${e.resolved?'Resolved':(e.nextRetry<=Date.now()?'Due':'Scheduled')}</td><td><button class="btn small primary" data-csp-onclick="runAdaptiveInterventionV212('${q.id}')">${esc(route.verb)}</button> <button class="btn small" data-csp-onclick="retryOne('${q.id}')">Retry</button> ${e.resolved?`<button class="btn small" data-csp-onclick="reopenError('${q.id}')">Reopen</button>`:''}</td></tr>`}).join('')}</tbody></table></div>`:'<div class="empty">Your Error Bank is empty.</div>'}
function adaptiveInlineMissV212(q){if(!q||session?.mode==='mock')return;const box=$('#quizFeedback'),e=state.errors?.[q.id];if(!box||!e||box.querySelector('.ad212-inline'))return;box.querySelectorAll('.av-inline-v211').forEach(x=>x.remove());const d=adaptiveConceptDiagnosisV212(q,e),sig=AD212_SIGNATURES[d.signature]||AD212_SIGNATURES.UNKNOWN,route=AD212_ROUTES[d.route]||AD212_ROUTES.MANUAL_DIAGNOSIS;box.insertAdjacentHTML('beforeend',`<div class="ad212-inline"><b>Adaptive diagnosis · ${esc(sig.short)}</b><div class="tiny">${d.band} confidence · recommended next: <b>${esc(route.label)}</b>. ${esc(d.reason)}</div><div class="ad212-actions"><button class="btn small primary" data-csp-onclick="runAdaptiveInterventionV212('${q.id}')">${esc(route.verb)}</button><button class="btn small" data-csp-onclick="focusDiagnosisV212('${q.id}')">Review diagnosis</button></div></div>`)}
function renderAdaptiveDiagnosisSummaryV212(){const host=$('#remediationSummaryV29');if(!host)return;host.querySelectorAll('.ad212-summary').forEach(x=>x.remove());const rows=Object.values(state.errors||{}).filter(e=>!e.resolved).map(e=>{const q=allQuestions().find(x=>x.id===e.questionId);return q?adaptiveConceptDiagnosisV212(q,e):null}).filter(Boolean),counts={VISUAL:0,DERIVATION:0,FORMULA_RECALL:0,DIRECT_RETRY:0};for(const d of rows)if(counts[d.route]!=null)counts[d.route]++;host.insertAdjacentHTML('beforeend',`<div class="ad212-summary"><div><b>${counts.VISUAL}</b><span>visual-model routes</span></div><div><b>${counts.DERIVATION}</b><span>derivation routes</span></div><div><b>${counts.FORMULA_RECALL}</b><span>formula-recall routes</span></div><div><b>${counts.DIRECT_RETRY}</b><span>direct-retry routes</span></div></div>`)}
function wireAdaptiveDiagnosisV212(){ensureAdaptiveDiagnosisStateV212();
 if(typeof renderRemediationWorkbenchV29==='function'&&!renderRemediationWorkbenchV29.__adaptiveV212){const base=renderRemediationWorkbenchV29;renderRemediationWorkbenchV29=function(qid){base(qid);injectAdaptiveDiagnosisV212(qid)};renderRemediationWorkbenchV29.__adaptiveV212=true;window.renderRemediationWorkbenchV29=renderRemediationWorkbenchV29}
 if(typeof renderRemediationV29==='function'&&!renderRemediationV29.__adaptiveV212){const base=renderRemediationV29;renderRemediationV29=function(qid=null){base(qid);renderAdaptiveDiagnosisSummaryV212()};renderRemediationV29.__adaptiveV212=true;window.renderRemediationV29=renderRemediationV29}
 renderErrors=renderErrorsAdaptiveV212;window.renderErrors=renderErrorsAdaptiveV212;
 adaptiveInlineMissV211=adaptiveInlineMissV212;window.adaptiveInlineMissV211=adaptiveInlineMissV212;
 if($('#view-errors')?.classList.contains('active'))renderErrorsAdaptiveV212();if($('#view-remediation')?.classList.contains('active'))renderRemediationV29(REMED_V29?.selected||null)
}
window.adaptiveConceptDiagnosisV212=adaptiveConceptDiagnosisV212;window.runAdaptiveInterventionV212=runAdaptiveInterventionV212;window.focusDiagnosisV212=focusDiagnosisV212;window.openDiagnosticMicroDrillV212=openDiagnosticMicroDrillV212;window.openSourceReviewV212=openSourceReviewV212;window.renderErrorsAdaptiveV212=renderErrorsAdaptiveV212;
setTimeout(wireAdaptiveDiagnosisV212,30);
