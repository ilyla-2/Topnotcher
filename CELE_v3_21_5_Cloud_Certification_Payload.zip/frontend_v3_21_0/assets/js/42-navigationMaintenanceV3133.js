
(function(){
  'use strict';
  function isRegisteredViewV3133(id){return !!id && !!document.getElementById('view-'+id)}
  const prior=window.runGuidedActionV15;
  if(typeof prior==='function'){
    window.runGuidedActionV15=function(action){
      const special=new Set(['resume','import','aikey','conflicts','study','quick20','review','errors','coverage','readiness','analyze','help','bank','backup','mock']);
      if(!special.has(action)&&isRegisteredViewV3133(action))return navTo(action);
      return prior(action);
    };
  }
  window.navigateRegisteredViewV3133=function(id){return isRegisteredViewV3133(id)?navTo(id):false};
  document.title='CELE Topnotcher OS 3.13.3';
})();
