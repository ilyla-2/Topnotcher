/* CELE Topnotcher OS v3.21.0 — native-first PDF/OCR transport.
   This module transports opaque PDF/image bytes only. It does not classify questions,
   assign trust, interpret answers, or alter compiler/analytics semantics. */
(()=>{'use strict';
 const clampWidth=w=>Math.max(900,Math.min(3200,Math.round(Number(w)||2200)));
 const isLocalHttp=()=>location.protocol==='http:'&&/^(127\.0\.0\.1|localhost)$/.test(location.hostname);
 const nativeInvoke=(command,args={})=>{const invoke=window.__TAURI__?.core?.invoke;if(!invoke)return Promise.reject(Error('Native Tauri services are unavailable.'));return invoke(command,args)};
 const bytesToBase64=bytes=>{let out='';const step=0x8000;for(let i=0;i<bytes.length;i+=step)out+=String.fromCharCode(...bytes.subarray(i,Math.min(bytes.length,i+step)));return btoa(out)};
 const blobToBase64=async blob=>bytesToBase64(new Uint8Array(await blob.arrayBuffer()));
 const base64ToBlob=(s,type='application/octet-stream')=>{const raw=atob(String(s||'')),step=0x8000,parts=[];for(let i=0;i<raw.length;i+=step){const end=Math.min(raw.length,i+step),u=new Uint8Array(end-i);for(let j=i;j<end;j++)u[j-i]=raw.charCodeAt(j);parts.push(u)}return new Blob(parts,{type})};
 async function nativeStatus(){const j=await nativeInvoke('document_adapter_status');return{ok:!!j?.ok,native:true,transport:'tauri-native',rendererAvailable:!!j?.rendererAvailable,ocrAvailable:!!j?.ocrAvailable,language:j?.language||'',error:j?.error||'',backend:j?.backend||'native',version:j?.version||'3.21.0',apiVersion:j?.apiVersion||3}}
 async function legacyStatus(){const c=new AbortController(),to=setTimeout(()=>c.abort(),1800);try{const r=await fetch('/health',{cache:'no-store',signal:c.signal});if(!r.ok)throw Error(`health HTTP ${r.status}`);const j=await r.json();return{ok:!!j?.ok,native:false,transport:'legacy-http',rendererAvailable:!!j?.rendererAvailable,ocrAvailable:!!j?.ocrAvailable,language:j?.language||'',error:j?.error||'',backend:j?.backend||'legacy-local-bridge',version:j?.version||'legacy',apiVersion:1}}finally{clearTimeout(to)}}
 async function status(){
  if(window.__TAURI__?.core?.invoke){try{return await nativeStatus()}catch(e){return{ok:false,native:true,transport:'tauri-native',rendererAvailable:false,ocrAvailable:false,language:'',error:e?.message||String(e),backend:'native-unavailable',version:'3.21.0',apiVersion:3}}}
  if(isLocalHttp()){try{return await legacyStatus()}catch(e){return{ok:false,native:false,transport:'legacy-http',rendererAvailable:false,ocrAvailable:false,language:'',error:e?.message||String(e),backend:'legacy-unavailable',version:'legacy',apiVersion:1}}}
  return{ok:false,native:false,transport:'none',rendererAvailable:false,ocrAvailable:false,language:'',error:'No local PDF/OCR transport is active.',backend:'none',version:'',apiVersion:0}
 }
 async function registerPdf(blob,name='scan.pdf'){
  if(!(blob instanceof Blob)||!blob.size)throw Error('Empty PDF.');
  if(window.__TAURI__?.core?.invoke){const data=await blobToBase64(blob),j=await nativeInvoke('register_source_pdf',{data,fileName:String(name||'scan.pdf')});if(!j?.ok||!j?.id)throw Error(j?.error||'Native PDF registration failed.');return{transport:'tauri-native',token:j.id,id:j.id,pageCount:+j.pageCount||0,sha256:j.id,revision:j.revision||'',preserved:!!j.preserved}}
  if(!isLocalHttp())throw Error('No local PDF renderer is available.');
  const ctrl=new AbortController(),to=setTimeout(()=>ctrl.abort(),120000);try{const r=await fetch('/pdf/load',{method:'POST',headers:{'Content-Type':'application/pdf','X-File-Name':encodeURIComponent(name||'scan.pdf')},body:blob,signal:ctrl.signal});if(!r.ok)throw Error(`PDF renderer HTTP ${r.status}`);const j=await r.json();if(!j?.ok||!j?.token)throw Error(j?.error||'Could not cache PDF in local renderer.');return{transport:'legacy-http',token:j.token,id:'',pageCount:+j.pageCount||0,sha256:'',revision:'',preserved:false}}finally{clearTimeout(to)}
 }
 async function renderPdf(ref,page,width=2200){
  if(!ref?.token)throw Error('PDF transport token is missing.');page=Math.max(1,Math.round(Number(page)||1));width=clampWidth(width);
  if(ref.transport==='tauri-native'){const j=await nativeInvoke('render_source_pdf_page',{id:ref.token,page,width});if(!j?.ok||!j?.base64)throw Error(j?.error||'Native PDF render failed.');return{blob:base64ToBlob(j.base64,'image/png'),width:+j.width||0,height:+j.height||0,pageCount:+j.pageCount||0,mime:'image/png'}}
  if(ref.transport!=='legacy-http')throw Error('Unknown PDF transport.');
  const ctrl=new AbortController(),to=setTimeout(()=>ctrl.abort(),120000);try{const r=await fetch(`/render?token=${encodeURIComponent(ref.token)}&page=${page}&width=${width}`,{cache:'no-store',signal:ctrl.signal});if(!r.ok){let msg='';try{msg=await r.text()}catch{}throw Error(`PDF render HTTP ${r.status}${msg?': '+msg:''}`)}const blob=await r.blob();if(!blob.size)throw Error('Local PDF renderer returned an empty image.');return{blob,width:+r.headers.get('X-CELE-Page-Width')||0,height:+r.headers.get('X-CELE-Page-Height')||0,pageCount:+r.headers.get('X-CELE-Page-Count')||0,mime:'image/png'}}finally{clearTimeout(to)}
 }
 async function ocrImage(blob,label='page'){
  if(!(blob instanceof Blob)||!blob.size)throw Error('Empty OCR image.');
  if(window.__TAURI__?.core?.invoke){const data=await blobToBase64(blob),j=await nativeInvoke('ocr_image_region',{data,label:String(label||'page')});if(!j?.ok)throw Error(j?.error||'Native OCR failed.');return j}
  if(!isLocalHttp())throw Error('No local OCR backend is available.');
  const ctrl=new AbortController(),to=setTimeout(()=>ctrl.abort(),90000);try{const r=await fetch('/ocr',{method:'POST',headers:{'Content-Type':'image/png','X-Region':label},body:blob,signal:ctrl.signal});if(!r.ok)throw Error(`OCR bridge HTTP ${r.status}`);const j=await r.json();if(!j?.ok)throw Error(j?.error||'Local OCR failed.');return j}finally{clearTimeout(to)}
 }
 window.CELEDocumentIO=Object.freeze({apiVersion:3,status,registerPdf,renderPdf,ocrImage,isNative:()=>!!window.__TAURI__?.core?.invoke});
})();
