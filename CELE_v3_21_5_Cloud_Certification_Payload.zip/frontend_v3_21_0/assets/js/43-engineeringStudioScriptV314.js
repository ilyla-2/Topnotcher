


(function(){
'use strict';
document.body.classList.add('forge-ui','engineering-studio-v314');
document.title='CELE Topnotcher OS 3.13.4 · Engineering Studio';
const SETTINGS_KEY='engineeringBackdropV314';
function ensureState(){
 try{
  state.settings=state.settings||{};
  if(typeof state.settings[SETTINGS_KEY]!=='boolean')state.settings[SETTINGS_KEY]=true;
  let first=true;
  try{first=!localStorage.getItem('cele_engineering_studio_init_v314')}catch(e){first=true}
  if(first){
    state.settings.theme='dark';state.settings.accent='orange';state.settings.uiModeV20='detailed';state.settings[SETTINGS_KEY]=true;
    try{localStorage.setItem('cele_engineering_studio_init_v314','1')}catch(e){}
    if(typeof save==='function')save();
  }
 }catch(e){}
}
function backdropOn(){try{return state.settings?.[SETTINGS_KEY]!==false}catch(e){return true}}
function syncBackdropV314(){
 const on=backdropOn();document.documentElement.dataset.engineeringBackdrop=on?'on':'off';
 const b=document.querySelector('#backdropToggleV314');if(b){b.classList.toggle('is-on',on);const s=b.querySelector('.backdrop-state-v314');if(s)s.textContent=on?'On':'Off';b.setAttribute('aria-pressed',on?'true':'false')}
 const sel=document.querySelector('#settingsBackdropV314');if(sel)sel.value=on?'on':'off';
}
function setBackdropV314(on){try{state.settings[SETTINGS_KEY]=!!on;if(typeof save==='function')save()}catch(e){}syncBackdropV314()}
function ensureControlsV314(){
 const themeBtn=document.querySelector('#themeBtn');
 if(themeBtn&&!document.querySelector('#backdropToggleV314')){const b=document.createElement('button');b.className='btn theme-btn backdrop-toggle-v314';b.id='backdropToggleV314';b.type='button';b.innerHTML='<span class="theme-icon" aria-hidden="true">▧</span><span>Civil backdrop</span><span class="backdrop-state-v314">On</span>';b.onclick=()=>setBackdropV314(!backdropOn());themeBtn.after(b)}
 const appearance=document.querySelector('#view-settings .settings-card-v20');
 if(appearance&&!document.querySelector('#settingsBackdropV314')){const grid=appearance.querySelector('.formgrid');const field=document.createElement('div');field.className='field backdrop-field-v314';field.innerHTML='<label>Construction backdrop</label><select id="settingsBackdropV314"><option value="on">On — construction scene</option><option value="off">Off — clean solid workspace</option></select><div class="backdrop-note-v314">Uses the civil-construction image from the supplied v3.2 UI reference. Stored locally.</div>';grid?.append(field);field.querySelector('select').onchange=e=>setBackdropV314(e.target.value==='on')}
 syncBackdropV314();
}
ensureState();
try{if(typeof syncAppearanceFromStateV201==='function')syncAppearanceFromStateV201({persistUi:true,animate:false})}catch(e){}
ensureControlsV314();syncBackdropV314();
// Keep the toggle synchronized after backup restore/import or later appearance refreshes.
try{if(typeof syncAppearanceFromStateV201==='function'){const baseSyncV314=syncAppearanceFromStateV201;syncAppearanceFromStateV201=function(opts){const r=baseSyncV314(opts);ensureState();syncBackdropV314();return r}}}catch(e){}
try{if(typeof renderSettingsV20==='function'){const baseSettingsV314=renderSettingsV20;renderSettingsV20=function(){const r=baseSettingsV314();ensureControlsV314();syncBackdropV314();return r}}}catch(e){}
// Latest release marker in the sidebar.
const sidefoot=document.querySelector('.sidefoot');if(sidefoot&&!sidefoot.querySelector('.release-current-v314')){const r=document.createElement('div');r.className='release-row release-current-v314';r.innerHTML='<span class="release-dot"></span><span>v3.13.4 · Engineering Studio UI</span>';const first=sidefoot.querySelector('.release-row');if(first)sidefoot.insertBefore(r,first);else sidefoot.append(r)}
// Keep version text in Settings accurate without touching stored CELE data.
document.querySelectorAll('#view-settings .settings-kv-v20 b').forEach(b=>{if(/^3\.13\.[123]$/.test(b.textContent.trim()))b.textContent='3.13.4'});
const sh=document.querySelector('#view-settings .settings-hero-v20 .tiny');if(sh)sh.textContent='CELE TOPNOTCHER OS 3.13.4';
window.setEngineeringBackdropV314=setBackdropV314;
})();


(function(){
'use strict';
if(typeof renderVisualLabV210!=='function'||typeof VISUAL_REGISTRY_V210==='undefined')return;
const G={filter:'All topics',query:'',layout:'grid',selected:'hydrostatic',model:false};
const groups=[
 ['Hydrostatics',['hydrostatic','inclined-hydro','buoyancy','metacentric'],'Fluids at rest, pressure distribution, buoyancy, and stability.','≈'],
 ['Fluid Flow',['bernoulli','seepage'],'Energy, head, flow, and hydraulic gradients.','≋'],
 ['Strength of Materials',['sfd-bmd','flexure','torsion','mohr-circle','euler-buckling','truss-force','beam-deflection'],'Stress, strain, structural behavior, and stability.','⌁'],
 ['Soil Mechanics',['effective-stress'],'Soil stress and pore-water interaction.','⋮'],
 ['Surveying',['simple-curve','vertical-curve','leveling'],'Measurements, curves, levels, and positioning.','△'],
 ['Mathematics',['vector-resultant','integral-area','derivative'],'See the relationships behind the equations.','∫']
];
const skyline=`<svg viewBox="0 0 540 180" fill="none" aria-hidden="true" class="studio-skyline"><defs><linearGradient id="studioSkyV314"><stop stop-color="#ffa619" stop-opacity="0"/><stop offset=".7" stop-color="#ffa619" stop-opacity=".18"/><stop offset="1" stop-color="#ffa619" stop-opacity="0"/></linearGradient></defs><rect width="540" height="180" fill="url(#studioSkyV314)"/><g stroke="currentColor" stroke-width="2"><path d="M10 174h520M50 174V114h158v60M44 113h172M50 139h158M75 113v61m28-61v61m28-61v61m28-61v61m28-61v61M258 174V89h183v85M251 89h197M259 115h182m-182 29h182M288 89v85m30-85v85m30-85v85m30-85v85m31-85v85M123 110V27l12-8v91m-12-73h125L95 57h153m-113-30 80 30m-42-20v62m-4-2h8M367 87V9l12-7v85m-12-68h130L337 39h160m-118-30 81 30m-35-20v44m-4-1h8"/><path d="M30 174l40-42 40 42 40-42 40 42M265 174l43-57 43 57 43-57 43 57" opacity=".45"/></g></svg>`;
function uniqueSvg(m,prefix,thumb=false){
 const v=vlValuesV210(m); let s=m.svg(v,m.calc(v));
 const ids=[...s.matchAll(/\bid="([^"]+)"/g)].map(x=>x[1]);
 ids.forEach(id=>{const safe=prefix+id;s=s.replaceAll(`id="${id}"`,`id="${safe}"`).replaceAll(`url(#${id})`,`url(#${safe})`).replaceAll(`href="#${id}"`,`href="#${safe}"`).replaceAll(`xlink:href="#${id}"`,`xlink:href="#${safe}"`)});
 s=s.replace(/stop-opacity=".14"/g,'stop-opacity=".4"').replace(/stop-opacity=".42"/g,'stop-opacity=".8"');
 s=s.replace('class="vl-svg-v210"',`class="vl-svg-v210 ${thumb?'studio-thumb-svg':''}"`);
 if(thumb)s=s.replace(/<text\b[\s\S]*?<\/text>/g,'');
 return s;
}
function status(m){return ensureVisualLabStateV210().visits[m.id]?'Explored':'Not started'}
function linked(m){return(m.formulaIds||[]).find(id=>(state.formulas||[]).some(f=>f.id===id))}
function preview(id){
 G.selected=id; const m=visualModuleV210(id),f=linked(m),p=document.querySelector('#studioPreview'); if(!p)return;
 const values=vlValuesV210(m),calc=m.calc(values),results=visualLabResultsV210(m,values,calc).slice(0,2);
 p.innerHTML=`<div class="studio-preview-head"><h3>Concept Preview</h3><span class="studio-ready">● Ready to explore</span></div><div class="studio-preview-diagram"><h4>${esc(m.title)}</h4><p>${esc(m.subtitle)}</p>${uniqueSvg(m,'preview-'+m.id+'-',true)}<div class="studio-preview-values">${results.map(([v,l])=>`<div><b>${esc(v)}</b><span>${esc(l)}</span></div>`).join('')}</div><div class="studio-equation">${m.equations?.[0]?.[1]||''}</div></div><button class="btn primary studio-open" data-studio-open="${m.id}">▶ &nbsp; Open Visual</button><button class="btn studio-secondary" id="studioDerive" ${f?'':'disabled'}>▤ &nbsp; Full Derivation</button><button class="btn studio-secondary" id="studioPractice" ${f?'':'disabled'}>◫ &nbsp; Concept Practice</button>${f?'':'<p class="studio-unlinked">Derivation and practice links are not yet available for this model.</p>'}<div class="studio-benefits"><h4>Why visuals matter</h4><p><span>✓</span> See how concepts actually work</p><p><span>✓</span> Build intuition through interaction</p><p><span>✓</span> Bridge theory with real-world applications</p><p><span>✓</span> Remember faster, solve better</p></div><div class="studio-quote">“Good engineers can solve problems.<br>Great engineers can see them.”<small>TOPNOTCHER OS</small></div>`;
 if(f){p.querySelector('#studioDerive').onclick=()=>visualLabDeriveV210(f);p.querySelector('#studioPractice').onclick=()=>visualLabPracticeV210(f)}
 p.querySelector('[data-studio-open]').onclick=()=>open(id);
 document.querySelectorAll('.studio-card').forEach(c=>{const yes=c.dataset.studioId===id;c.classList.toggle('selected',yes);c.querySelector('.studio-select')?.setAttribute('aria-pressed',yes?'true':'false')});
}
function open(id){G.model=true;visualLabSelectV210(id);requestAnimationFrame(()=>document.querySelector('.vl-workspace-v210')?.scrollIntoView({behavior:'smooth',block:'start'}))}
function cards(){
 const target=document.querySelector('#studioGroups');if(!target)return;let count=0;target.classList.toggle('studio-list',G.layout==='list');
 target.innerHTML=groups.filter(g=>G.filter==='All topics'||G.filter===g[0]).map(g=>{const ms=g[1].map(id=>VISUAL_REGISTRY_V210.find(m=>m.id===id)).filter(Boolean).filter(m=>`${m.title} ${m.subtitle} ${m.category} ${g[0]}`.toLowerCase().includes(G.query.toLowerCase()));count+=ms.length;if(!ms.length)return '';return`<section class="studio-group"><div class="studio-group-head"><span class="studio-group-symbol">${g[3]}</span><div><h3>${g[0]} <small>${ms.length}</small></h3><p>${g[2]}</p></div>${G.filter==='All topics'&&ms.length>3?`<button class="studio-view-all" data-group-all="${g[0]}">View all →</button>`:''}</div><div class="studio-cards">${(G.filter==='All topics'&&!G.query?ms.slice(0,3):ms).map(m=>`<article class="studio-card ${G.selected===m.id?'selected':''}" data-studio-id="${m.id}"><button class="studio-select" aria-pressed="${G.selected===m.id}" aria-label="Preview ${esc(m.title)}" data-preview="${m.id}"><div class="studio-thumb"><span class="studio-status ${status(m)==='Explored'?'explored':''}">${status(m)==='Explored'?'✓ ':''}${status(m)}</span>${uniqueSvg(m,'thumb-'+m.id+'-',true)}</div><div class="studio-card-copy"><h4>${esc(m.title)}</h4><p>${esc(m.subtitle)}</p></div></button><div class="studio-card-actions"><button class="btn primary" data-studio-open="${m.id}">Open Visual <span>↗</span></button><span class="studio-category">${m.category}</span></div></article>`).join('')}</div></section>`}).join('')||'<div class="studio-empty"><h3>No matching concepts</h3><p>Try a broader keyword or choose All topics.</p><button class="btn" id="studioClear">Clear search & filters</button></div>';
 const countEl=document.querySelector('#studioCount');if(countEl)countEl.textContent=`${count} native models`;
 target.querySelectorAll('[data-group-all]').forEach(b=>b.onclick=()=>{G.filter=b.dataset.groupAll;renderVisualLabV210()});
 target.querySelectorAll('[data-preview]').forEach(b=>b.onclick=()=>preview(b.dataset.preview));
 target.querySelectorAll('[data-studio-open]').forEach(b=>b.onclick=()=>open(b.dataset.studioOpen));
 const clear=target.querySelector('#studioClear');if(clear)clear.onclick=()=>{G.query='';G.filter='All topics';renderVisualLabV210();document.querySelector('#studioSearch')?.focus()};
}
const baseRenderVisualLabV314=renderVisualLabV210;
renderVisualLabV210=function(){
 baseRenderVisualLabV314();const host=document.querySelector('#visualLabV210');if(!host)return;
 host.classList.add('studio-enabled');host.classList.toggle('studio-model-mode',G.model);
 const m=visualModuleV210(G.selected),featured=visualModuleV210('hydrostatic');const gallery=document.createElement('div');gallery.id='studioGallery';
 gallery.innerHTML=`<div class="studio-toolbar"><div><p class="studio-eyebrow">PRACTICE / VISUAL LAB</p><h2>Visual Concept Lab</h2><p>Interactive visual intuition for hard CELE concepts.</p></div><div class="studio-search-tools"><div class="studio-layout" role="group" aria-label="Concept layout"><button data-layout="grid" class="${G.layout==='grid'?'active':''}" aria-pressed="${G.layout==='grid'}">▦ Grid</button><button data-layout="list" class="${G.layout==='list'?'active':''}" aria-pressed="${G.layout==='list'}">☷ List</button></div><label class="studio-search"><span aria-hidden="true">⌕</span><input id="studioSearch" type="search" placeholder="Search concepts, topics, or keywords…" aria-label="Search visual concepts" value="${esc(G.query)}"><kbd>Ctrl K</kbd></label><div class="studio-save-v314"><i></i><span>${esc(document.querySelector('#saveStateLabel')?.textContent||'Saved locally')}</span></div></div></div><div class="studio-feature">${skyline}<div class="studio-feature-icon"><svg viewBox="0 0 40 50" aria-hidden="true" fill="none" stroke="currentColor" stroke-width="2"><path d="M20 3C18 14 5 24 5 33a15 15 0 0 0 30 0C35 24 22 14 20 3Z"/><path d="M12 31q-2 10 8 11"/></svg></div><div class="studio-feature-copy"><span class="studio-eyebrow">FEATURED CONCEPT</span><h3>${esc(featured.title)}</h3><p>${esc(featured.subtitle)}</p><div class="studio-feature-tags"><span>✓ Interactive diagram</span><span>✓ Step-by-step derivation</span><span>✓ Practice problems</span></div></div><button class="btn primary" id="studioFeatured">Open Visual &nbsp; →</button></div><div class="studio-browser"><div class="studio-library"><div class="studio-filters" role="group" aria-label="Filter visual concepts">${['All topics',...groups.map(g=>g[0])].map(g=>`<button class="${G.filter===g?'active':''}" data-filter="${g}" aria-pressed="${G.filter===g}">${g}</button>`).join('')}</div><div class="studio-catalogue-meta"><span id="studioCount"></span><span>Explore → derive → practice</span></div><div id="studioGroups"></div></div><aside id="studioPreview" aria-label="Selected concept"></aside></div><div class="studio-model-nav"><button class="btn" id="studioBack">← Back to concept gallery</button><span>Change the variables below to explore the model.</span></div>`;
 host.prepend(gallery);
 gallery.querySelector('#studioFeatured').onclick=()=>open(featured.id);
 gallery.querySelector('#studioBack').onclick=()=>{G.model=false;renderVisualLabV210();window.scrollTo({top:0,behavior:'smooth'})};
 gallery.querySelectorAll('[data-filter]').forEach(b=>b.onclick=()=>{G.filter=b.dataset.filter;gallery.querySelectorAll('[data-filter]').forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-pressed',x===b?'true':'false')});cards()});
 gallery.querySelectorAll('[data-layout]').forEach(b=>b.onclick=()=>{G.layout=b.dataset.layout;gallery.querySelectorAll('[data-layout]').forEach(x=>{x.classList.toggle('active',x===b);x.setAttribute('aria-pressed',x===b?'true':'false')});cards()});
 gallery.querySelector('#studioSearch').oninput=e=>{G.query=e.target.value;cards()};
 const practice=document.querySelector('[data-cluster="practice"]');if(practice){practice.classList.remove('open');practice.querySelector('.nav-parent')?.setAttribute('aria-expanded','false')}
 cards();preview(m.id);
};
// Visual Lab is a first-class navigation destination, matching the v3.2 reference.
try{if(typeof NAV_V13!=='undefined'&&NAV_V13.groups?.practice)NAV_V13.groups.practice=NAV_V13.groups.practice.filter(v=>v!=='visuallab')}catch{}
try{if(typeof navTo==='function'){const navToStudioBaseV314=navTo;navTo=function(v){if(v==='visuallab'&&typeof NAV_V13!=='undefined'&&NAV_V13.groups?.practice){NAV_V13.groups.practice=NAV_V13.groups.practice.filter(x=>x!=='visuallab');NAV_V13.openGroup=null}return navToStudioBaseV314(v)}}}catch{}
const leaf=document.querySelector('.nav [data-view="visuallab"]');
if(leaf){
 leaf.innerHTML='<span class="nav-icon"><svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="4" width="18" height="16" rx="3"/><path d="m5 17 5-6 4 4 3-3 4 5"/><circle cx="16" cy="8" r="1"/></svg></span><span class="nav-text">Visual Lab</span>';
 const wrap=document.createElement('div');wrap.className='nav-direct studio-direct-v314';wrap.append(leaf);const progress=document.querySelector('[data-cluster="progress"]');progress?.after(wrap);
 const practice=document.querySelector('[data-cluster="practice"]');const count=practice?.querySelectorAll('.nav-children .nav-leaf').length;const badge=practice?.querySelector('.nav-count');if(badge&&count!=null)badge.textContent=String(count);
}
if(!document.querySelector('.studio-sidebar-art')){const foot=document.createElement('div');foot.className='studio-sidebar-art';foot.innerHTML=skyline+'<p>Build understanding today.<br>Engineer a better tomorrow.</p><i></i>';document.querySelector('.sidefoot')?.before(foot)}
const oldSelectV314=visualLabSelectV210;visualLabSelectV210=function(id){G.selected=id;G.model=true;return oldSelectV314(id)};
if(document.querySelector('#view-visuallab.active'))renderVisualLabV210();
window.STUDIO_V314=G;
})();


