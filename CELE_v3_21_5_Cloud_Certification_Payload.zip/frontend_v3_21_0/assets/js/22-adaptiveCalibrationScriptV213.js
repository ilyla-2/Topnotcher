
/* v2.13.0 · Diagnosis Calibration & Repair Outcomes
   Descriptive calibration only. This layer observes already-graded attempts and never
   grades answers, awards mastery, changes answer keys, resolves errors, or predicts CELE outcomes. */
const AD213_OUTCOMES={
 INSUFFICIENT:{label:'Insufficient evidence',short:'Pending evidence'},
 TENTATIVE_HELP:{label:'Tentatively helped',short:'Tentative +'},
 POSITIVE_PATTERN:{label:'Positive outcome evidence',short:'Positive'},
 MIXED:{label:'Mixed outcome',short:'Mixed'},
 DID_NOT_HELP_YET:{label:'Did not help yet',short:'Not yet'}
};
const AD213_RUNTIME={retrograde:false};
const AD213_CALIBRATION={
 INSUFFICIENT:{label:'Insufficient evidence',tone:'muted'},
 POSITIVE:{label:'Positive recent signal',tone:'good'},
 MIXED:{label:'Mixed recent outcomes',tone:'warn'},
 WEAK:{label:'Weak recent signal',tone:'bad'}
};
function ensureAdaptiveCalibrationStateV213(){
 state.adaptiveCalibrationV213=state.adaptiveCalibrationV213&&typeof state.adaptiveCalibrationV213==='object'?state.adaptiveCalibrationV213:{schema:1,episodes:[]};
 const st=state.adaptiveCalibrationV213;st.schema=1;st.episodes=Array.isArray(st.episodes)?st.episodes:[];return st;
}
function ad213Norm(x){return String(x||'').trim().toLowerCase().replace(/\s+/g,' ')}
function ad213FormulaMatch(q){
 if(!q||!Array.isArray(state.formulas)||typeof rankFormulaV22!=='function')return null;
 const hit=state.formulas.map(f=>({f,s:rankFormulaV22(f,q)})).sort((a,b)=>b.s-a.s)[0];
 return hit&&hit.s>=8?hit:null;
}
function ad213ConceptInfo(q){
 if(!q)return{key:'unknown',label:'Unknown concept',category:''};
 const fm=ad213FormulaMatch(q);if(fm)return{key:`formula:${fm.f.id}`,label:fm.f.name||fm.f.topic||q.topic||'Verified concept',category:q.category||'',formulaId:fm.f.id};
 const vr=typeof adaptiveVisualRecommendationV211==='function'?adaptiveVisualRecommendationV211(q):null;
 if(vr?.module)return{key:`visual:${vr.module.id}`,label:vr.module.title||q.topic||'Visual concept',category:q.category||'',visualId:vr.module.id};
 const cat=ad213Norm(q.category)||'general',sub=ad213Norm(q.subject)||'general',topic=ad213Norm(q.topic)||'general';
 return{key:`topic:${cat}|${sub}|${topic}`,label:[q.subject,q.topic].filter(Boolean).join(' · ')||q.category||'General concept',category:q.category||''};
}
function ad213OutcomeForEpisode(ep){
 const a=Array.isArray(ep?.gradedAttempts)?ep.gradedAttempts.filter(x=>x&&x.graded===true):[];
 if(!a.length)return{code:'INSUFFICIENT',...AD213_OUTCOMES.INSUFFICIENT,evidence:0};
 const c=a.filter(x=>x.correct===true).length,w=a.filter(x=>x.correct===false).length;
 if(c&&w)return{code:'MIXED',...AD213_OUTCOMES.MIXED,evidence:a.length};
 if(c===1&&a.length===1)return{code:'TENTATIVE_HELP',...AD213_OUTCOMES.TENTATIVE_HELP,evidence:1};
 if(c>=2&&!w)return{code:'POSITIVE_PATTERN',...AD213_OUTCOMES.POSITIVE_PATTERN,evidence:a.length};
 return{code:'DID_NOT_HELP_YET',...AD213_OUTCOMES.DID_NOT_HELP_YET,evidence:a.length};
}
function ad213EpisodeStrength(ep){const n=ad213OutcomeForEpisode(ep).evidence;return n>=3?'HIGH':n>=2?'MEDIUM':n>=1?'LOW':'NONE'}
function ad213RelevantEpisodes({questionId=null,conceptKey=null,signature=null,route=null,observedOnly=false}={}){
 return ensureAdaptiveCalibrationStateV213().episodes.filter(ep=>{
  if(questionId&&ep.originQuestionId!==questionId)return false;if(conceptKey&&ep.conceptKey!==conceptKey)return false;
  if(signature&&ep.signature!==signature)return false;if(route&&ep.route!==route)return false;
  if(observedOnly&&!ad213OutcomeForEpisode(ep).evidence)return false;return true;
 });
}
function ad213Aggregate({conceptKey=null,signature=null,route=null}={}){
 const eps=ad213RelevantEpisodes({conceptKey,signature,route,observedOnly:true});let positive=0,negative=0,mixed=0,attempts=0;
 for(const ep of eps){const o=ad213OutcomeForEpisode(ep);attempts+=o.evidence;if(['TENTATIVE_HELP','POSITIVE_PATTERN'].includes(o.code))positive++;else if(o.code==='MIXED')mixed++;else if(o.code==='DID_NOT_HELP_YET')negative++}
 const n=eps.length,rate=n?(positive+.5*mixed)/n:0;let code='INSUFFICIENT';
 if(n>=3){if(rate>=.70)code='POSITIVE';else if(rate<=.30)code='WEAK';else code='MIXED'}
 return{episodes:n,positive,negative,mixed,gradedAttempts:attempts,positiveRate:rate,code,label:AD213_CALIBRATION[code].label,tone:AD213_CALIBRATION[code].tone};
}
function ad213OpenEpisodeFor(qid,signature,route){
 const now=Date.now();return ensureAdaptiveCalibrationStateV213().episodes.slice().reverse().find(ep=>ep.originQuestionId===qid&&ep.signature===signature&&ep.route===route&&!ep.closedAt&&now-(ep.startedAt||0)<12*3600000)||null;
}
function ad213BeginEpisode(q,d,source='adaptive-route'){
 if(!q||!d||!d.route||d.route==='MANUAL_DIAGNOSIS')return null;const st=ensureAdaptiveCalibrationStateV213(),ci=ad213ConceptInfo(q);
 let ep=ad213OpenEpisodeFor(q.id,d.signature,d.route);if(ep){ep.routeStarts=(ep.routeStarts||1)+1;ep.lastRouteStartAt=Date.now();ep.source=source;save();return ep}
 // A newer intervention on the same origin supersedes an unfinished older one, but does not count as failure.
 for(const old of st.episodes){if(old.originQuestionId===q.id&&!old.closedAt&&old.route!==d.route){old.closedAt=Date.now();old.closeReason='superseded';old.outcome='INSUFFICIENT'}}
 const p=getProgress(q.id),e=state.errors?.[q.id]||{};ep={id:uid('RPE'),schema:1,originQuestionId:q.id,conceptKey:ci.key,conceptLabel:ci.label,category:q.category||'',subject:q.subject||'',topic:q.topic||'',signature:d.signature,diagnosisConfidence:d.confidence,diagnosisBand:d.band,recommendedRoute:d.route,route:d.route,source,startedAt:Date.now(),lastRouteStartAt:Date.now(),routeStarts:1,interventionEngagedAt:Date.now(),baseline:{attempts:p.attempts||0,correct:p.correct||0,incorrect:p.incorrect||0,misses:e.misses||0,retryCorrect:e.retryCorrect||0},gradedAttempts:[],closedAt:null,closeReason:null,outcome:'INSUFFICIENT'};
 st.episodes.push(ep);if(st.episodes.length>500)st.episodes=st.episodes.slice(-500);save();return ep;
}
function ad213LatestEpisode(qid){return ensureAdaptiveCalibrationStateV213().episodes.filter(ep=>ep.originQuestionId===qid).sort((a,b)=>(b.startedAt||0)-(a.startedAt||0))[0]||null}
function ad213CandidateEpisodesForAttempt(q){
 if(!q)return[];const ci=ad213ConceptInfo(q),now=Date.now();return ensureAdaptiveCalibrationStateV213().episodes.filter(ep=>!ep.closedAt&&now-(ep.startedAt||0)<7*86400000&&(ep.originQuestionId===q.id||ep.conceptKey===ci.key)).sort((a,b)=>(b.startedAt||0)-(a.startedAt||0));
}
function ad213ObserveGradedAttempt(q,correct,sec){
 if(!q||typeof correct!=='boolean'||AD213_RUNTIME.retrograde||!session||session.mode==='mock')return null;const ep=ad213CandidateEpisodesForAttempt(q)[0];if(!ep)return null;
 // DIRECT_RETRY is deliberately tied to the original item; other interventions may use a same-concept transfer item.
 if(ep.route==='DIRECT_RETRY'&&q.id!==ep.originQuestionId)return null;
 const now=Date.now();if(now<(ep.startedAt||0))return null;ep.gradedAttempts=Array.isArray(ep.gradedAttempts)?ep.gradedAttempts:[];
 // recordAnswer can be wrapped by other layers; dedupe rapid duplicate notifications.
 const prev=ep.gradedAttempts.at(-1);if(prev&&prev.questionId===q.id&&prev.correct===correct&&now-(prev.at||0)<1000)return ep;
 ep.gradedAttempts.push({questionId:q.id,at:now,graded:true,correct:!!correct,sec:+sec||0,isOrigin:q.id===ep.originQuestionId,kind:q.id===ep.originQuestionId?'retry':'transfer'});
 const out=ad213OutcomeForEpisode(ep);ep.outcome=out.code;ep.lastOutcomeAt=now;
 const visualCycle=ep.route==='VISUAL'&&state.adaptiveVisualV211?.active?.questionId===ep.originQuestionId;
 if(correct||!visualCycle){ep.closedAt=now;ep.closeReason=correct?'graded-positive':'graded-negative'}
 save();return ep;
}
function ad213CloseVisualEpisode(qid,reason='visual-cycle-closed'){
 const ep=ensureAdaptiveCalibrationStateV213().episodes.slice().reverse().find(x=>x.originQuestionId===qid&&x.route==='VISUAL'&&!x.closedAt);if(!ep)return;ep.closedAt=Date.now();ep.closeReason=reason;ep.outcome=ad213OutcomeForEpisode(ep).code;save();
}
function ad213RouteStatsForDiagnosis(q,d){const ci=ad213ConceptInfo(q);return ad213Aggregate({conceptKey:ci.key,signature:d.signature,route:d.route})}
function ad213AlternativeRoute(q,d){
 const ci=ad213ConceptInfo(q),available=route=>{if(route==='VISUAL')return!!d.visual;if(['DERIVATION','FORMULA_RECALL'].includes(route))return!!d.formula;return true},routes=Object.keys(AD212_ROUTES||{}).filter(r=>r!=='MANUAL_DIAGNOSIS'&&r!==d.route&&available(r)),base=ad213Aggregate({conceptKey:ci.key,signature:d.signature,route:d.route});if(base.episodes<3||base.positiveRate>.30)return null;
 const candidates=routes.map(route=>({route,stats:ad213Aggregate({conceptKey:ci.key,signature:d.signature,route})})).filter(x=>x.stats.episodes>=3&&x.stats.positiveRate>=.70&&x.stats.positiveRate-base.positiveRate>=.30).sort((a,b)=>b.stats.positiveRate-a.stats.positiveRate||b.stats.episodes-a.stats.episodes);
 return candidates[0]||null;
}
function calibratedDiagnosisV213(q,e){
 const d=AD213_BASE_DIAG(q,e),stats=ad213RouteStatsForDiagnosis(q,d),alt=ad213AlternativeRoute(q,d),calibration={stats,applied:false,note:stats.episodes?`${stats.label} from ${stats.episodes} prior observed repair episode${stats.episodes===1?'':'s'}.`:'No prior observed repair outcome for this route/concept yet.'};
 if(alt&&d.confidence>=.62){calibration.applied=true;calibration.originalRoute=d.route;calibration.note=`Prior local repair outcomes weakly favor ${AD212_ROUTES[alt.route]?.label||alt.route} over ${AD212_ROUTES[d.route]?.label||d.route}; this adjustment requires at least 3 observed episodes per route.`;return{...d,route:alt.route,reason:`${d.reason} ${calibration.note}`,calibration}}
 return{...d,calibration};
}
function ad213OutcomeChip(out){const cls=out.code==='POSITIVE_PATTERN'||out.code==='TENTATIVE_HELP'?'good':out.code==='DID_NOT_HELP_YET'?'bad':out.code==='MIXED'?'warn':'muted';return`<span class="ad213-outcome ${cls}">${esc(out.label)}</span>`}
function ad213OutcomeCardHtml(qid){
 const q=allQuestions().find(x=>x.id===qid);if(!q)return'';const ep=ad213LatestEpisode(qid),d=adaptiveConceptDiagnosisV212(q,state.errors?.[qid]);const ci=ad213ConceptInfo(q),route=d?.route||ep?.route||null;
 const stats=route?ad213Aggregate({conceptKey:ci.key,signature:d?.signature||ep?.signature,route}):ad213Aggregate({conceptKey:ci.key});
 if(!ep&&!stats.episodes)return`<div class="ad213-card" data-ad213-card="1"><div class="ad213-head"><div><div class="ad213-kicker">Repair outcomes · v2.13.0</div><h3>No outcome evidence yet</h3><p>Start the recommended intervention, then complete a normal graded retry or transfer problem. CELE OS will observe that result without adding any extra mastery credit.</p></div>${ad213OutcomeChip(AD213_OUTCOMES.INSUFFICIENT?{code:'INSUFFICIENT',...AD213_OUTCOMES.INSUFFICIENT}:ad213OutcomeForEpisode({}))}</div><div class="ad213-guard">Outcome calibration is descriptive local evidence, not proof that an intervention caused improvement and not a CELE score/pass prediction.</div></div>`;
 const out=ep?ad213OutcomeForEpisode(ep):{code:'INSUFFICIENT',...AD213_OUTCOMES.INSUFFICIENT,evidence:0},routeLabel=AD212_ROUTES[ep?.route||route]?.label||ep?.route||route||'—';
 return`<div class="ad213-card" data-ad213-card="1"><div class="ad213-head"><div><div class="ad213-kicker">Repair outcomes · v2.13.0</div><h3>${ep?esc(routeLabel):'Concept calibration'}</h3><p>${ep?`${esc(out.label)} after ${out.evidence} linked graded follow-up${out.evidence===1?'':'s'}.`:'No question-specific episode yet; showing concept-level history.'}</p></div>${ad213OutcomeChip(out)}</div><div class="ad213-grid"><div class="ad213-panel"><div class="ad213-kicker">Latest episode</div>${ep?`<div class="ad213-route">${esc(AD212_SIGNATURES[ep.signature]?.short||ep.signature)} → ${esc(routeLabel)}</div><div class="tiny">Started ${new Date(ep.startedAt).toLocaleString()} · ${ep.gradedAttempts?.length||0} graded follow-up${(ep.gradedAttempts?.length||0)===1?'':'s'} · evidence strength ${ad213EpisodeStrength(ep)}</div>`:'<div class="tiny">No intervention episode has been started for this mistake.</div>'}</div><div class="ad213-panel"><div class="ad213-kicker">Same concept + diagnosis + route</div><div class="ad213-route">${esc(stats.label)}</div><div class="tiny">${stats.episodes} observed episode${stats.episodes===1?'':'s'} · ${stats.positive} positive · ${stats.mixed} mixed · ${stats.negative} not-yet-positive</div>${stats.episodes>=3?`<div class="ad213-meter"><span data-csp-style="width:${Math.round(stats.positiveRate*100)}%"></span></div><div class="tiny">Descriptive positive follow-up index: ${Math.round(stats.positiveRate*100)}%</div>`:'<div class="tiny" data-csp-style-id="s028">At least 3 observed episodes are required before CELE OS treats this as a calibration signal.</div>'}</div></div><div class="ad213-guard">These outcomes are observational. The intervention never grants correctness/mastery, and calibration only changes routing when repeated local evidence is strong enough.</div></div>`;
}
function injectAdaptiveCalibrationV213(qid){const host=$('#remediationWorkbenchV29');if(!host||!qid)return;host.querySelectorAll('[data-ad213-card]').forEach(x=>x.remove());const diag=host.querySelector('[data-ad212-card]');if(diag)diag.insertAdjacentHTML('afterend',ad213OutcomeCardHtml(qid));else host.insertAdjacentHTML('afterbegin',ad213OutcomeCardHtml(qid))}
function ad213LatestOutcomeForQuestion(qid){const ep=ad213LatestEpisode(qid);return ep?ad213OutcomeForEpisode(ep):{code:'INSUFFICIENT',...AD213_OUTCOMES.INSUFFICIENT,evidence:0}}
function renderErrorsAdaptiveV213(){
 const es=Object.values(state.errors||{}),active=es.filter(e=>!e.resolved),due=active.filter(e=>(+e.nextRetry||0)<=Date.now()),diagnosed=active.filter(e=>{const q=allQuestions().find(x=>x.id===e.questionId);return q&&adaptiveConceptDiagnosisV212(q,e).signature!=='UNKNOWN'}).length,observed=es.filter(e=>ad213LatestOutcomeForQuestion(e.questionId).evidence>0).length;
 $('#errorMetrics').innerHTML=[['Active errors',active.length],['Due now',due.length],['Diagnosed',diagnosed],['Outcome observed',observed],['Resolved',es.filter(e=>e.resolved).length]].map(([l,k])=>`<div class="card metric"><div class="k">${k}</div><div class="l">${l}</div></div>`).join('');let rows=es.slice(),f=$('#errorFilter')?.value||'all';if(f==='due')rows=rows.filter(e=>!e.resolved&&e.nextRetry<=Date.now());if(f==='unresolved')rows=rows.filter(e=>!e.resolved);rows.sort((a,b)=>(a.resolved-b.resolved)||(b.lastMiss||0)-(a.lastMiss||0));
 $('#errorTable').innerHTML=rows.length?`<div class="tablewrap"><table><thead><tr><th>Question</th><th>Misses</th><th>Diagnosis</th><th>Next intervention</th><th>Repair outcome</th><th>Retry streak</th><th>Status</th><th>Action</th></tr></thead><tbody>${rows.map(e=>{const q=allQuestions().find(x=>x.id===e.questionId);if(!q)return'';const d=adaptiveConceptDiagnosisV212(q,e),sig=AD212_SIGNATURES[d.signature]||AD212_SIGNATURES.UNKNOWN,route=AD212_ROUTES[d.route]||AD212_ROUTES.MANUAL_DIAGNOSIS,out=ad213LatestOutcomeForQuestion(q.id),ep=ad213LatestEpisode(q.id);return`<tr><td><b>${esc(q.question).slice(0,150)}</b><div class="tiny">${esc(q.category)} · ${esc(q.topic||'')}</div></td><td>${e.misses||0}</td><td><div class="ad212-table-sig">${esc(sig.short)}</div><div class="tiny">${d.band} · ${Math.round(d.confidence*100)}%</div></td><td class="ad212-table-route"><b>${esc(route.label)}</b><div class="tiny">${esc(d.calibration?.note||d.reason)}</div></td><td>${ad213OutcomeChip(out)}<div class="tiny" data-csp-style-id="s064">${ep?.gradedAttempts?.length||0} linked graded follow-up${(ep?.gradedAttempts?.length||0)===1?'':'s'}</div></td><td>${e.retryCorrect||0}/3</td><td>${e.resolved?'Resolved':(e.nextRetry<=Date.now()?'Due':'Scheduled')}</td><td><button class="btn small primary" data-csp-onclick="runAdaptiveInterventionV212('${q.id}')">${esc(route.verb)}</button> <button class="btn small" data-csp-onclick="retryOne('${q.id}')">Retry</button> ${e.resolved?`<button class="btn small" data-csp-onclick="reopenError('${q.id}')">Reopen</button>`:''}</td></tr>`}).join('')}</tbody></table></div>`:'<div class="empty">Your Error Bank is empty.</div>';
}
function renderCalibrationSummaryV213(){const host=$('#remediationSummaryV29');if(!host)return;host.querySelectorAll('.ad213-summary').forEach(x=>x.remove());host.querySelectorAll('.ad212-summary').forEach(x=>x.remove());const eps=ensureAdaptiveCalibrationStateV213().episodes,observed=eps.filter(ep=>ad213OutcomeForEpisode(ep).evidence),positive=observed.filter(ep=>['TENTATIVE_HELP','POSITIVE_PATTERN'].includes(ad213OutcomeForEpisode(ep).code)),pending=eps.filter(ep=>!ad213OutcomeForEpisode(ep).evidence&&!ep.closedAt),active=Object.values(state.errors||{}).filter(e=>!e.resolved),routeCounts={VISUAL:0,DERIVATION:0,FORMULA_RECALL:0,DIRECT_RETRY:0};for(const e of active){const q=allQuestions().find(x=>x.id===e.questionId);if(!q)continue;const d=adaptiveConceptDiagnosisV212(q,e);if(routeCounts[d.route]!=null)routeCounts[d.route]++}host.insertAdjacentHTML('beforeend',`<div class="ad213-summary"><div><b>${eps.length}</b><span>repair episodes</span></div><div><b>${observed.length}</b><span>with graded outcomes</span></div><div><b>${positive.length}</b><span>positive follow-ups</span></div><div><b>${pending.length}</b><span>awaiting evidence</span></div><div class="ad213-route-mix">Current route mix · visual ${routeCounts.VISUAL} · derivation ${routeCounts.DERIVATION} · formula recall ${routeCounts.FORMULA_RECALL} · direct retry ${routeCounts.DIRECT_RETRY}</div></div>`)}
function ad213WrapRouting(){
 if(typeof retrogradeCompletedSet==='function'&&!retrogradeCompletedSet.__calibrationV213){const base=retrogradeCompletedSet;retrogradeCompletedSet=function(setId){AD213_RUNTIME.retrograde=true;try{return base(setId)}finally{AD213_RUNTIME.retrograde=false}};retrogradeCompletedSet.__calibrationV213=true;window.retrogradeCompletedSet=retrogradeCompletedSet}
 if(typeof runAdaptiveInterventionV212==='function'&&!runAdaptiveInterventionV212.__calibrationV213){const base=runAdaptiveInterventionV212;runAdaptiveInterventionV212=function(qid){const q=allQuestions().find(x=>x.id===qid),e=state.errors?.[qid],d=q&&e?adaptiveConceptDiagnosisV212(q,e):null;if(q&&d&&d.route!=='MANUAL_DIAGNOSIS')ad213BeginEpisode(q,d,'adaptive-route');return base(qid)};runAdaptiveInterventionV212.__calibrationV213=true;window.runAdaptiveInterventionV212=runAdaptiveInterventionV212}
 if(typeof recordAnswer==='function'&&!recordAnswer.__calibrationV213){const base=recordAnswer;recordAnswer=function(q,correct,sec){const out=base(q,correct,sec);ad213ObserveGradedAttempt(q,correct,sec);return out};recordAnswer.__calibrationV213=true;window.recordAnswer=recordAnswer}
 if(typeof adaptiveTrackControlV211==='function'&&!adaptiveTrackControlV211.__calibrationV213){const base=adaptiveTrackControlV211;adaptiveTrackControlV211=function(id,key){const a=state.adaptiveVisualV211?.active,ep=a?ensureAdaptiveCalibrationStateV213().episodes.slice().reverse().find(x=>x.originQuestionId===a.questionId&&x.route==='VISUAL'&&!x.closedAt):null;if(ep&&!ep.firstManipulationAt)ep.firstManipulationAt=Date.now();const out=base(id,key);if(ep)save();return out};adaptiveTrackControlV211.__calibrationV213=true;window.adaptiveTrackControlV211=adaptiveTrackControlV211}
 if(typeof cancelAdaptiveVisualV211==='function'&&!cancelAdaptiveVisualV211.__calibrationV213){const base=cancelAdaptiveVisualV211;cancelAdaptiveVisualV211=function(){const qid=state.adaptiveVisualV211?.active?.questionId,out=base();if(qid)ad213CloseVisualEpisode(qid,'visual-cycle-cancelled');return out};cancelAdaptiveVisualV211.__calibrationV213=true;window.cancelAdaptiveVisualV211=cancelAdaptiveVisualV211}
 if(typeof finishAdaptiveVisualCycleV211==='function'&&!finishAdaptiveVisualCycleV211.__calibrationV213){const base=finishAdaptiveVisualCycleV211;finishAdaptiveVisualCycleV211=function(){const qid=state.adaptiveVisualV211?.active?.questionId,out=base();if(qid)ad213CloseVisualEpisode(qid,'visual-cycle-finished');return out};finishAdaptiveVisualCycleV211.__calibrationV213=true;window.finishAdaptiveVisualCycleV211=finishAdaptiveVisualCycleV211}
}
function wireAdaptiveCalibrationV213(){
 ensureAdaptiveCalibrationStateV213();
 // Wrap v2.12 diagnosis so local outcome history may influence routing only after conservative sample gates.
 if(typeof adaptiveConceptDiagnosisV212==='function'&&!adaptiveConceptDiagnosisV212.__calibrationV213){AD213_BASE_DIAG=adaptiveConceptDiagnosisV212;adaptiveConceptDiagnosisV212=function(q,e){return calibratedDiagnosisV213(q,e)};adaptiveConceptDiagnosisV212.__calibrationV213=true;window.adaptiveConceptDiagnosisV212=adaptiveConceptDiagnosisV212}
 ad213WrapRouting();
 if(typeof renderRemediationWorkbenchV29==='function'&&!renderRemediationWorkbenchV29.__calibrationV213){const base=renderRemediationWorkbenchV29;renderRemediationWorkbenchV29=function(qid){base(qid);injectAdaptiveCalibrationV213(qid)};renderRemediationWorkbenchV29.__calibrationV213=true;window.renderRemediationWorkbenchV29=renderRemediationWorkbenchV29}
 if(typeof renderRemediationV29==='function'&&!renderRemediationV29.__calibrationV213){const base=renderRemediationV29;renderRemediationV29=function(qid=null){base(qid);renderCalibrationSummaryV213()};renderRemediationV29.__calibrationV213=true;window.renderRemediationV29=renderRemediationV29}
 renderErrors=renderErrorsAdaptiveV213;window.renderErrors=renderErrorsAdaptiveV213;
 if($('#view-errors')?.classList.contains('active'))renderErrorsAdaptiveV213();if($('#view-remediation')?.classList.contains('active'))renderRemediationV29(REMED_V29?.selected||null);
}
let AD213_BASE_DIAG=null;
window.ensureAdaptiveCalibrationStateV213=ensureAdaptiveCalibrationStateV213;window.ad213Aggregate=ad213Aggregate;window.ad213OutcomeForEpisode=ad213OutcomeForEpisode;window.ad213BeginEpisode=ad213BeginEpisode;window.ad213ObserveGradedAttempt=ad213ObserveGradedAttempt;window.renderErrorsAdaptiveV213=renderErrorsAdaptiveV213;window.injectAdaptiveCalibrationV213=injectAdaptiveCalibrationV213;
setTimeout(wireAdaptiveCalibrationV213,90);

