/* CELE Topnotcher OS v3.21.0 — opt-in Tauri desktop API adapter. */
(()=>{'use strict';
 const call=(command,args={})=>{const invoke=window.__TAURI__?.core?.invoke;if(!invoke)return Promise.reject(Error('Desktop services require the native Tauri shell.'));return invoke(command,args)};
 window.CELEDesktop=Object.freeze({
  apiVersion:3,
  status:()=>call('desktop_status'),
  documentStatus:()=>call('document_adapter_status'),
  registerSourcePdf:(data,fileName='scan.pdf')=>call('register_source_pdf',{data,fileName}),
  renderSourcePdfPage:(id,page,width=2200)=>call('render_source_pdf_page',{id,page,width}),
  ocrImageRegion:(data,label='page')=>call('ocr_image_region',{data,label}),
  checkpoint:(records,expectedRevision)=>call('save_checkpoint',{records,expectedRevision}),
  readCheckpoint:()=>call('read_checkpoint'),
  saveBrowserSnapshot:(records,assets,expectedRevision)=>call('save_browser_snapshot',{records,assets,expectedRevision}),
  readBrowserSnapshot:()=>call('read_browser_snapshot'),
  choosePdf:()=>call('choose_pdf'),
  readPdf:(id,page)=>call('read_pdf',{id,page}),
  exportBackup:()=>call('export_backup'),
  restoreBackup:()=>call('restore_backup')
 });
})();
