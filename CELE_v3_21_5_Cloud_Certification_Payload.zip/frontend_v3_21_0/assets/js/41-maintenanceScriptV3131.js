
(function(){
  'use strict';
  function syncNavCountsV3131(){
    document.querySelectorAll('.nav-cluster').forEach(cluster=>{
      const panel=cluster.querySelector('.nav-children');
      const badge=cluster.querySelector('.nav-parent .nav-count');
      if(panel&&badge)badge.textContent=String(panel.querySelectorAll(':scope > [data-view]').length);
    });
  }
  function maintenanceV3131(){
    syncNavCountsV3131();
    if(document.title!=='CELE Topnotcher OS 3.13.3')document.title='CELE Topnotcher OS 3.13.3';
    const current=document.querySelector('.view.active')?.id?.replace('view-','');
    if(current==='exam'&&document.querySelector('#pageTitle')?.textContent==='CELE Topnotcher OS')document.querySelector('#pageTitle').textContent='Exam Simulation';
  }
  window.syncNavCountsV3131=syncNavCountsV3131;
  document.querySelectorAll('.nav-children').forEach(panel=>{
    try{new MutationObserver(()=>syncNavCountsV3131()).observe(panel,{childList:true})}catch{}
  });
  setTimeout(maintenanceV3131,0);
  setTimeout(maintenanceV3131,250);
  setTimeout(maintenanceV3131,1000);
})();
