# v3.21.0 Native PDF/OCR Adapter Report

The frontend now has one document I/O contract for both supported local modes.

### Tauri desktop

PDF bytes are sent to the native shell for validation and preservation. The returned content-addressed SHA-256 ID is used to request exact source pages. Native-rendered PNG pages then flow through the pre-existing browser crop/preprocessing logic, and those PNG regions are sent to native Windows OCR. Spatial lines/words/bounds are returned to the unchanged layout/compiler pipeline.

### Standalone browser compatibility

When intentionally served from localhost without Tauri, the same transport module can use the existing local PowerShell `/pdf/load`, `/render`, and `/ocr` endpoints. A Tauri failure does not silently switch to localhost.

### Static verification

The release audit verifies JavaScript syntax, CSS parseability, strict-CSP markup, asset-reference resolution, static ID uniqueness, compiler byte identity, native command/permission parity, clean-bank markers, and exact-file Tauri staging. Native runtime behavior is not claimed until the Windows builder executes the supplied smoke checklist.
