@echo off
cd /d "%~dp0"
title CELE Topnotcher OS 3.21.0 Public Edition
echo Starting CELE Topnotcher OS v3.21.0 local PDF/OCR service...
echo No bundled reviewer corpus and no cloud AI bridge are included in this public candidate.
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0CELE_Local_PDF_OCR_Bridge_v3_21_0.ps1"
pause
