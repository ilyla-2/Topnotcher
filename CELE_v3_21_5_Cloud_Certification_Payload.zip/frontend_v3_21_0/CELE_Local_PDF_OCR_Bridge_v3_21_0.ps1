param(
    [int]$Port = 8765,
    [string]$AppFile = "CELE_Topnotcher_OS_v3_21_0.html"
)

$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $MyInvocation.MyCommand.Path
$appPath = Join-Path $root $AppFile
if (-not (Test-Path -LiteralPath $appPath)) {
    Write-Host "CELE OS HTML was not found: $appPath" -ForegroundColor Red
    Read-Host "Press Enter to close"
    exit 1
}

[Console]::OutputEncoding = [System.Text.UTF8Encoding]::new($false)
Add-Type -AssemblyName System.Runtime.WindowsRuntime
$null = [Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Storage.FileAccessMode, Windows.Storage, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.IRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.InMemoryRandomAccessStream, Windows.Storage.Streams, ContentType = WindowsRuntime]
$null = [Windows.Storage.Streams.DataReader, Windows.Storage.Streams, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
$null = [Windows.Graphics.Imaging.BitmapEncoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
$null = [Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
$null = [Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]
$null = [Windows.Data.Pdf.PdfDocument, Windows.Data.Pdf, ContentType = WindowsRuntime]
$null = [Windows.Data.Pdf.PdfPageRenderOptions, Windows.Data.Pdf, ContentType = WindowsRuntime]

function Await-WinRt {
    param([Parameter(Mandatory=$true)][object]$Operation,[Parameter(Mandatory=$true)][Type]$ResultType)
    $method = [System.WindowsRuntimeSystemExtensions].GetMethods() |
        Where-Object {
            $_.Name -eq 'AsTask' -and $_.IsGenericMethod -and
            $_.GetParameters().Count -eq 1 -and
            $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncOperation`1'
        } | Select-Object -First 1
    if ($null -eq $method) { throw 'Could not resolve WinRT AsTask helper.' }
    $task = $method.MakeGenericMethod($ResultType).Invoke($null, @($Operation))
    $task.Wait()
    return $task.Result
}

function Await-WinRtAction {
    param([Parameter(Mandatory=$true)][object]$Operation)
    $method = [System.WindowsRuntimeSystemExtensions].GetMethods() |
        Where-Object {
            $_.Name -eq 'AsTask' -and -not $_.IsGenericMethod -and
            $_.GetParameters().Count -eq 1 -and
            $_.GetParameters()[0].ParameterType.Name -eq 'IAsyncAction'
        } | Select-Object -First 1
    if ($null -eq $method) { throw 'Could not resolve WinRT IAsyncAction AsTask helper.' }
    $task = $method.Invoke($null, @($Operation))
    $task.Wait()
}

function Get-OcrEngineStatus {
    try {
        $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
        if ($null -eq $engine) {
            return [ordered]@{ available=$false; language=''; error='Windows OCR has no usable language pack. Install the English OCR language feature in Windows Settings.' }
        }
        return [ordered]@{ available=$true; language=$engine.RecognizerLanguage.LanguageTag; error='' }
    } catch {
        return [ordered]@{ available=$false; language=''; error=$_.Exception.Message }
    }
}

function Get-PdfRendererStatus {
    try {
        $null = [Windows.Data.Pdf.PdfDocument]
        $null = [Windows.Data.Pdf.PdfPageRenderOptions]
        return [ordered]@{ available=$true; error='' }
    } catch {
        return [ordered]@{ available=$false; error=$_.Exception.Message }
    }
}

function Invoke-WindowsOcr {
    param([Parameter(Mandatory=$true)][string]$ImagePath)
    $file = Await-WinRt ([Windows.Storage.StorageFile]::GetFileFromPathAsync((Resolve-Path -LiteralPath $ImagePath).Path)) ([Windows.Storage.StorageFile])
    $stream = Await-WinRt ($file.OpenAsync([Windows.Storage.FileAccessMode]::Read)) ([Windows.Storage.Streams.IRandomAccessStream])
    try {
        $decoder = Await-WinRt ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
        $bitmap = Await-WinRt ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])
        try {
            $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
            if ($null -eq $engine) { throw 'No Windows OCR language is available. English OCR language support may need to be installed in Windows.' }
            $result = Await-WinRt ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])
            $lines = @($result.Lines | ForEach-Object {
                $words = @($_.Words | ForEach-Object {
                    [ordered]@{
                        text = $_.Text
                        bounds = [ordered]@{ x=[double]$_.BoundingRect.X; y=[double]$_.BoundingRect.Y; width=[double]$_.BoundingRect.Width; height=[double]$_.BoundingRect.Height }
                    }
                })
                [ordered]@{ text=$_.Text; words=$words }
            })
            return [ordered]@{ ok=$true; backend='windows-media-ocr'; language=$engine.RecognizerLanguage.LanguageTag; text=$result.Text; lines=$lines }
        } finally {
            if ($null -ne $bitmap) { $bitmap.Dispose() }
        }
    } finally {
        if ($null -ne $stream) { $stream.Dispose() }
    }
}

function Get-PdfPageCount {
    param([Parameter(Mandatory=$true)][string]$PdfPath)
    $file = Await-WinRt ([Windows.Storage.StorageFile]::GetFileFromPathAsync((Resolve-Path -LiteralPath $PdfPath).Path)) ([Windows.Storage.StorageFile])
    $doc = Await-WinRt ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($file)) ([Windows.Data.Pdf.PdfDocument])
    return [int]$doc.PageCount
}

function Read-RandomAccessStreamBytes {
    param([Parameter(Mandatory=$true)][object]$Stream)
    $Stream.Seek(0)
    $size64 = [uint64]$Stream.Size
    if ($size64 -gt [uint32]::MaxValue) { throw 'Rendered page image is unexpectedly large.' }
    $size = [uint32]$size64
    $input = $Stream.GetInputStreamAt(0)
    $reader = [Windows.Storage.Streams.DataReader]::new($input)
    try {
        $loaded = Await-WinRt ($reader.LoadAsync($size)) ([uint32])
        $bytes = New-Object byte[] ([int]$loaded)
        $reader.ReadBytes($bytes)
        return $bytes
    } finally {
        try { $reader.DetachStream() | Out-Null } catch {}
        try { $reader.Dispose() } catch {}
        try { $input.Dispose() } catch {}
    }
}

function Render-PdfPage {
    param(
        [Parameter(Mandatory=$true)][string]$PdfPath,
        [Parameter(Mandatory=$true)][int]$PageNumber,
        [int]$DestinationWidth = 2200
    )
    $file = Await-WinRt ([Windows.Storage.StorageFile]::GetFileFromPathAsync((Resolve-Path -LiteralPath $PdfPath).Path)) ([Windows.Storage.StorageFile])
    $doc = Await-WinRt ([Windows.Data.Pdf.PdfDocument]::LoadFromFileAsync($file)) ([Windows.Data.Pdf.PdfDocument])
    if ($PageNumber -lt 1 -or $PageNumber -gt [int]$doc.PageCount) { throw "Page $PageNumber is outside this PDF (1-$($doc.PageCount))." }
    $page = $doc.GetPage([uint32]($PageNumber - 1))
    try {
        $pageSize = $page.Size
        $w = [math]::Max(1.0,[double]$pageSize.Width)
        $h = [math]::Max(1.0,[double]$pageSize.Height)
        $destW = [uint32][math]::Max(900,[math]::Min(3200,$DestinationWidth))
        $destH = [uint32][math]::Max(1,[math]::Round($destW * $h / $w))
        $opts = [Windows.Data.Pdf.PdfPageRenderOptions]::new()
        $opts.BitmapEncoderId = [Windows.Graphics.Imaging.BitmapEncoder]::PngEncoderId
        $opts.DestinationWidth = $destW
        $opts.DestinationHeight = $destH
        $mem = [Windows.Storage.Streams.InMemoryRandomAccessStream]::new()
        try {
            Await-WinRtAction ($page.RenderToStreamAsync($mem,$opts))
            $bytes = Read-RandomAccessStreamBytes $mem
            return [ordered]@{ bytes=$bytes; width=[int]$destW; height=[int]$destH; pageCount=[int]$doc.PageCount }
        } finally {
            try { $mem.Dispose() } catch {}
        }
    } finally {
        try { $page.Dispose() } catch {}
    }
}

function Read-HttpRequest {
    param([Parameter(Mandatory=$true)][System.Net.Sockets.NetworkStream]$Stream)
    $headerBytes = New-Object System.Collections.Generic.List[byte]
    $state = 0
    while ($headerBytes.Count -lt 65536) {
        $b = $Stream.ReadByte()
        if ($b -lt 0) { break }
        [void]$headerBytes.Add([byte]$b)
        if (($state -eq 0 -and $b -eq 13)) { $state=1 }
        elseif (($state -eq 1 -and $b -eq 10)) { $state=2 }
        elseif (($state -eq 2 -and $b -eq 13)) { $state=3 }
        elseif (($state -eq 3 -and $b -eq 10)) { break }
        else { $state=0 }
    }
    if ($headerBytes.Count -eq 0) { return $null }
    $headerText = [System.Text.Encoding]::ASCII.GetString($headerBytes.ToArray())
    $lines = $headerText -split "`r`n"
    $parts = $lines[0] -split ' '
    if ($parts.Count -lt 2) { throw 'Malformed HTTP request.' }
    $headers = @{}
    if ($lines.Count -gt 1) {
        foreach ($line in $lines[1..($lines.Count-1)]) {
            if ([string]::IsNullOrWhiteSpace($line)) { continue }
            $i = $line.IndexOf(':')
            if ($i -gt 0) { $headers[$line.Substring(0,$i).Trim().ToLowerInvariant()] = $line.Substring($i+1).Trim() }
        }
    }
    $len = 0
    if ($headers.ContainsKey('content-length')) { [void][int]::TryParse($headers['content-length'], [ref]$len) }
    $body = New-Object byte[] $len
    $read = 0
    while ($read -lt $len) {
        $n = $Stream.Read($body,$read,$len-$read)
        if ($n -le 0) { break }
        $read += $n
    }
    if ($read -lt $len) { throw "Request body ended early ($read/$len bytes)." }
    return [ordered]@{ method=$parts[0].ToUpperInvariant(); path=$parts[1]; headers=$headers; body=$body }
}

function Write-HttpResponse {
    param(
        [Parameter(Mandatory=$true)][System.Net.Sockets.NetworkStream]$Stream,
        [int]$Status=200,
        [string]$ContentType='text/plain; charset=utf-8',
        [byte[]]$Body=([byte[]]@()),
        [hashtable]$ExtraHeaders=@{}
    )
    $reason = switch ($Status) { 200 {'OK'} 204 {'No Content'} 400 {'Bad Request'} 404 {'Not Found'} 405 {'Method Not Allowed'} 500 {'Internal Server Error'} default {'OK'} }
    $h = "HTTP/1.1 $Status $reason`r`nContent-Type: $ContentType`r`nContent-Length: $($Body.Length)`r`nCache-Control: no-store`r`nX-Content-Type-Options: nosniff`r`nX-Frame-Options: DENY`r`nReferrer-Policy: no-referrer`r`nConnection: close`r`n"
    foreach ($k in $ExtraHeaders.Keys) { $h += "$k`: $($ExtraHeaders[$k])`r`n" }
    $h += "`r`n"
    $hb = [System.Text.Encoding]::ASCII.GetBytes($h)
    $Stream.Write($hb,0,$hb.Length)
    if ($Body.Length -gt 0) { $Stream.Write($Body,0,$Body.Length) }
    $Stream.Flush()
}

function Json-Bytes($obj) { return [System.Text.Encoding]::UTF8.GetBytes(($obj | ConvertTo-Json -Depth 10 -Compress)) }

function Parse-QueryString {
    param([string]$Path)
    $out = @{}
    $qPos = $Path.IndexOf('?')
    if ($qPos -lt 0) { return $out }
    $query = $Path.Substring($qPos+1)
    foreach ($pair in ($query -split '&')) {
        if ([string]::IsNullOrWhiteSpace($pair)) { continue }
        $kv = $pair -split '=',2
        $k = [System.Uri]::UnescapeDataString($kv[0])
        $v = if ($kv.Count -gt 1) { [System.Uri]::UnescapeDataString($kv[1].Replace('+',' ')) } else { '' }
        $out[$k] = $v
    }
    return $out
}

$pdfCache = @{}
$tempPdfPaths = New-Object System.Collections.Generic.List[string]

$listener = [System.Net.Sockets.TcpListener]::new([System.Net.IPAddress]::Loopback,$Port)
try {
    $listener.Start()
} catch {
    Write-Host "Could not start local CELE bridge on port $Port." -ForegroundColor Red
    Write-Host $_.Exception.Message -ForegroundColor Red
    Read-Host "Press Enter to close"
    exit 1
}

$ocrStatus = Get-OcrEngineStatus
$pdfStatus = Get-PdfRendererStatus
Write-Host ""; Write-Host "CELE Topnotcher OS v3.21.0 — browser compatibility bridge" -ForegroundColor Cyan
Write-Host "Local server: http://127.0.0.1:$Port/"
if ($pdfStatus.available) { Write-Host "Windows PDF renderer: ready" -ForegroundColor Green } else { Write-Host "Windows PDF renderer: unavailable - $($pdfStatus.error)" -ForegroundColor Yellow }
if ($ocrStatus.available) { Write-Host "Windows OCR: ready ($($ocrStatus.language))" -ForegroundColor Green } else { Write-Host "Windows OCR: unavailable - $($ocrStatus.error)" -ForegroundColor Yellow }
Write-Host "PDF rendering and OCR remain local to this PC. Keep this window open while using CELE OS." -ForegroundColor DarkGray
Start-Process "http://127.0.0.1:$Port/"

try {
    while ($true) {
        $client = $null
        $stream = $null
        try {
            $client = $listener.AcceptTcpClient()
            $stream = $client.GetStream()
            $req = Read-HttpRequest $stream
            if ($null -eq $req) { continue }
            $pathOnly = ($req.path -split '\?')[0]
            $query = Parse-QueryString $req.path

            if ($req.method -eq 'GET' -and ($pathOnly -eq '/' -or $pathOnly -eq '/CELE_Topnotcher_OS_v3_21_0.html')) {
                $bytes = [System.IO.File]::ReadAllBytes($appPath)
                Write-HttpResponse $stream 200 'text/html; charset=utf-8' $bytes
            }

            elseif ($req.method -eq 'GET' -and $pathOnly -eq '/health') {
                $os = Get-OcrEngineStatus
                $ps = Get-PdfRendererStatus
                Write-HttpResponse $stream 200 'application/json; charset=utf-8' (Json-Bytes ([ordered]@{ok=$true;ocrAvailable=$os.available;rendererAvailable=$ps.available;language=$os.language;error=($os.error + $(if($ps.error){' '+$ps.error}else{''})).Trim();version='1.5';backend='windows-media-ocr+windows-data-pdf'}))
            }
            elseif ($req.method -eq 'POST' -and $pathOnly -eq '/pdf/load') {
                if ($req.body.Length -eq 0) { Write-HttpResponse $stream 400 'application/json; charset=utf-8' (Json-Bytes @{ok=$false;error='Empty PDF.'}); continue }
                $token = [guid]::NewGuid().ToString('N')
                $tmpPdf = Join-Path ([System.IO.Path]::GetTempPath()) ("cele-pdf-$token.pdf")
                try {
                    [System.IO.File]::WriteAllBytes($tmpPdf,$req.body)
                    $pageCount = Get-PdfPageCount $tmpPdf
                    $pdfCache[$token] = $tmpPdf
                    [void]$tempPdfPaths.Add($tmpPdf)
                    Write-HttpResponse $stream 200 'application/json; charset=utf-8' (Json-Bytes ([ordered]@{ok=$true;token=$token;pageCount=$pageCount}))
                } catch {
                    Remove-Item -LiteralPath $tmpPdf -Force -ErrorAction SilentlyContinue
                    Write-HttpResponse $stream 500 'application/json; charset=utf-8' (Json-Bytes ([ordered]@{ok=$false;error=$_.Exception.Message}))
                }
            }
            elseif ($req.method -eq 'GET' -and $pathOnly -eq '/render') {
                $token = [string]$query['token']
                $page = 1; $width = 2200
                if ($query.ContainsKey('page')) { [void][int]::TryParse([string]$query['page'],[ref]$page) }
                if ($query.ContainsKey('width')) { [void][int]::TryParse([string]$query['width'],[ref]$width) }
                if (-not $pdfCache.ContainsKey($token)) { Write-HttpResponse $stream 404 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes('Unknown PDF token. Reload the PDF in CELE OS.')); continue }
                try {
                    $rendered = Render-PdfPage -PdfPath $pdfCache[$token] -PageNumber $page -DestinationWidth $width
                    Write-HttpResponse $stream 200 'image/png' $rendered.bytes @{ 'X-CELE-Page-Width'=[string]$rendered.width; 'X-CELE-Page-Height'=[string]$rendered.height; 'X-CELE-Page-Count'=[string]$rendered.pageCount }
                } catch {
                    Write-HttpResponse $stream 500 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes($_.Exception.Message))
                }
            }
            elseif ($req.method -eq 'POST' -and $pathOnly -eq '/ocr') {
                if ($req.body.Length -eq 0) { Write-HttpResponse $stream 400 'application/json; charset=utf-8' (Json-Bytes @{ok=$false;error='Empty OCR image.'}); continue }
                $tmp = Join-Path ([System.IO.Path]::GetTempPath()) ("cele-ocr-"+[guid]::NewGuid().ToString('N')+'.png')
                try {
                    [System.IO.File]::WriteAllBytes($tmp,$req.body)
                    $result = Invoke-WindowsOcr $tmp
                    Write-HttpResponse $stream 200 'application/json; charset=utf-8' (Json-Bytes $result)
                } catch {
                    Write-HttpResponse $stream 500 'application/json; charset=utf-8' (Json-Bytes ([ordered]@{ok=$false;error=$_.Exception.Message}))
                } finally {
                    Remove-Item -LiteralPath $tmp -Force -ErrorAction SilentlyContinue
                }
            }
            else {
                Write-HttpResponse $stream 404 'text/plain; charset=utf-8' ([System.Text.Encoding]::UTF8.GetBytes('Not found'))
            }
        } catch {
            try { if ($null -ne $stream) { Write-HttpResponse $stream 500 'application/json; charset=utf-8' (Json-Bytes ([ordered]@{ok=$false;error=$_.Exception.Message})) } } catch {}
        } finally {
            if ($null -ne $client) { $client.Close() }
        }
    }
} finally {
    try { $listener.Stop() } catch {}
    foreach ($p in $tempPdfPaths) { Remove-Item -LiteralPath $p -Force -ErrorAction SilentlyContinue }
}
