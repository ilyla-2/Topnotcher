CELE Topnotcher OS v3.21.0 — Native PDF/OCR Adapter Public Candidate

Desktop/Tauri mode:
  Use this frontend with CELE Topnotcher Desktop Foundation 0.3.0.
  PDF validation, exact source-page rendering, and OCR are routed through the native Windows adapter.
  The v3.20 transactional native data bridge remains intact.

Standalone browser compatibility mode:
  Run Start_CELE_OS_v3_21_0.cmd on Windows. This uses the existing PowerShell localhost PDF/OCR bridge only as a compatibility path.

The public candidate contains no bundled private reviewer question bank or source PDFs. Clean install begins with zero questions.

Native adapter QA remains pending until Foundation 0.3.0 is compiled and exercised on a real Windows Rust/Tauri/WebView2 builder.
