/* Opt-in handoff utility. Not included or auto-run in the frozen CELE application.
   Call exportCeleBrowserBackup() only after pausing study/import activity.
   No records, trust labels, keys or source mappings are rewritten. */
async function exportCeleBrowserBackup(){
 const encoder=new TextEncoder(),limit=64*1024*1024,files=[];let total=0;
 const hash=async b=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b))).map(x=>x.toString(16).padStart(2,'0')).join('');
 async function add(path,b){if(b.byteLength>limit||(total+=b.byteLength)>128*1024*1024)throw Error('Backup size limit; use an approved streaming migration for larger data.');let text='';for(let i=0;i<b.length;i+=32768)text+=String.fromCharCode(...b.subarray(i,i+32768));files.push({path,size:b.byteLength,sha256:await hash(b),data:btoa(text)});}
 const records={};for(let i=0;i<localStorage.length;i++){const k=localStorage.key(i);if(k.startsWith('cele_')||k.startsWith('celeos_'))records[k]=localStorage.getItem(k)}
 if(!records.cele_topnotcher_os_v01)throw Error('No legacy learner record found; refusing an incomplete migration.');
 await add('learner-state/browser-localstorage.json',encoder.encode(JSON.stringify(records)));
 const rows=await new Promise((resolve,reject)=>{const r=indexedDB.open('CELE_TOPNOTCHER_OS_ASSETS_V1');let missing=false;r.onupgradeneeded=()=>{missing=true;r.transaction.abort()};r.onerror=()=>missing?resolve([]):reject(Error('Cannot read existing asset database'));r.onsuccess=()=>{const db=r.result;if(!db.objectStoreNames.contains('assets')){db.close();reject(Error('Expected asset store missing'));return}const t=db.transaction('assets','readonly');const q=t.objectStore('assets').getAll();q.onsuccess=()=>{const result=q.result;t.oncomplete=()=>{db.close();resolve(result)}};q.onerror=()=>{db.close();reject(Error('Asset read failed'))};t.onabort=()=>{db.close();reject(Error('Asset snapshot aborted'))}}});
 const map=[];
 for(const r of rows){if(!(r.blob instanceof Blob))throw Error('Unknown asset record shape: manual review required');const b=new Uint8Array(await r.blob.arrayBuffer());const id=await hash(b),pdf=r.blob.type==='application/pdf';const path=pdf?'source-pdfs/'+id+'.pdf':'compiler/'+id+'.blob';if(!files.some(f=>f.path===path))await add(path,b);map.push({key:r.key,meta:r.meta,updatedAt:r.updatedAt,mime:r.blob.type,path});}
 await add('compiler/indexeddb-assets.json',encoder.encode(JSON.stringify({database:'CELE_TOPNOTCHER_OS_ASSETS_V1',store:'assets',records:map})));
 // Detect localStorage changes across the read. IndexedDB/app writers must be quiesced by caller.
 for(const[k,v]of Object.entries(records))if(localStorage.getItem(k)!==v)throw Error('Learner state changed during capture. Pause activity and retry.');
 const out={format:'CELE-DESKTOP-BACKUP',schemaVersion:1,dataSchema:1,foundationVersion:'0.3.0',snapshotScope:'native-committed-only',files};
 return new Blob([JSON.stringify(out)],{type:'application/json'});
}
