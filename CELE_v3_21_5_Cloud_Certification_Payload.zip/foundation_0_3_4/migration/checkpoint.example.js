/* Example ONLY, not injected. Run only inside a quiesced, reviewed frontend.
   Exact raw strings are preserved. IndexedDB migration remains a separate gate. */
async function captureBrowserCheckpoint(){
 const records={};
 for(let i=0;i<localStorage.length;i++){const key=localStorage.key(i);if(key.startsWith('cele_')||key.startsWith('celeos_'))records[key]=localStorage.getItem(key);}
 if(!records.cele_topnotcher_os_v01)throw Error('No legacy learner state.');
 const {revision}=await CELEDesktop.status();
 return CELEDesktop.checkpoint(records,revision);
}
