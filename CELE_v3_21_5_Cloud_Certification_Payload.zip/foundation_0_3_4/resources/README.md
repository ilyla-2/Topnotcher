# Permitted built-in resources

No inherited reviewer PDFs, formula scans, standards or question data are present.
Original foundation icons live in src-tauri/icons. Final permitted resources must
be explicitly reviewed and listed by SHA-256 in the frontend manifest. This folder
is not recursively bundled by Tauri.
