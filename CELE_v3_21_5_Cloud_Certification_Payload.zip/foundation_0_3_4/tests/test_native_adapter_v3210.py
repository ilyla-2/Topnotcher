import json,re,unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class NativeAdapterStaticTests(unittest.TestCase):
 def test_api_v3_surface_matches_rust_and_permissions(self):
  js=(ROOT/'app/desktop-api.js').read_text()
  rs=(ROOT/'src-tauri/src/main.rs').read_text()
  perm=(ROOT/'src-tauri/permissions/desktop.toml').read_text()
  self.assertIn('apiVersion:3',js)
  commands=['desktop_status','document_adapter_status','register_source_pdf','render_source_pdf_page','ocr_image_region','save_checkpoint','read_checkpoint','save_browser_snapshot','read_browser_snapshot','choose_pdf','read_pdf','export_backup','restore_backup']
  handler=re.search(r'generate_handler!\[(.*?)\]',rs,re.S).group(1)
  for cmd in commands:
   self.assertIn(cmd,js); self.assertIn(cmd,rs); self.assertIn(cmd,handler); self.assertIn(f'"{cmd}"',perm)
 def test_native_pdf_ocr_module_is_semantically_opaque(self):
  rs=(ROOT/'src-tauri/src/pdf_ocr.rs').read_text()
  for required in ['PdfDocument','PdfPageRenderOptions','OcrEngine','BitmapDecoder','BoundingRect','source-pdfs/']:
   if required=='source-pdfs/':
    self.assertIn(required,(ROOT/'src-tauri/src/main.rs').read_text())
   else:self.assertIn(required,rs)
  for forbidden in ['TRUSTED','STAGING','REVIEW','REJECT','Readiness','Study Next','domain classification','answerKey']:
   self.assertNotIn(forbidden,rs)
 def test_pdf_import_is_validated_before_commit(self):
  rs=(ROOT/'src-tauri/src/main.rs').read_text()
  block=re.search(r'fn register_source_pdf\(.*?\n}\n#\[tauri::command\]',rs,re.S).group(0)
  self.assertLess(block.index('page_count_bytes'),block.index('st.commit'))
  for token in ['%PDF-','source-pdfs/','store::hash','PDF_PAGECOUNT_INVALID','trust":"not-assigned']:
   self.assertIn(token,block)
 def test_render_reverifies_content_address(self):
  rs=(ROOT/'src-tauri/src/main.rs').read_text()
  block=re.search(r'fn render_source_pdf_page\(.*?\n}\n#\[tauri::command\]',rs,re.S).group(0)
  self.assertIn('committed_path',block);self.assertIn('SOURCE_INTEGRITY_FAILURE',block);self.assertIn('pdf_ocr::render_page',block)
 def test_ocr_returns_spatial_contract(self):
  rs=(ROOT/'src-tauri/src/pdf_ocr.rs').read_text()
  for token in ['OcrBounds','OcrWord','OcrLine','BoundingRect','words:Vec<OcrWord>']:
   self.assertIn(token,rs)
 def test_native_validates_legacy_namespace_and_assets(self):
  rs=(ROOT/'src-tauri/src/main.rs').read_text(); store=(ROOT/'src-tauri/src/store.rs').read_text()
  for token in ['cele_topnotcher_os_v01','CELE_TOPNOTCHER_OS_ASSETS_V1','HASH_MISMATCH','ASSET_INTEGRITY_FAILURE','STALE_REVISION']:
   self.assertIn(token,rs+store)
  self.assertIn('source-pdfs/',rs); self.assertIn('compiler/indexeddb-assets.json',rs)
 def test_strict_csp_unchanged(self):
  csp=json.loads((ROOT/'src-tauri/tauri.conf.json').read_text())['app']['security']['csp']
  self.assertNotIn('unsafe-inline',csp);self.assertNotIn('unsafe-eval',csp);self.assertNotIn('https:',csp)
 def test_version_alignment(self):
  meta=json.loads((ROOT/'release/metadata.json').read_text())
  # metadata is updated during v3.21 packaging; this test prevents accidental mismatch afterward.
  if meta.get('foundationVersion')=='0.3.0':
   self.assertEqual(json.loads((ROOT/'package.json').read_text())['version'],'0.3.0')
   self.assertEqual(json.loads((ROOT/'src-tauri/tauri.conf.json').read_text())['version'],'0.3.0')

if __name__=='__main__':unittest.main()
