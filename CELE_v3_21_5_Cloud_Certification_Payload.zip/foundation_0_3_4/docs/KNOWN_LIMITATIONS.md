# Known limitations

1. Rust/Cargo and native Tauri prerequisites are absent in the authoring environment. Native source is provided but not compiled or executed here. No EXE, MSI, NSIS installer, APP or DMG is claimed. Cargo.lock must be generated/reviewed on the native builder before release.
2. The application payload is a diagnostic placeholder, not a populated CELE app. The reviewed public-cleared v3.20.0 frontend and its own QA remain external dependencies.
3. The strict CSP may block current inline/dynamic frontend patterns. This must be fixed/reviewed by the integration owner; the shell does not disable security to accept the old monolith.
4. No OCR/render/text-extraction backend is ported. Existing Windows PowerShell and optional AI service are not run. Source preservation/lookup is implemented at the native API level; exact-page rendering and macOS PDF behavior require integration tests.
5. Native restore does not overwrite browser localStorage/IndexedDB. Explicit startup reconciliation/write barriers are still required. Browser migration export reads opaque existing bytes, but must run at the old origin while the application is quiesced. Files only in the old package are not automatically captured.
6. Snapshot operations use bounded in-memory JSON/base64: 64 MiB/file, 128 MiB decoded total, 192 MiB archive. Larger data needs a versioned streaming implementation. Generations duplicate data and are retained indefinitely until an explicit cleanup policy is implemented.
7. No encryption, cryptographic backup authentication, automatic update service, cloud account, telemetry or signing certificate is supplied. Backup integrity hashes do not imply source trust.
8. Placeholder publisher/identifier/icon and unsigned builds are not production-ready. Metadata approval flags are procedural gates, not cryptographic proofs.
9. Native filesystem power-loss behavior, Windows dialogs/UAC/uninstall details, macOS signing/notarization and actual display scaling need platform validation. Browser simulations cannot certify those behaviors.
10. Cleanup removes fixed generated paths only. Original input and private user data must never be placed in those generated directories. No automatic user-data deletion is implemented.
