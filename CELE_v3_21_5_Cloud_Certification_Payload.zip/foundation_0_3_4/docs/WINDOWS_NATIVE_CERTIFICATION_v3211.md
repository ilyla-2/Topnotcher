# v3.21.1 — Windows Native Runtime Certification

This phase certifies the v3.21.0 Native PDF/OCR Adapter on an actual Windows x64 machine without changing the reviewed 103-file frontend payload or the frozen CELE compiler.

## Isolation

The certification build uses `src-tauri/tauri.certification.conf.json` and the separate identifier `local.cele.topnotcher.certification`. It therefore does not intentionally use the production app-data identity while exercising the same Rust adapter/store source.

## Automated evidence

`RUN_WINDOWS_CERTIFICATION.cmd` performs the following in order:

1. records Windows, Node, npm, Rust, Cargo and build environment metadata;
2. installs the exact npm lockfile dependencies;
3. stages the byte-reviewed v3.21.0 frontend through `stage-certification`;
4. runs the portable Python regression suite;
5. generates and then freezes `src-tauri/Cargo.lock` if it does not yet exist;
6. compiles all Rust targets and runs `src-tauri/tests/native_runtime_cert.rs`;
7. validates a real two-page PDF using `Windows.Data.Pdf`;
8. renders source pages 1 and 2 to PNG and checks bounds/page count;
9. rejects an invalid PDF and an out-of-range page request;
10. runs `Windows.Media.Ocr` against a synthetic high-contrast image and checks text plus word geometry;
11. exercises immutable native generations, expected-revision rejection, source SHA-256, backup round-trip, and corrupted-backup rejection;
12. builds the isolated Tauri release executable;
13. launches it, forcibly terminates it, and launches it again;
14. optionally builds an isolated NSIS certification installer.

The script writes machine-readable evidence under `release/native-certification/`. A PASS proves the automated native gate only: native PDF/OCR/store execution, Rust/Tauri release build, and launch/forced-stop/relaunch. `nativeAdapterQA` deliberately remains pending until the real staged v3.21.0 frontend has exercised the Tauri IPC commands through WebView2.

## Deliberately separate release gates

Automated native-gate PASS does **not** claim frontend-to-Tauri IPC E2E, installer E2E, signed installer verification, display-scaling/manual UI checks, publisher identity, redistribution clearance, or final public-release approval. Those remain separate gates.

## OCR language behavior

If Windows has no usable OCR recognizer language, the harness verifies the stable `OCR_LANGUAGE_UNAVAILABLE` contract but leaves the runtime certificate `BLOCKED`. Install an OCR-capable Windows language and rerun before approving `nativeAdapterQA`.
