# Desktop architecture

Tauri 2 hosts the existing frontend through `app/payload/`. No framework conversion, engine rewrite, Electron substitution, or source-bridge execution occurs. Foundation semantic version 0.3.0 is independent of the CELE frontend version.

The native main window loads a content-free diagnostic page. After reviewed staging, its link opens the exact payload entry. Before public distribution, set the configured window URL to that manifest entry so users enter the existing splash/onboarding directly; this is a configuration change, not an HTML patch. Theme is not forced: system light/dark is available to the WebView, and the frontend retains its saved workspace theme behavior. Native decorations provide resize, minimize, maximize and restore. Default 1280 × 800 logical units; minimum 640 × 480. No zoom override or fixed physical-pixel scaling is introduced.

Native services: status; opaque localStorage checkpoint; read checkpoint; native PDF picker/preservation; PDF read by SHA-256 ID; export snapshot; validated restore. JavaScript facade is `app/desktop-api.js`, API version 1. It must be explicitly loaded by the final frontend owner; it never patches existing functions. No filesystem, shell, HTTP, updater or process plugin is exposed.

Data root resolves with Tauri's app-data API, under identifier `local.cele.topnotcher.foundation`, then `Topnotcher Data`. This placeholder identifier must be finalized before distribution, because changing it relocates WebView/native data. App resources are read-only. Runtime files never go inside a macOS app bundle or installation folder.

Error codes and timestamps go to `logs/events.log`, rotating once at 1 MiB. Startup failure displays a generic native message. A panic hook records only NATIVE_PANIC (no panic payload or backtrace). No paths, document text, question content or profile fields are logged. A process-held OS file lock rejects a second instance. A mutex serializes commands within the process. Native dialog calls do not hold that mutex across awaits.

Rust compilation is pending; portable tests validate the documented storage contract, not the native ABI. Resolve and commit Cargo.lock on the target builder, then compile and run the native tests before approval. Node's CLI dependency has a lockfile.
