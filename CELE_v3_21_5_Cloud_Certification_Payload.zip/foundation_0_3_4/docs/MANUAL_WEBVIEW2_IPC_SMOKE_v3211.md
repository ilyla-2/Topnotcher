# v3.21.1 — Manual WebView2 → Tauri IPC Smoke

Run this only after `RUN_WINDOWS_CERTIFICATION.cmd` reports `AUTOMATED NATIVE GATE: PASS` and `nativeAdapterQA: pending-manual-ipc`.

The purpose is narrow: verify that the real staged v3.21.0 frontend reaches the already-tested native commands through WebView2. Do not alter question-bank data, compiler rules, Coverage, Readiness, Study Next, analytics, engineering calculations, or NSCP logic during this gate.

## Preconditions

- Use the isolated certification build (`local.cele.topnotcher.certification`).
- Keep `release/native-certification/windows-certification-summary.json` from the automated run.
- Use a non-sensitive test PDF that you are allowed to use for validation.
- Do not mark `nativeAdapterQA` approved merely because the application opens.

## Required checks

1. Launch the certification executable and confirm the real v3.21.0 application loads in WebView2.
2. Open the PDF import flow and select a test PDF through the native picker.
3. Confirm the page count shown by the application matches the PDF.
4. Render at least two non-adjacent source pages and visually confirm each page matches the selected source page.
5. Trigger OCR on at least one visible text region. Confirm text is returned and the UI does not fall back to the legacy localhost PowerShell bridge in Tauri mode.
6. Use **Checkpoint now**, make a harmless learner-state change, then restore the checkpoint and confirm the prior state returns.
7. Use **Export native backup**, then **Restore backup file** and confirm the validated restore reloads correctly.
8. Close the app normally, relaunch it, and confirm state persists.
9. Force-close the app once, relaunch it, and confirm the previous valid native generation remains usable.
10. If possible, start with an empty browser compatibility store while a native checkpoint exists and confirm the recovery offer appears instead of silently overwriting state.
11. Repeat a basic open/import/render interaction at Windows display scaling 100%, 125%, 150%, 175%, and 200%; record any clipping, unusable dialogs, or broken hit targets.

## Pass criteria

All required IPC operations above must complete through the real WebView2/Tauri application without corruption, source-page mismatch, legacy localhost dependency, or unexpected modification of CELE learner/question data. Any failure leaves `nativeAdapterQA` pending.

## Evidence

Copy `release/native-certification/manual-ipc-template.json` to `manual-ipc-report.json`, fill every required observation, add timestamps and artifact hashes where available, and preserve it beside the automated certification report. Final approval is a separate release decision; do not edit the reviewed v3.21.0 frontend manifest to manufacture an approval.
