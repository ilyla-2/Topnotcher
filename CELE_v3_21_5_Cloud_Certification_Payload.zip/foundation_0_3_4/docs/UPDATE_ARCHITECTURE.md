# Update architecture (inactive)

No updater plugin, network endpoint, background polling or update service is installed. Manual installers are the initial path. Runtime remains local-first. `release/update-manifest.example.json` is a non-operational template using example.invalid.

Future enablement: choose verified release channels; add the Tauri updater plugin and only required capabilities; provision its public verification key; produce signed updater artifacts with a protected private key held outside this repository. Updater signature and platform code signature are separate checks. Never disable update signature verification. GitHub Releases can later host artifacts/manifests, but no GitHub account, token or deployment is configured here.

Use semantic version comparison through the official updater, not string comparison. Keep stable/prerelease channels separate. A release manifest should identify platform/architecture, version, notes/date, artifact URL and signature. Supply compatibility metadata and verified hashes in release records. Deny incompatible data-schema updates before installation.

Before update, checkpoint/quiesce and export a validated native snapshot. Retain previous installer and data generation. Executable rollback is safe only if its data reader accepts the active data schema; otherwise restore the compatible prior snapshot with explicit consent. Do not overwrite browser state with stale data during rollback. Migration code must support old readers or use a new copy-on-write generation.

Signatures, channels, final identifier/publisher, Cargo lockfile, native regression reports, installer upgrade checks and recovery exercises remain required before live updates.

Reference: https://v2.tauri.app/plugin/updater/ (checked 2026-09-23).
