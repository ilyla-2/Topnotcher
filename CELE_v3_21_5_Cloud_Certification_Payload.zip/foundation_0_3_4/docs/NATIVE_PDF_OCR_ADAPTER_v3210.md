# Native PDF/OCR Adapter — CELE v3.21.0 / Foundation 0.3.0

v3.21 replaces the browser-era PowerShell transport inside the Tauri application with explicit native commands. The PowerShell bridge remains only as a standalone-browser compatibility path and is not part of the Tauri runtime payload.

## Boundary

The adapter accepts and returns opaque PDF/image bytes. It does not parse CELE questions, assign TRUSTED/STAGING/REVIEW/REJECT, classify domains, modify answers, calculate Coverage or Readiness, choose Study Next items, perform engineering calculations, or interpret NSCP provisions.

The frozen compiler remains `CELE-PDF-COMPILER-v1.6.1` with SHA-256 `3133e9ea5259afd12dfc8f2ba7b7cc3cdc8b4e2b089ad86bad40936e504d0ef5`.

## Native API v3

Added Tauri commands:

- `document_adapter_status()`
- `register_source_pdf(data, fileName)`
- `render_source_pdf_page(id, page, width)`
- `ocr_image_region(data, label)`

The pre-existing v3.20 checkpoint, browser-snapshot, PDF preservation, backup, and restore commands remain available.

## PDF path

`register_source_pdf` validates PDF magic and obtains a native `Windows.Data.Pdf` page count before committing. Accepted bytes are SHA-256 addressed and preserved as `source-pdfs/<sha256>.pdf` in the immutable native generation store.

Before every page render, the committed file is read within the bounded store policy and its SHA-256 is compared with the requested source ID. Rendering uses the exact 1-based source page and emits PNG bytes with bounded destination width while retaining the page aspect ratio.

## OCR path

`ocr_image_region` decodes the supplied PNG and invokes `Windows.Media.Ocr`. Its response preserves the browser pipeline's spatial contract: full text plus lines, words, and bounding rectangles. Existing browser-side crop/preprocessing/layout logic therefore stays unchanged.

## Frontend transport

`assets/js/00-native-document-transport-v3210.js` is native-first. In Tauri it invokes only the native API. When the same public frontend is intentionally launched through the standalone localhost compatibility bridge, it may use the legacy `/health`, `/pdf/load`, `/render`, and `/ocr` routes. A failed Tauri adapter does not silently fall through to localhost.

## Security and data guarantees

- Tauri allowlist explicitly names the new commands.
- No shell or arbitrary filesystem plugin is exposed.
- Native import is bounded by the existing per-file store limit.
- Source IDs are exact 64-character hexadecimal SHA-256 values.
- Errors returned by the adapter are fixed codes rather than local filesystem paths.
- The strict CSP remains unchanged and contains neither `unsafe-inline` nor `unsafe-eval`.

## Certification gate

Source integration and static tests are complete in the authoring environment. Rust/Cargo/Tauri compilation, WebView2 execution, native Windows PDF rendering, Windows OCR execution, installer behavior, and crash/restart E2E are not available here. Therefore `nativeAdapterQA` remains `pending` until the Windows builder completes the native smoke checklist.
