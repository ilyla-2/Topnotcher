# Native Data Bridge — CELE v3.20.0 / Foundation 0.2.0

The bridge preserves the browser-era compatibility stores while adding a transactional native mirror.

## Compatibility stores
- `localStorage`: `cele_topnotcher_os_v01` plus other CELE-scoped keys (`cele_` / `celeos_`).
- IndexedDB: `CELE_TOPNOTCHER_OS_ASSETS_V1`, object store `assets`.

The frontend remains responsible for CELE semantics. Native Rust treats records and assets as opaque validated bytes.

## Native API v2
Existing commands remain. Added commands:
- `save_browser_snapshot(records, assets, expectedRevision)`
- `read_browser_snapshot()`

Full snapshots preserve localStorage as `learner-state/browser-localstorage.json`. Browser assets are content-addressed by SHA-256 and indexed by `compiler/indexeddb-assets.json`. PDF bytes use `source-pdfs/<sha256>.pdf`; non-PDF assets use `compiler/<sha256>.blob`.

Every native commit uses an expected revision. Stale revisions fail closed. Asset bytes are hash-checked before native commit and again before return to the frontend.

## Checkpoint policy
Normal study saves schedule a lightweight localStorage checkpoint. Asset writes/deletes schedule a full snapshot. Separate debounce timers prevent one class of update from cancelling the other.

## Restore policy
Restores are explicit. The native archive is validated before commit, a prior native generation is retained, and the frontend then reconciles the validated localStorage + IndexedDB snapshot. The app reloads only after reconciliation succeeds.

## Current gate
Source/static validation is complete in this environment. Rust/Cargo compilation and live Tauri/WebView2 backup/restore testing remain pending. `nativeAdapterQA` must stay pending until those tests pass.
