# Security model

The native layer trusts bundled, reviewed app code only. Remote capabilities are absent. App commands are explicitly declared through `AppManifest::commands` and allowed only by the main-window capability. This matters because registered app commands otherwise default to broad app access in Tauri. Each command also checks window label and local Tauri origin. Native navigation is limited to the internal origin. No shell/process/general filesystem/HTTP permissions are granted.

CSP disallows external resources, eval, inline event execution and object embedding; inline scripts in the legacy monolith and dynamic event-handler patterns require review by the frontend integration owner. Do not set CSP null or add unsafe-eval/unsafe-inline just to boot the old app. Tauri's CSP handling may hash static scripts, but runtime-generated handlers and worker/PDF behavior must still pass platform tests. The current v3.17.1 app is not certified compatible with this policy.

No renderer-supplied OS paths are accepted. PDF/backup locations come from native dialogs. Source IDs are SHA-256 hex; filenames are never reused as storage paths. Symlinks, path separators, Windows device names, alternate streams, invalid components and case collisions are rejected in archive logical keys. Writes go to managed native generations, never application resources. PDF magic bytes are a format sanity check only; malformed PDFs remain untrusted and renderer security depends on patched WebViews.

No code execution is inferred from imported files. `read_pdf` returns original bytes plus requested page; it does not execute viewers or shell commands. It does not validate PDF page count: the final frontend's parser/viewer must do that. Review PDF rendering support on both WebViews before claiming exact-page display.

Native dialogs protect file choice and restore consent. App code/XSS could still invoke allowed checkpoint/read commands: audit existing innerHTML and imported-content handling before enabling the bridge in the final frontend. Capabilities are not a substitute for frontend injection safety. Same-OS-user tampering, admin access and filesystem races by malicious local software are outside this foundation's threat boundary; no encryption claim is made.

Backups use integrity hashes, not authenticity signatures. Release code signing and update signing require real credentials and verification. Logs include only fixed event codes and timestamps; no telemetry. Size bounds constrain memory abuse but mean large libraries need a streaming format. The retained generation policy can grow disk usage; cleanup must later be explicit and backup-aware.

Native compilation/security/runtime checks are pending. Portable tests exercise the reference contract, not Rust/Tauri execution. Reference: https://v2.tauri.app/security/capabilities/ (checked 2026-09-23).
