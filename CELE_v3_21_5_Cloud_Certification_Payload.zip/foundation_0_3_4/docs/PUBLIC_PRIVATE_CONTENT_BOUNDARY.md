# Public / private content boundary

The supplied archive was read without modification. `release/source-audit/exclusion-manifest.json` inventories **429 files**, their SHA-256 hashes and an exclusion reason. Counts: 44 source/derived-content files; 62 development corpus files; 232 development reports; 84 unreviewed resources; 6 code candidates; 1 mixed application/content HTML. These categories prioritize a conservative release boundary, not legal ownership conclusions.

No source-package file is automatically included in this foundation. `inclusion-manifest.json` records that decision. Foundation source, original diagnostic UI and icon are listed separately in the deliverable inventory. Test fixtures are synthetic and live outside the application bundle.

Static audit found embedded `OCR_PAGE_IMAGES`, `TERM_QUESTIONS`, `TERM_CONCEPTS`, and three `TRUSTED_V3141/V3142/V3143` packs in the HTML. Their loaders run at initialization and contribute 186 + 171 + 57 = 414 questions. Formula/standard/source figures and reviewer paths need their own review even if not in a PDF folder. The legacy bridge also contains optional online AI behavior. It is excluded, not launched.

Public build input is a reviewed directory plus an exact-file manifest. `stage` validates hashes, rejects symlinks/traversal and prohibited file types/folders, scans known embedded-content and credential markers, and copies only listed files. Extra source files are not copied. A pending review, missing entry, unexpected destination or changed hash blocks staging. `verify` rejects extra packaged payload files and routing mismatches. These checks supplement human rights/content review; they cannot prove an arbitrary file is cleared or free of all secrets.

The source team must provide a content-cleared frontend and licensed/original assets. This foundation does not strip banks, rewrite manifests, or alter educational content. The current monolithic HTML is deliberately blocked by embedded-content markers even if someone marks its manifest approved. Do not disable that check to publish it.

Application resources: UI/code/analytics/compiler/labs and permitted assets. User data: privately imported PDFs, opaque questions, progress, profile, mappings and backups. No broad filesystem glob includes the audit folder or user-data directories. Git ignores private formats and generated payloads; it cannot remove files already tracked or protect files uploaded outside the build process.
