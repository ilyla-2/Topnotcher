# Release checklist

## Foundation evidence

- [x] Frozen source package audited without modification.
- [x] Separate Tauri project; no private frontend/source files copied into app resources.
- [x] Exact-file inclusion/exclusion boundary and conservative payload gates.
- [x] Native checkpoint/PDF/backup/restore source, scoped commands and local logging.
- [x] Portable archive/store reference tests and safe staging tests.
- [ ] Rust compile and native unit tests — required on a configured builder.

## Frontend handoff gates

- [ ] v3.21.0 native-data-bridge frontend received, immutable source hash recorded; its QA report retained.
- [ ] Content owner clears every packaged file and all embedded content.
- [ ] Zero-private-question launch works through existing UI; PDF Intake is actionable.
- [ ] Engine/trust/duplicate/engineering logic preserved; compiler team's FALSE TRUSTED gate passes.
- [ ] Strict CSP and both WebViews supported without unsafe blanket exceptions.
- [ ] LocalStorage + IndexedDB mappings validated before any storage cutover.
- [ ] Restore write barrier/reconciliation prevents stale browser data overwrites.
- [ ] Source PDF bytes/page references verified; missing source evidence stays unavailable.
- [ ] Offline OCR/rendering adapter available or accurately unavailable in the final UI.

## Native and installer gates

- [ ] Cargo.lock resolved, committed and reviewed; dependency/license/security audit completed.
- [ ] Native app and native tests pass on Windows; macOS architecture/renderer tested separately.
- [ ] Cancel/read-only/full-disk/large-file/invalid-PDF/invalid-archive cases handled.
- [ ] Process lock, stale revisions, shutdown during commit, recovery and data retention tested.
- [ ] 100/125/150/175/200% native DPI and multiple monitors tested.
- [ ] Default startup uses system theme; saved frontend theme is honored afterwards.
- [ ] Per-user installer, Start Menu identity, direct frontend launch and offline WebView2 installation verified.
- [ ] Upgrade preserves browser storage and native root; uninstall retains data unless explicitly selected.
- [ ] Publisher, identifier, product icon, package versions and real signatures finalized and verified.
- [ ] Packaged resources inspected: no private PDFs, developer artifacts, test fixtures or credentials.
- [ ] `verify --production` passes backed by retained evidence; no updater endpoint is accidentally active.

Passing portable tests does not check native boxes. Do not call this foundation v4.0 or a production desktop release.
