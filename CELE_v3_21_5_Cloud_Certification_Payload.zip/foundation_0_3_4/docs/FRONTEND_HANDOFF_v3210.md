# CELE Topnotcher OS v3.21.0 — Native PDF/OCR Adapter Handoff

## Authoritative lineage

- Frontend: v3.20.0 Native Data Bridge public candidate.
- Desktop: Foundation 0.2.0 Native Data Bridge source.
- Compiler: `CELE-PDF-COMPILER-v1.6.1`, SHA-256 `3133e9ea5259afd12dfc8f2ba7b7cc3cdc8b4e2b089ad86bad40936e504d0ef5`.

## v3.21 change

The existing browser PDF/OCR pipeline keeps its page/crop/layout/compiler behavior. A new transport layer selects Tauri-native operations in desktop mode:

1. register and validate source PDF;
2. preserve it content-addressed in the native generation store;
3. render an exact requested source page as PNG;
4. OCR preprocessed PNG regions using the Windows OCR engine;
5. return the same spatial line/word structure expected by the existing pipeline.

The old local PowerShell service is retained only for intentional standalone browser compatibility. It is excluded from the Tauri payload.

## Non-goals / invariants

No question-bank data, source-ingestion semantics, trust states, domain classification, Coverage mathematics, Readiness logic, Study Next behavior, learner analytics, engineering calculations, NSCP content, or compiler rules were redesigned or migrated.

The browser compatibility stores from v3.20 remain unchanged: `cele_topnotcher_os_v01` plus CELE-scoped localStorage keys and `CELE_TOPNOTCHER_OS_ASSETS_V1/assets`.

## Gate state

- CSP review: approved.
- Empty-bank QA: approved.
- Redistribution review: pending for final public release ownership/review.
- Native adapter QA: pending until Windows Rust/Tauri compile and runtime smoke tests pass.

A temporary all-approved manifest may be used only to prove exact-file staging in a disposable Foundation during QA. The shipped pending manifest must continue to report `nativeAdapterQA = pending`.
