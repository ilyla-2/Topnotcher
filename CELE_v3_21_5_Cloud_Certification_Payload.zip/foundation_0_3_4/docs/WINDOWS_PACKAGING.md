# Windows packaging

Preferred initial target: x86_64, per-user NSIS. Tauri also supports WiX MSI, but this foundation selects NSIS to keep a non-admin user path; MSI support is a future deployment choice, not an asserted equivalent. Config uses `installMode: currentUser` and embeds the offline WebView2 installer. The build machine requires dependency/download access; installed app operation and runtime availability must be tested offline. Corporate policy can still block installation.

Name: CELE Topnotcher OS. Main binary: CELE-Topnotcher-OS.exe. Shell version: 0.3.0 (file/product version derives from the Tauri/Rust version). Identifier: local.cele.topnotcher.foundation. Publisher remains explicitly UNSET in release metadata, not a fictitious certificate. Configure a verified publisher in bundle metadata and finalize identifier before shipping. The Tauri product identity feeds installer/Start Menu/uninstall identity; verify the resulting registry and shortcuts on Windows. No custom uninstall deletion hooks are installed.

Prerequisites: supported Node, Python 3.11+, Rust stable/MSVC target, Microsoft C++ Build Tools and Windows SDK, WebView2. Obtain prerequisites through their official installers with authorization; this task installed no system tools. Use `npm ci`, then `cargo generate-lockfile --manifest-path src-tauri/Cargo.toml` and commit Cargo.lock after review. Run `cargo test --manifest-path src-tauri/Cargo.toml`, `cargo check --manifest-path src-tauri/Cargo.toml`, then `npm run desktop:dev`.

For a native unsigned foundation test bundle only (never a public release): `npm run tauri -- build --bundles nsis`. For the public distribution workflow after all gates: `npm run build:windows`. That wrapper refuses an absent/unreviewed payload, unset publisher, missing Cargo.lock, or unapproved native/installer/signing metadata. A boolean is a process attestation, not cryptographic evidence: release engineers must verify Authenticode and archive hashes and retain the reports.

Artifacts normally appear under `src-tauri/target/release/bundle/nsis/`; executable under `src-tauri/target/release/`. Build output is not included in this foundation ZIP. Test standard-user install, launch, shortcuts, update over prior version, same app-data root, uninstall and reinstall. User data should remain when uninstalling; actual generated NSIS behavior must be checked, especially any offered data-removal option. Never claim retention solely from this config.

On macOS, install Xcode command-line tooling and build on macOS. `tauri.macos.conf.json` selects app/dmg targets; `npm run build:macos` applies the same release gates. Signing/notarization need the actual developer identity. The disk image is an installer container, not a writable data location.

Scaling gate: test native 100/125/150/175/200% display scaling, restore/maximize/minimize, monitor moves, taskbar boundaries, dialogs, keyboard navigation and font rendering. Browser scale simulations do not certify native DPI behavior.

References checked 2026-09-23: https://v2.tauri.app/distribute/windows-installer/ and https://v2.tauri.app/reference/config/
