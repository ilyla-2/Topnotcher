# Backup and restore foundation

`.celebak` is a UTF-8 JSON archive envelope (not ZIP) with format `CELE-DESKTOP-BACKUP`, schemaVersion 1, dataSchema 1, foundationVersion, snapshotScope `native-committed-only`, and a files array. Each entry has `path`, decoded `size`, lowercase SHA-256 and canonical base64 `data`. No compression is used, so there is no decompression-bomb path. A JSON schema is included in `backup/archive.schema.json`.

Archive validation rejects unknown envelope/entry fields, unsupported schemas, invalid base64, digest/size mismatch, duplicate and case-colliding paths, traversal, Windows device names and alternate data stream syntax. Paths have exactly one allowed bucket and one portable ASCII leaf. Limits: 64 MiB per file, 128 MiB decoded total, 192 MiB archive, 4096 files. These deliberate in-memory limits are not a scalable database strategy; a streaming format upgrade is required for larger libraries.

Export snapshots while holding the storage mutex, encodes, and atomically writes via a same-directory temporary file to a user-selected destination outside the managed root. The native save dialog owns overwrite consent. A cancelled dialog does nothing. Native backup scope is explicit; live browser state is included only after a checkpoint or browser export migration. PDFs and source metadata are preserved if they have been committed. Logs, native lock, CURRENT and previous generations are not in the archive.

Restore validates all entries before writing anything. A native confirmation names the replacement scope. A new generation is created, file bytes are written and synced and read back, then CURRENT is atomically replaced. The previous generation is retained. Stale revision at commit refuses the restore. A failed write/validation leaves current data unchanged. Unreferenced generations may require manual recovery/cleanup; no automatic garbage collection is included.

Recovery: stop the app, retain the entire data directory, validate an old generation's contents and build a fresh validated archive, then restore it through the normal path. Do not edit CURRENT while the app is running. Platform power-loss durability of atomic replacement must be tested on target Windows/macOS filesystems; Linux reference fault injection is not native certification.

SHA-256 detects accidental corruption; it does not authenticate an archive or establish trusted question evidence. Backups are unencrypted and user-owned; do not publicly upload them. The restore service never upgrades imported question trust.

Implemented in Rust store.rs and main.rs. `backup/reference.py` is an independent executable reference for portable adversarial testing, not a shipped Python sidecar. Three Rust tests are included but not executed in the authoring environment.
