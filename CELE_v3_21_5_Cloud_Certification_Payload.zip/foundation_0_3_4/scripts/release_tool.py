"""Audits, exact-file frontend staging, fail-closed checks and bounded cleanup."""
import argparse,hashlib,json,re,shutil,sys,zipfile
from collections import Counter
from pathlib import Path,PurePosixPath
ROOT=Path(__file__).resolve().parents[1]
def sha(b):return hashlib.sha256(b).hexdigest()
def write(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def safe(p):
 return bool(p) and not p.startswith(('/','.')) and '\\' not in p and ':' not in p and all(x not in ('','..','.') for x in p.split('/')) and all(re.fullmatch(r'[A-Za-z0-9_-][A-Za-z0-9_.-]*',x) for x in p.split('/'))
def audit(source,out):
 rows=[]
 with zipfile.ZipFile(source) as z:
  for i in z.infolist():
   if i.is_dir():continue
   n=i.filename;b=z.read(i);s=n.lower()
   if s.endswith('.html'):c='mixed-application-and-embedded-content';why='Embedded bank/scan/term content and application code require separate clearance; not safe to publish intact.'
   elif s.endswith('.pdf') or '/trusted_content/' in s or '/nscp_sources/' in s or '/formula_sources/' in s or '/formula_figures/' in s:c='source-or-derived-content';why='Source or derivative redistribution rights not established.'
   elif '/dev/' in s or any(x in s for x in ['benchmark','corpus','fixture','stress_test']):c='development-corpus';why='Development/benchmark artifacts may contain private examples; not runtime assets.'
   elif any(x in s for x in ['qa','audit','preview','test','validation','sha256','release_notes']):c='development-report';why='Historical QA/audit material not required by the distributed runtime.'
   elif s.endswith(('.js','.ps1','.cmd','.py')):c='code-needs-review';why='Candidate code, not approved for redistribution; Windows bridge also has optional AI/network behavior.'
   else:c='unreviewed-resource';why='Conservative default exclusion until an exact-file review establishes inclusion.'
   rows.append({'path':n,'bytes':len(b),'sha256':sha(b),'decision':'exclude','category':c,'reason':why})
 write(out/'exclusion-manifest.json',{'sourceArchive':Path(source).name,'sourceArchiveSHA256':sha(Path(source).read_bytes()),'files':rows,'categoryCounts':dict(Counter(x['category'] for x in rows))})
 write(out/'inclusion-manifest.json',{'sourcePackageIncludedFiles':[],'reason':'No inherited file automatically approved. Foundation-only source is separately inventoried; final frontend requires reviewed hash manifest.','payloadManifest':'app_payload/approved.example.json'})
 print(json.dumps({'auditedFiles':len(rows),'categoryCounts':dict(Counter(x['category'] for x in rows))}))
DENY_EXT={'.pdf','.zip','.ps1','.cmd','.exe','.dll','.sqlite','.db','.pfx','.p12','.key','.celebak'}
DENY_PART={'trusted_content','nscp_sources','formula_sources','dev','tests','audit','benchmarks','node_modules'}
def inspect_payload(path,data):
 p=PurePosixPath(path)
 if not safe(path) or p.suffix.lower() in DENY_EXT or any(x.lower() in DENY_PART for x in p.parts):raise ValueError('Excluded payload path: '+path)
 if p.suffix.lower() not in {'.html','.js','.css','.json','.svg','.png','.jpg','.webp','.woff2'}:raise ValueError('Unapproved asset type: '+path)
 if p.suffix.lower() in {'.html','.js','.json','.svg'}:
  s=data.decode('utf8')
  for token in ['const OCR_PAGE_IMAGES=','const TERM_QUESTIONS=','const TRUSTED_V3141=','const TRUSTED_V3142=','const TRUSTED_V3143=','-----BEGIN PRIVATE KEY-----','-----BEGIN RSA PRIVATE KEY-----']:
   if token in s:raise ValueError('Embedded/private-content or secret marker in '+path)
  if re.search(r'AIza[0-9A-Za-z_-]{30,}|github_pat_[A-Za-z0-9_]{25,}|ghp_[A-Za-z0-9]{30,}',s):raise ValueError('Potential credential in '+path)
 # Heuristic is defense-in-depth; exact human clearance is still required.
def check_manifest(m,certification=False):
 if m.get('schemaVersion')!=1 or not isinstance(m.get('files'),list) or not m['files']:raise ValueError('Invalid manifest')
 if certification:
  for k in ['cspReview','emptyBankQA']:
   if m.get(k)!='approved':raise ValueError('Pending safety gate: '+k)
  for k in ['redistributionReview','nativeAdapterQA']:
   if m.get(k) not in {'pending','approved'}:raise ValueError('Invalid certification gate: '+k)
 else:
  for k in ['redistributionReview','cspReview','emptyBankQA','nativeAdapterQA']:
   if m.get(k)!='approved':raise ValueError('Pending gate: '+k)
 seen=set()
 for r in m['files']:
  if not safe(r['path']) or r['path'].lower() in seen or not re.fullmatch('[0-9a-f]{64}',r['sha256']) or not r.get('reason'):raise ValueError('Invalid file entry')
  seen.add(r['path'].lower())
 if m.get('entry') not in [x['path'] for x in m['files']] or not m['entry'].endswith('.html'):raise ValueError('Invalid entry')
def stage(source,manifest,root=ROOT,certification=False):
 m=json.loads(Path(manifest).read_text());check_manifest(m,certification=certification);source=Path(source).resolve();verified=[]
 for r in m['files']:
  p=source/r['path']
  if any(x.is_symlink() for x in [p,*p.parents]) or not p.is_file() or source not in p.resolve().parents:raise ValueError('Unsafe payload input')
  b=p.read_bytes()
  if sha(b)!=r['sha256']:raise ValueError('Payload hash mismatch')
  inspect_payload(r['path'],b);verified.append((r['path'],b))
 out=root/'app/payload'
 if out.exists():raise ValueError('Payload already staged. Archive it outside this project, then run clean-payload explicitly.')
 tmp=root/'app/payload-staging'
 if tmp.exists():raise ValueError('Staging leftovers require inspection')
 tmp.mkdir(parents=True)
 try:
  for n,b in verified:
   p=tmp/n;p.parent.mkdir(parents=True,exist_ok=True);p.write_bytes(b)
  tmp.rename(out);write(root/'release/active-payload.json',m);write(root/'app/payload.json',{'entry':'payload/'+m['entry'],'version':m.get('frontendVersion')})
 except Exception:
  if tmp.exists():shutil.rmtree(tmp)
  raise
 print('Staged exact reviewed payload for '+('native certification' if certification else 'release')+'; no source edits performed.')
def verify(root=ROOT,production=False):
 config=json.loads((root/'src-tauri/tauri.conf.json').read_text());meta=json.loads((root/'release/metadata.json').read_text());pkg=json.loads((root/'package.json').read_text());cargo=(root/'src-tauri/Cargo.toml').read_text()
 v=meta['foundationVersion']
 assert config['version']==pkg['version']==v and f'version = "{v}"' in cargo,'Version mismatch'
 assert config['identifier']==meta['identifier'] and config['mainBinaryName']==meta['binaryName'],'Identity mismatch'
 for n in ['app/index.html','app/desktop-api.js','src-tauri/src/main.rs','src-tauri/src/store.rs','src-tauri/build.rs','src-tauri/capabilities/main.json','src-tauri/icons/icon.ico']:
  assert (root/n).is_file(),f'Missing {n}'
 assert config['app']['security']['capabilities']==['main'] and config['app']['security']['assetProtocol']['enable'] is False,'Capability regression'
 csp=config['app']['security']['csp'];assert 'unsafe-eval' not in csp and 'unsafe-inline' not in csp and 'https:' not in csp,'CSP regression'
 allowed={'index.html','foundation.css','foundation.js','desktop-api.js','payload.json'}
 for p in (root/'app').iterdir():assert p.name in allowed|{'payload'},'Unexpected app asset '+p.name
 active=root/'release/active-payload.json'
 if active.exists():
  m=json.loads(active.read_text());check_manifest(m,certification=not production);assert not any(p.is_symlink() for p in (root/'app/payload').rglob('*')),'Payload symlink';assert json.loads((root/'app/payload.json').read_text())=={'entry':'payload/'+m['entry'],'version':m.get('frontendVersion')},'Payload routing mismatch';files={r['path']:r for r in m['files']};actual={str(p.relative_to(root/'app/payload')).replace('\\','/') for p in (root/'app/payload').rglob('*') if p.is_file()}
  assert actual==set(files),'Extra/missing payload files'
  for n,r in files.items():
   p=root/'app/payload'/n;assert not p.is_symlink() and sha(p.read_bytes())==r['sha256'],'Payload mismatch';inspect_payload(n,p.read_bytes())
 elif (root/'app/payload').exists():raise ValueError('Unmanifested payload')
 if production:
  assert active.exists(),'Final approved frontend missing'
  assert meta['publicReleaseApproved'] and meta['publisher'] and 'UNSET' not in meta['publisher'],'Release identity/review incomplete'
  assert (root/'src-tauri/Cargo.lock').exists(),'Rust lockfile missing; resolve and test on native builder'
  assert meta.get('nativeBuildValidated') and meta.get('installerValidated') and meta.get('signed'),'Native/signing/installer gates incomplete'
 print('PASS: '+('production preflight' if production else 'foundation integrity; not native-runtime or production certification'))
def clean(root=ROOT,payload=False):
 # Fixed paths only. No user-supplied recursive delete path and never user data.
 names=['app/payload','release/active-payload.json','app/payload.json'] if payload else ['src-tauri/target','src-tauri/gen','release/staging','release/artifacts']
 for n in names:
  p=root/n
  if p.is_symlink():raise ValueError('Refusing symlink cleanup')
  if p.is_dir():shutil.rmtree(p)
  elif p.exists():p.unlink()
 print('Removed generated '+('payload' if payload else 'build outputs')+' only.')
def main():
 ap=argparse.ArgumentParser();ap.add_argument('command',choices=['audit','stage','stage-certification','prepare','verify','clean','clean-payload']);ap.add_argument('--source');ap.add_argument('--manifest');ap.add_argument('--out',default=str(ROOT/'release/source-audit'));ap.add_argument('--production',action='store_true');a=ap.parse_args()
 if a.command=='audit':audit(a.source,Path(a.out))
 elif a.command=='stage':stage(a.source,a.manifest)
 elif a.command=='stage-certification':stage(a.source,a.manifest,certification=True)
 elif a.command=='clean':clean()
 elif a.command=='clean-payload':clean(payload=True)
 else:verify(production=a.production)
if __name__=='__main__':
 try:main()
 except Exception as e:print('BLOCKED:',e,file=sys.stderr);sys.exit(1)
