import {spawnSync} from 'node:child_process';
import {existsSync} from 'node:fs';
const task=process.argv[2];
function run(cmd,args){const p=spawnSync(cmd,args,{stdio:'inherit',shell:false});if(p.error){console.error(p.error.message);process.exit(1)}if(p.status!==0)process.exit(p.status??1)}
const py=process.platform==='win32'?'python':'python3';
if(task==='test'){run(py,['-m','unittest','discover','-s','tests','-v']);}
else if(['verify','clean'].includes(task)){run(py,['scripts/release_tool.py',task]);}
else if(task==='prepare'){run(py,['scripts/release_tool.py','prepare']);}
else if(task==='dev'){run(py,['scripts/release_tool.py','verify']);run(process.execPath,['node_modules/@tauri-apps/cli/tauri.js','dev']);}
else if(['windows','macos'].includes(task)){
 if((task==='windows'&&process.platform!=='win32')||(task==='macos'&&process.platform!=='darwin'))throw Error('Build on the target OS with its native prerequisites.');
 run(py,['scripts/release_tool.py','verify','--production']);
 run(process.execPath,['node_modules/@tauri-apps/cli/tauri.js','build','--bundles',task==='windows'?'nsis':'app,dmg']);
}else throw Error('Expected prepare, dev, windows or macos');
