//! Opaque data snapshots. No CELE question interpretation or trust assignment.
use std::{collections::BTreeMap, fs::{self, File, OpenOptions}, io::{Read, Write}, path::{Path,PathBuf}};
use base64::{engine::general_purpose::STANDARD,Engine};
use fs2::FileExt;
use serde::{Deserialize,Serialize};
use sha2::{Digest,Sha256};
use tempfile::NamedTempFile;
use uuid::Uuid;
pub type Result<T> = std::result::Result<T,String>;
pub const FILE_LIMIT: u64 = 64*1024*1024;
pub const TOTAL_LIMIT: u64 = 128*1024*1024;
pub const ARCHIVE_LIMIT: u64 = 192*1024*1024;
const BUCKETS: [&str;6] = ["profile","learner-state","question-bank","source-pdfs","compiler","transactions"];
pub fn hash(bytes:&[u8])->String {format!("{:x}",Sha256::digest(bytes))}
fn io<T>(x:std::io::Result<T>)->Result<T>{x.map_err(|_|"IO_FAILURE".into())}
pub fn safe_key(key:&str)->bool {
 let parts:Vec<_>=key.split('/').collect();
 if parts.len()!=2||!BUCKETS.contains(&parts[0]){return false}
 let n=parts[1];let stem=n.split('.').next().unwrap_or("").to_uppercase();
 n.len()<=120&&!n.is_empty()&&!n.starts_with('.')&&!n.ends_with('.')&&!n.contains("..")&&n.bytes().all(|c|c.is_ascii_alphanumeric()||b"._-".contains(&c))&& !["CON","PRN","AUX","NUL","COM1","COM2","COM3","COM4","COM5","COM6","COM7","COM8","COM9","LPT1","LPT2","LPT3","LPT4","LPT5","LPT6","LPT7","LPT8","LPT9"].contains(&stem.as_str())
}
fn no_link(p:&Path)->Result<()> {if io(fs::symlink_metadata(p))?.file_type().is_symlink(){Err("SYMLINK_REJECTED".into())}else{Ok(())}}
fn sync_dir(p:&Path)->Result<()> {#[cfg(unix)]{io(File::open(p))?.sync_all().map_err(|_|"SYNC_FAILURE".to_string())?;}let _=p;Ok(())}
pub fn atomic_write(path:&Path, bytes:&[u8])->Result<()> {
 let parent=path.parent().ok_or("INVALID_PATH")?;
 if path.exists(){no_link(path)?;}no_link(parent)?;
 let mut tmp=io(NamedTempFile::new_in(parent))?;io(tmp.write_all(bytes))?;io(tmp.as_file().sync_all())?;
 tmp.persist(path).map_err(|_|"ATOMIC_REPLACE_FAILURE".to_string())?;sync_dir(parent)
}
pub fn read_bounded(path:&Path,limit:u64)->Result<Vec<u8>> {
 no_link(path)?;let f=io(File::open(path))?;let m=io(f.metadata())?;if !m.is_file()||m.len()>limit{return Err("FILE_LIMIT".into())}
 let mut b=Vec::new();io(f.take(limit+1).read_to_end(&mut b))?;if b.len() as u64>limit{return Err("FILE_LIMIT".into())}Ok(b)
}
#[derive(Serialize,Deserialize)]
#[serde(deny_unknown_fields,rename_all="camelCase")]
pub struct Entry {pub path:String,pub size:u64,pub sha256:String,pub data:String}
#[derive(Serialize,Deserialize)]
#[serde(deny_unknown_fields,rename_all="camelCase")]
pub struct Archive {pub format:String,pub schema_version:u32,pub data_schema:u32,pub foundation_version:String,pub snapshot_scope:String,pub files:Vec<Entry>}
pub fn encode(files:&BTreeMap<String,Vec<u8>>)->Result<Vec<u8>> {
 validate_files(files)?;
 let a=Archive{format:"CELE-DESKTOP-BACKUP".into(),schema_version:1,data_schema:1,foundation_version:env!("CARGO_PKG_VERSION").into(),snapshot_scope:"native-committed-only".into(),files:files.iter().map(|(p,b)|Entry{path:p.clone(),size:b.len() as u64,sha256:hash(b),data:STANDARD.encode(b)}).collect()};
 serde_json::to_vec(&a).map_err(|_|"ENCODE_FAILURE".into())
}
fn validate_files(files:&BTreeMap<String,Vec<u8>>)->Result<()> {
 if files.len()>4096{return Err("ENTRY_LIMIT".into())}let mut total=0u64;let mut seen=std::collections::HashSet::new();
 for(p,b)in files {if !safe_key(p)||!seen.insert(p.to_lowercase()){return Err("INVALID_KEY".into())}if b.len() as u64>FILE_LIMIT{return Err("FILE_LIMIT".into())}total+=b.len() as u64;if total>TOTAL_LIMIT{return Err("TOTAL_LIMIT".into())}}
 Ok(())
}
pub fn decode(bytes:&[u8])->Result<BTreeMap<String,Vec<u8>>> {
 if bytes.len() as u64>ARCHIVE_LIMIT{return Err("ARCHIVE_LIMIT".into())}
 let a:Archive=serde_json::from_slice(bytes).map_err(|_|"INVALID_ARCHIVE".to_string())?;
 if a.format!="CELE-DESKTOP-BACKUP"||a.schema_version!=1||a.data_schema!=1||a.snapshot_scope!="native-committed-only"{return Err("UNSUPPORTED_ARCHIVE".into())}
 if a.files.len()>4096{return Err("ENTRY_LIMIT".into())}let mut out=BTreeMap::new();let mut total=0u64;
 for e in a.files {if !safe_key(&e.path)||e.size>FILE_LIMIT||e.data.len() as u64>(FILE_LIMIT+2)/3*4{return Err("INVALID_ENTRY".into())}let b=STANDARD.decode(&e.data).map_err(|_|"INVALID_BASE64".to_string())?;if b.len() as u64!=e.size||hash(&b)!=e.sha256{return Err("HASH_MISMATCH".into())}total+=e.size;if total>TOTAL_LIMIT{return Err("TOTAL_LIMIT".into())}if out.insert(e.path,b).is_some(){return Err("DUPLICATE_ENTRY".into())}}
 validate_files(&out)?;Ok(out)
}
pub struct Store {pub root:PathBuf,_lock:File}
impl Store {
 pub fn committed_path(&self,key:&str)->Result<PathBuf>{
  if !safe_key(key){return Err("INVALID_KEY".into())}
  let dir=self.root.join("generations").join(self.revision()?);no_link(&dir)?;let p=dir.join(key);
  if !p.exists(){return Err("SOURCE_MISSING".into())}no_link(&p)?;let m=io(fs::metadata(&p))?;if !m.is_file()||m.len()>FILE_LIMIT{return Err("FILE_LIMIT".into())}Ok(p)
 }
 pub fn open(root:PathBuf)->Result<Self>{
  io(fs::create_dir_all(&root))?;no_link(&root)?;
  for p in ["generations","logs","backups"]{let p=root.join(p);io(fs::create_dir_all(&p))?;no_link(&p)?;}
  let lp=root.join("instance.lock");if lp.exists(){no_link(&lp)?;}let lock=io(OpenOptions::new().create(true).read(true).write(true).open(lp))?;
  lock.try_lock_exclusive().map_err(|_|"ANOTHER_INSTANCE_ACTIVE".to_string())?;
  let s=Self{root,_lock:lock};if !s.root.join("CURRENT").exists(){s.commit(&BTreeMap::new(),None)?;}else{s.snapshot()?;}s.log("SHELL_START_OK");Ok(s)
 }
 pub fn revision(&self)->Result<String>{let b=read_bounded(&self.root.join("CURRENT"),64)?;let s=String::from_utf8(b).map_err(|_|"INVALID_POINTER".to_string())?;if s.len()!=32||!s.bytes().all(|c|c.is_ascii_hexdigit()){return Err("INVALID_POINTER".into())}Ok(s)}
 pub fn snapshot(&self)->Result<BTreeMap<String,Vec<u8>>>{
  let dir=self.root.join("generations").join(self.revision()?);no_link(&dir)?;let mut out=BTreeMap::new();
  for bucket in io(fs::read_dir(&dir))?{let bucket=io(bucket)?;no_link(&bucket.path())?;let name=bucket.file_name().to_string_lossy().into_owned();if !BUCKETS.contains(&name.as_str())||!io(bucket.file_type())?.is_dir(){return Err("UNEXPECTED_DATA".into())}
   for e in io(fs::read_dir(bucket.path()))?{let e=io(e)?;let k=format!("{}/{}",name,e.file_name().to_string_lossy());if !safe_key(&k){return Err("INVALID_KEY".into())}out.insert(k,read_bounded(&e.path(),FILE_LIMIT)?);validate_files(&out)?;}}
  Ok(out)
 }
 pub fn commit(&self,files:&BTreeMap<String,Vec<u8>>,expected:Option<&str>)->Result<String>{
  validate_files(files)?;if let Some(r)=expected{if self.revision()?!=r{return Err("STALE_REVISION".into())}}
  let id=Uuid::new_v4().simple().to_string();let dir=self.root.join("generations").join(&id);io(fs::create_dir(&dir))?;
  for bucket in BUCKETS{io(fs::create_dir(dir.join(bucket)))?;}
  for(k,b)in files {let p=dir.join(k);let mut f=io(OpenOptions::new().create_new(true).write(true).open(&p))?;io(f.write_all(b))?;io(f.sync_all())?;if hash(&read_bounded(&p,FILE_LIMIT)?)!=hash(b){return Err("READBACK_FAILURE".into())}}
  for bucket in BUCKETS{sync_dir(&dir.join(bucket))?;}sync_dir(&dir)?;sync_dir(&self.root.join("generations"))?;
  atomic_write(&self.root.join("CURRENT"),id.as_bytes())?;self.log("COMMIT_OK");Ok(id)
 }
 pub fn log(&self,code:&str){
  // Only native fixed event codes, never input paths, names, contents or error text.
  let allowed=["SHELL_START_OK","COMMIT_OK","CHECKPOINT_OK","PDF_IMPORT_OK","BACKUP_OK","RESTORE_OK","COMMAND_FAILED"];
  if !allowed.contains(&code){return}let p=self.root.join("logs/events.log");
  if p.exists()&&no_link(&p).is_err(){return}
  if fs::metadata(&p).map(|m|m.len()>1024*1024).unwrap_or(false){let old=p.with_extension("previous.log");if old.exists(){if no_link(&old).is_err(){return}let _=fs::remove_file(&old);}let _=fs::rename(&p,old);}
  if let Ok(mut f)=OpenOptions::new().create(true).append(true).open(p){let t=std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map(|d|d.as_secs()).unwrap_or(0);let _=writeln!(f,"{} {}",t,code);}
 }
}
#[cfg(test)]mod tests{use super::*;
 #[test]fn keys(){for k in ["../evil","source-pdfs/../x","source-pdfs/CON.pdf","source-pdfs/x:ads","source-pdfs/a/b"]{assert!(!safe_key(k))}assert!(safe_key("source-pdfs/abc.pdf"));}
 #[test]fn roundtrip_and_corruption(){let mut f=BTreeMap::new();f.insert("learner-state/sample.json".into(),b"{}".to_vec());assert_eq!(decode(&encode(&f).unwrap()).unwrap(),f);let mut a:serde_json::Value=serde_json::from_slice(&encode(&f).unwrap()).unwrap();a["files"][0]["sha256"]=serde_json::json!("bad");assert!(decode(&serde_json::to_vec(&a).unwrap()).is_err());}
 #[test]fn revisions(){let t=tempfile::tempdir().unwrap();let s=Store::open(t.path().join("data")).unwrap();let r=s.revision().unwrap();let mut f=BTreeMap::new();f.insert("profile/test.json".into(),b"{}".to_vec());s.commit(&f,Some(&r)).unwrap();assert!(s.commit(&f,Some(&r)).is_err());assert_eq!(s.snapshot().unwrap(),f);}
}
