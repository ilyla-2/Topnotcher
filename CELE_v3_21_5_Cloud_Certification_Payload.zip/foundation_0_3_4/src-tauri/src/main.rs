#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]
mod store;
mod pdf_ocr;
use std::{collections::{BTreeMap,BTreeSet},sync::Mutex};
use serde::{Deserialize,Serialize};
use serde_json::{json,Value};
use tauri::{Manager,State,WebviewWindow};
use base64::{engine::general_purpose::STANDARD,Engine};
use store::{Store,Result};
struct Desktop(Mutex<Store>);

#[derive(Deserialize)]
#[serde(deny_unknown_fields,rename_all="camelCase")]
struct BrowserAssetInput {key:String,meta:Value,updated_at:Option<u64>,mime:String,sha256:String,data:String}
#[derive(Serialize,Deserialize,Clone)]
#[serde(deny_unknown_fields,rename_all="camelCase")]
struct BrowserAssetIndex {key:String,meta:Value,updated_at:Option<u64>,mime:String,sha256:String,size:u64,path:String}
#[derive(Serialize,Deserialize)]
#[serde(deny_unknown_fields,rename_all="camelCase")]
struct BrowserAssetManifest {database:String,store:String,records:Vec<BrowserAssetIndex>}

fn guard(w:&WebviewWindow)->Result<()> {
 let u=w.url().map_err(|_|"ORIGIN_DENIED".to_string())?;
 let local=(u.scheme()=="tauri"&&u.host_str()==Some("localhost"))||(["http","https"].contains(&u.scheme())&&u.host_str()==Some("tauri.localhost"));
 if w.label()!="main"||!local{return Err("ORIGIN_DENIED".into())}Ok(())
}
fn with_store<T>(w:&WebviewWindow,s:&State<Desktop>,f:impl FnOnce(&Store)->Result<T>)->Result<T>{guard(w)?;let st=s.0.lock().map_err(|_|"LOCK_FAILURE".to_string())?;let r=f(&st);if r.is_err(){st.log("COMMAND_FAILED")}r}
fn validate_records(records:&BTreeMap<String,String>)->Result<()> {
 if !records.contains_key("cele_topnotcher_os_v01")||records.len()>100{return Err("CHECKPOINT_INVALID".into())}
 for(k,v)in records{if k.len()>120||!(k.starts_with("cele_")||k.starts_with("celeos_"))||v.len()as u64>store::FILE_LIMIT{return Err("CHECKPOINT_INVALID".into())}}
 let value:Value=serde_json::from_str(&records["cele_topnotcher_os_v01"]).map_err(|_|"LEARNER_JSON_INVALID".to_string())?;if !value.is_object(){return Err("LEARNER_JSON_INVALID".into())}Ok(())
}
fn asset_manifest(files:&BTreeMap<String,Vec<u8>>)->Result<BrowserAssetManifest>{match files.get("compiler/indexeddb-assets.json"){
 Some(b)=>{let m:BrowserAssetManifest=serde_json::from_slice(b).map_err(|_|"ASSET_MANIFEST_INVALID".to_string())?;if m.database!="CELE_TOPNOTCHER_OS_ASSETS_V1"||m.store!="assets"{return Err("ASSET_MANIFEST_INVALID".into())}Ok(m)},
 None=>Ok(BrowserAssetManifest{database:"CELE_TOPNOTCHER_OS_ASSETS_V1".into(),store:"assets".into(),records:Vec::new()})}}

#[tauri::command]
fn desktop_status(window:WebviewWindow,s:State<Desktop>)->Result<Value>{with_store(&window,&s,|st|{let f=st.snapshot()?;let assets=asset_manifest(&f)?.records.len();Ok(json!({"apiVersion":3,"dataSchema":1,"revision":st.revision()?,"nativeFiles":f.len(),"sourcePdfs":f.keys().filter(|k|k.starts_with("source-pdfs/")).count(),"browserAssets":assets,"checkpointPresent":f.contains_key("learner-state/browser-localstorage.json"),"assetCheckpointPresent":f.contains_key("compiler/indexeddb-assets.json"),"scope":"native-committed-only","cloud":false}))})}
#[tauri::command]
fn document_adapter_status(window:WebviewWindow)->Result<Value>{guard(&window)?;let x=pdf_ocr::status();Ok(json!({"ok":true,"apiVersion":3,"version":"3.21.0","rendererAvailable":x.renderer_available,"ocrAvailable":x.ocr_available,"language":x.language,"error":x.error,"backend":x.backend,"native":true,"scope":"opaque-pdf-and-image-bytes"}))}
fn valid_source_id(id:&str)->bool{id.len()==64&&id.bytes().all(|x|x.is_ascii_hexdigit())}
#[tauri::command]
fn register_source_pdf(window:WebviewWindow,s:State<Desktop>,data:String,file_name:String)->Result<Value>{
 if file_name.len()>512{return Err("PDF_NAME_INVALID".into())}guard(&window)?;if data.len()as u64>(store::FILE_LIMIT+2)/3*4{return Err("FILE_LIMIT".into())}let b=STANDARD.decode(&data).map_err(|_|"INVALID_BASE64".to_string())?;if b.len()as u64>store::FILE_LIMIT{return Err("FILE_LIMIT".into())}if !b.starts_with(b"%PDF-"){return Err("NOT_PDF".into())}let page_count=pdf_ocr::page_count_bytes(&b)?;if page_count<1||page_count>100000{return Err("PDF_PAGECOUNT_INVALID".into())}let id=store::hash(&b);
 with_store(&window,&s,|st|{let mut f=st.snapshot()?;let key=format!("source-pdfs/{}.pdf",id);let already=f.contains_key(&key);f.insert(key,b);let rev=st.commit(&f,Some(&st.revision()?))?;st.log("PDF_IMPORT_OK");Ok(json!({"ok":true,"id":id,"sha256":id,"pageCount":page_count,"revision":rev,"preserved":true,"deduplicated":already,"trust":"not-assigned"}))})
}
#[tauri::command]
fn render_source_pdf_page(window:WebviewWindow,s:State<Desktop>,id:String,page:u32,width:u32)->Result<Value>{
 if !valid_source_id(&id)||page<1||page>100000{return Err("INVALID_SOURCE_REQUEST".into())}let path=with_store(&window,&s,|st|{let p=st.committed_path(&format!("source-pdfs/{}.pdf",id))?;let b=store::read_bounded(&p,store::FILE_LIMIT)?;if store::hash(&b)!=id{return Err("SOURCE_INTEGRITY_FAILURE".into())}Ok(p)})?;let r=pdf_ocr::render_page(&path,page,width.clamp(900,3200))?;Ok(json!({"ok":true,"id":id,"page":page,"pageCount":r.page_count,"width":r.width,"height":r.height,"mime":"image/png","base64":STANDARD.encode(r.bytes)}))
}
#[tauri::command]
fn ocr_image_region(window:WebviewWindow,data:String,label:String)->Result<Value>{
 guard(&window)?;if label.len()>80{return Err("OCR_LABEL_INVALID".into())}if data.len()as u64>(store::FILE_LIMIT+2)/3*4{return Err("FILE_LIMIT".into())}let b=STANDARD.decode(&data).map_err(|_|"INVALID_BASE64".to_string())?;if b.len()as u64>store::FILE_LIMIT{return Err("FILE_LIMIT".into())}let o=pdf_ocr::ocr_png(&b)?;Ok(json!({"ok":true,"backend":o.backend,"language":o.language,"text":o.text,"lines":o.lines}))
}

#[tauri::command]
fn save_checkpoint(window:WebviewWindow,s:State<Desktop>,records:BTreeMap<String,String>,expected_revision:String)->Result<String>{with_store(&window,&s,|st|{
 validate_records(&records)?;let bytes=serde_json::to_vec(&records).map_err(|_|"ENCODE_FAILURE".to_string())?;let mut f=st.snapshot()?;f.insert("learner-state/browser-localstorage.json".into(),bytes);let r=st.commit(&f,Some(&expected_revision))?;st.log("CHECKPOINT_OK");Ok(r)
})}
#[tauri::command]
fn read_checkpoint(window:WebviewWindow,s:State<Desktop>)->Result<Value>{with_store(&window,&s,|st|{let f=st.snapshot()?;let records=match f.get("learner-state/browser-localstorage.json"){Some(b)=>serde_json::from_slice::<Value>(b).map_err(|_|"CHECKPOINT_INVALID".to_string())?,None=>Value::Null};Ok(json!({"revision":st.revision()?,"records":records}))})}
#[tauri::command]
fn save_browser_snapshot(window:WebviewWindow,s:State<Desktop>,records:BTreeMap<String,String>,assets:Vec<BrowserAssetInput>,expected_revision:String)->Result<Value>{with_store(&window,&s,|st|{
 validate_records(&records)?;if assets.len()>4096{return Err("ENTRY_LIMIT".into())}
 let mut total=0u64;let mut seen=BTreeSet::new();let mut decoded:Vec<(BrowserAssetIndex,Vec<u8>)>=Vec::new();
 for a in assets{
  if a.key.is_empty()||a.key.len()>512||!seen.insert(a.key.clone())||a.sha256.len()!=64||!a.sha256.bytes().all(|c|c.is_ascii_hexdigit()){return Err("ASSET_INVALID".into())}
  if a.data.len()as u64>(store::FILE_LIMIT+2)/3*4{return Err("FILE_LIMIT".into())}
  let b=STANDARD.decode(&a.data).map_err(|_|"INVALID_BASE64".to_string())?;let size=b.len()as u64;if size>store::FILE_LIMIT{return Err("FILE_LIMIT".into())}total+=size;if total>store::TOTAL_LIMIT{return Err("TOTAL_LIMIT".into())}
  let sha=store::hash(&b);if sha!=a.sha256{return Err("HASH_MISMATCH".into())}
  let pdf=a.mime=="application/pdf"&&b.starts_with(b"%PDF-");let path=if pdf{format!("source-pdfs/{}.pdf",sha)}else{format!("compiler/{}.blob",sha)};
  decoded.push((BrowserAssetIndex{key:a.key,meta:a.meta,updated_at:a.updated_at,mime:a.mime,sha256:sha,size,path},b));
 }
 let mut f=st.snapshot()?;
 // Prune only prior browser-managed compiler blobs. Source PDFs are content-addressed and retained conservatively.
 if let Ok(old)=asset_manifest(&f){let keep:BTreeSet<String>=decoded.iter().map(|(x,_)|x.path.clone()).collect();for r in old.records{if r.path.starts_with("compiler/")&&!keep.contains(&r.path){f.remove(&r.path);}}}
 let record_bytes=serde_json::to_vec(&records).map_err(|_|"ENCODE_FAILURE".to_string())?;f.insert("learner-state/browser-localstorage.json".into(),record_bytes);
 let mut index=Vec::with_capacity(decoded.len());for(r,b)in decoded{f.insert(r.path.clone(),b);index.push(r)}
 let manifest=BrowserAssetManifest{database:"CELE_TOPNOTCHER_OS_ASSETS_V1".into(),store:"assets".into(),records:index};f.insert("compiler/indexeddb-assets.json".into(),serde_json::to_vec(&manifest).map_err(|_|"ENCODE_FAILURE".to_string())?);
 let revision=st.commit(&f,Some(&expected_revision))?;st.log("CHECKPOINT_OK");Ok(json!({"revision":revision,"assetCount":manifest.records.len(),"scope":"browser-localstorage+indexeddb"}))
})}
#[tauri::command]
fn read_browser_snapshot(window:WebviewWindow,s:State<Desktop>)->Result<Value>{with_store(&window,&s,|st|{
 let f=st.snapshot()?;let records:Value=match f.get("learner-state/browser-localstorage.json"){Some(b)=>serde_json::from_slice(b).map_err(|_|"CHECKPOINT_INVALID".to_string())?,None=>return Err("CHECKPOINT_MISSING".into())};let m=asset_manifest(&f)?;let mut assets=Vec::with_capacity(m.records.len());
 for r in m.records{let b=f.get(&r.path).ok_or("ASSET_MISSING")?;if b.len()as u64!=r.size||store::hash(b)!=r.sha256{return Err("ASSET_INTEGRITY_FAILURE".into())}assets.push(json!({"key":r.key,"meta":r.meta,"updatedAt":r.updated_at,"mime":r.mime,"sha256":r.sha256,"data":STANDARD.encode(b)}));}
 Ok(json!({"revision":st.revision()?,"records":records,"assets":assets,"scope":"browser-localstorage+indexeddb"}))
})}
#[tauri::command]
async fn choose_pdf(window:WebviewWindow,s:State<'_,Desktop>)->Result<Value>{guard(&window)?;
 let file=match rfd::AsyncFileDialog::new().set_title("Preserve and validate a source PDF locally").add_filter("PDF",&["pdf"]).pick_file().await{Some(x)=>x,None=>return Ok(json!({"cancelled":true}))};
 let path=file.path().to_path_buf();let b=store::read_bounded(&path,store::FILE_LIMIT)?;if !b.starts_with(b"%PDF-"){return Err("NOT_PDF".into())}let page_count=pdf_ocr::page_count_bytes(&b)?;let id=store::hash(&b);with_store(&window,&s,|st|{let mut f=st.snapshot()?;f.insert(format!("source-pdfs/{}.pdf",id),b);let rev=st.commit(&f,Some(&st.revision()?))?;st.log("PDF_IMPORT_OK");Ok(json!({"id":id,"revision":rev,"pageCount":page_count,"pageCountValidated":true,"trust":"not-assigned"}))})
}
#[tauri::command]
fn read_pdf(window:WebviewWindow,s:State<Desktop>,id:String,page:u32)->Result<Value>{with_store(&window,&s,|st|{if !valid_source_id(&id)||page<1||page>100000{return Err("INVALID_SOURCE_REQUEST".into())}let f=st.snapshot()?;let b=f.get(&format!("source-pdfs/{}.pdf",id)).ok_or("SOURCE_MISSING")?;if store::hash(b)!=id{return Err("SOURCE_INTEGRITY_FAILURE".into())}Ok(json!({"id":id,"requestedPage":page,"pageCountValidated":false,"mime":"application/pdf","base64":STANDARD.encode(b)}))})}
#[tauri::command]
async fn export_backup(window:WebviewWindow,s:State<'_,Desktop>)->Result<Value>{guard(&window)?;
 let file=match rfd::AsyncFileDialog::new().set_title("Export native committed data").set_file_name("Topnotcher.celebak").add_filter("CELE backup",&["celebak"]).save_file().await{Some(x)=>x,None=>return Ok(json!({"cancelled":true}))};
 with_store(&window,&s,|st|{let bytes=store::encode(&st.snapshot()?)?;let dest=file.path();if dest.starts_with(&st.root){return Err("BACKUP_DESTINATION_MUST_BE_OUTSIDE_DATA_ROOT".into())}store::atomic_write(dest,&bytes)?;st.log("BACKUP_OK");Ok(json!({"exported":true,"scope":"native-committed-only"}))})
}
#[tauri::command]
async fn restore_backup(window:WebviewWindow,s:State<'_,Desktop>)->Result<Value>{guard(&window)?;
 let file=match rfd::AsyncFileDialog::new().set_title("Select Topnotcher backup").add_filter("CELE backup",&["celebak"]).pick_file().await{Some(x)=>x,None=>return Ok(json!({"cancelled":true}))};
 let bytes=store::read_bounded(file.path(),store::ARCHIVE_LIMIT)?;let files=store::decode(&bytes)?;
 let revision=with_store(&window,&s,|st|st.revision())?;
 let yes=rfd::AsyncMessageDialog::new().set_title("Restore validated native snapshot?").set_description("This replaces the active native snapshot. The prior generation is retained. The Topnotcher frontend will reconcile localStorage and IndexedDB after the native restore succeeds.").set_buttons(rfd::MessageButtons::YesNo).show().await;
 if yes!=rfd::MessageDialogResult::Yes{return Ok(json!({"cancelled":true}))}
 with_store(&window,&s,|st|{let revision=st.commit(&files,Some(&revision))?;st.log("RESTORE_OK");Ok(json!({"restored":true,"revision":revision,"frontendReconciliationRequired":true}))})
}
fn main(){
 let r=tauri::Builder::default().setup(|app|{
  let root=app.path().app_data_dir()?.join("Topnotcher Data");
  let st=Store::open(root).map_err(std::io::Error::other)?;
  let panic_log=st.root.join("logs/events.log");
  std::panic::set_hook(Box::new(move |_| {
   use std::io::Write;
   if std::fs::symlink_metadata(&panic_log).map(|m|m.file_type().is_symlink()).unwrap_or(false){return}
   if let Ok(mut f)=std::fs::OpenOptions::new().create(true).append(true).open(&panic_log){let _=writeln!(f,"NATIVE_PANIC");}
  }));
  app.manage(Desktop(Mutex::new(st)));
  tauri::WebviewWindowBuilder::from_config(app.handle(), &app.config().app.windows[0])?
   .on_navigation(|u| (u.scheme()=="tauri"&&u.host_str()==Some("localhost")) || (["http","https"].contains(&u.scheme())&&u.host_str()==Some("tauri.localhost")))
   .build()?;
  Ok(())
 })
 .invoke_handler(tauri::generate_handler![desktop_status,document_adapter_status,register_source_pdf,render_source_pdf_page,ocr_image_region,save_checkpoint,read_checkpoint,save_browser_snapshot,read_browser_snapshot,choose_pdf,read_pdf,export_backup,restore_backup])
 .run(tauri::generate_context!());
 if r.is_err(){let _=rfd::MessageDialog::new().set_title("Topnotcher could not start").set_description("Native startup failed. Check that no other instance is running and that the application data location is writable. No user data was reset.").show();}
}
