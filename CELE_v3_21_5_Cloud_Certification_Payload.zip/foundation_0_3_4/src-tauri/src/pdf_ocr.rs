//! Native PDF page validation/rendering and OCR transport.
//! Opaque bytes only: no CELE question interpretation, classification, trust, or answer logic.
use std::path::Path;
use serde::Serialize;

pub type Result<T> = std::result::Result<T,String>;

#[derive(Serialize)]
#[serde(rename_all="camelCase")]
pub struct AdapterStatus {pub renderer_available:bool,pub ocr_available:bool,pub language:String,pub error:String,pub backend:String}
#[derive(Serialize)]
#[serde(rename_all="camelCase")]
pub struct RenderedPage {#[serde(skip_serializing)]pub bytes:Vec<u8>,pub width:u32,pub height:u32,pub page_count:u32}
#[derive(Serialize)]
#[serde(rename_all="camelCase")]
pub struct OcrBounds {pub x:f64,pub y:f64,pub width:f64,pub height:f64}
#[derive(Serialize)]
#[serde(rename_all="camelCase")]
pub struct OcrWord {pub text:String,pub bounds:OcrBounds}
#[derive(Serialize)]
#[serde(rename_all="camelCase")]
pub struct OcrLine {pub text:String,pub words:Vec<OcrWord>}
#[derive(Serialize)]
#[serde(rename_all="camelCase")]
pub struct OcrOutput {pub backend:String,pub language:String,pub text:String,pub lines:Vec<OcrLine>}

#[cfg(target_os="windows")]
mod imp {
 use super::*;
 use std::{fs,io::Write};
 use tempfile::NamedTempFile;
 use windows::{
  core::HSTRING,
  Data::Pdf::{PdfDocument,PdfPageRenderOptions},
  Graphics::Imaging::{BitmapDecoder,BitmapEncoder},
  Media::Ocr::OcrEngine,
  Storage::{FileAccessMode,StorageFile},
  Storage::Streams::{DataReader,InMemoryRandomAccessStream},
 };

 fn fail(code:&str)->String{code.to_string()}
 fn storage_file(path:&Path,code:&str)->Result<StorageFile>{
  let p=fs::canonicalize(path).map_err(|_|fail(code))?;
  let mut s=p.to_string_lossy().into_owned();if let Some(x)=s.strip_prefix(r"\\?\"){s=x.to_string()}
  StorageFile::GetFileFromPathAsync(&HSTRING::from(s)).map_err(|_|fail(code))?.join().map_err(|_|fail(code))
 }
 fn load_pdf(path:&Path)->Result<PdfDocument>{let f=storage_file(path,"PDF_OPEN_FAILURE")?;PdfDocument::LoadFromFileAsync(&f).map_err(|_|fail("PDF_OPEN_FAILURE"))?.join().map_err(|_|fail("PDF_OPEN_FAILURE"))}
 fn read_stream(stream:&InMemoryRandomAccessStream)->Result<Vec<u8>>{
  stream.Seek(0).map_err(|_|fail("PDF_RENDER_FAILURE"))?;let size=stream.Size().map_err(|_|fail("PDF_RENDER_FAILURE"))?;
  if size>u32::MAX as u64{return Err(fail("RENDER_LIMIT"))}
  let input=stream.GetInputStreamAt(0).map_err(|_|fail("PDF_RENDER_FAILURE"))?;let reader=DataReader::CreateDataReader(&input).map_err(|_|fail("PDF_RENDER_FAILURE"))?;
  let loaded=reader.LoadAsync(size as u32).map_err(|_|fail("PDF_RENDER_FAILURE"))?.join().map_err(|_|fail("PDF_RENDER_FAILURE"))?;
  let mut out=vec![0u8;loaded as usize];reader.ReadBytes(&mut out).map_err(|_|fail("PDF_RENDER_FAILURE"))?;let _=reader.DetachStream();let _=reader.Close();Ok(out)
 }
 fn temp_with(bytes:&[u8],suffix:&str,code:&str)->Result<NamedTempFile>{
  let mut f=tempfile::Builder::new().prefix("cele-native-").suffix(suffix).tempfile().map_err(|_|fail(code))?;f.write_all(bytes).map_err(|_|fail(code))?;f.as_file().sync_all().map_err(|_|fail(code))?;Ok(f)
 }
 pub fn status()->AdapterStatus{
  let o=OcrEngine::TryCreateFromUserProfileLanguages();
  match o{Ok(engine)=>{let lang=engine.RecognizerLanguage().and_then(|x|x.LanguageTag()).map(|x|x.to_string_lossy()).unwrap_or_default();AdapterStatus{renderer_available:true,ocr_available:true,language:lang,error:String::new(),backend:"windows-data-pdf+windows-media-ocr".into()}},Err(_)=>AdapterStatus{renderer_available:true,ocr_available:false,language:String::new(),error:"Windows OCR has no usable recognizer language.".into(),backend:"windows-data-pdf+windows-media-ocr".into()}}
 }
 pub fn page_count(path:&Path)->Result<u32>{let d=load_pdf(path)?;d.PageCount().map_err(|_|fail("PDF_PAGECOUNT_FAILURE"))}
 pub fn page_count_bytes(bytes:&[u8])->Result<u32>{let f=temp_with(bytes,".pdf","PDF_TEMP_FAILURE")?;page_count(f.path())}
 pub fn render_page(path:&Path,page:u32,width:u32)->Result<RenderedPage>{
  let d=load_pdf(path)?;let count=d.PageCount().map_err(|_|fail("PDF_PAGECOUNT_FAILURE"))?;if page<1||page>count{return Err(fail("PDF_PAGE_OUT_OF_RANGE"))}
  let p=d.GetPage(page-1).map_err(|_|fail("PDF_RENDER_FAILURE"))?;let sz=p.Size().map_err(|_|fail("PDF_RENDER_FAILURE"))?;let w=width.clamp(900,3200);let h=((w as f64)*(sz.Height.max(1.0) as f64)/(sz.Width.max(1.0) as f64)).round().max(1.0) as u32;
  let opt=PdfPageRenderOptions::new().map_err(|_|fail("PDF_RENDER_FAILURE"))?;opt.SetBitmapEncoderId(BitmapEncoder::PngEncoderId().map_err(|_|fail("PDF_RENDER_FAILURE"))?).map_err(|_|fail("PDF_RENDER_FAILURE"))?;opt.SetDestinationWidth(w).map_err(|_|fail("PDF_RENDER_FAILURE"))?;opt.SetDestinationHeight(h).map_err(|_|fail("PDF_RENDER_FAILURE"))?;
  let mem=InMemoryRandomAccessStream::new().map_err(|_|fail("PDF_RENDER_FAILURE"))?;p.RenderWithOptionsToStreamAsync(&mem,&opt).map_err(|_|fail("PDF_RENDER_FAILURE"))?.join().map_err(|_|fail("PDF_RENDER_FAILURE"))?;let bytes=read_stream(&mem)?;let _=p.Close();let _=mem.Close();if bytes.is_empty(){return Err(fail("PDF_RENDER_EMPTY"))}Ok(RenderedPage{bytes,width:w,height:h,page_count:count})
 }
 pub fn ocr_png(bytes:&[u8])->Result<OcrOutput>{
  if bytes.is_empty(){return Err(fail("OCR_EMPTY_IMAGE"))}let f=temp_with(bytes,".png","OCR_TEMP_FAILURE")?;let sf=storage_file(f.path(),"OCR_IMAGE_OPEN_FAILURE")?;let stream=sf.OpenAsync(FileAccessMode::Read).map_err(|_|fail("OCR_IMAGE_OPEN_FAILURE"))?.join().map_err(|_|fail("OCR_IMAGE_OPEN_FAILURE"))?;
  let decoder=BitmapDecoder::CreateAsync(&stream).map_err(|_|fail("OCR_IMAGE_DECODE_FAILURE"))?.join().map_err(|_|fail("OCR_IMAGE_DECODE_FAILURE"))?;let bitmap=decoder.GetSoftwareBitmapAsync().map_err(|_|fail("OCR_IMAGE_DECODE_FAILURE"))?.join().map_err(|_|fail("OCR_IMAGE_DECODE_FAILURE"))?;
  let engine=OcrEngine::TryCreateFromUserProfileLanguages().map_err(|_|fail("OCR_LANGUAGE_UNAVAILABLE"))?;let result=engine.RecognizeAsync(&bitmap).map_err(|_|fail("OCR_FAILURE"))?.join().map_err(|_|fail("OCR_FAILURE"))?;let language=engine.RecognizerLanguage().and_then(|x|x.LanguageTag()).map(|x|x.to_string_lossy()).unwrap_or_default();let text=result.Text().map_err(|_|fail("OCR_FAILURE"))?.to_string_lossy();
  let view=result.Lines().map_err(|_|fail("OCR_FAILURE"))?;let mut lines=Vec::new();for i in 0..view.Size().map_err(|_|fail("OCR_FAILURE"))?{let ln=view.GetAt(i).map_err(|_|fail("OCR_FAILURE"))?;let words_view=ln.Words().map_err(|_|fail("OCR_FAILURE"))?;let mut words=Vec::new();for j in 0..words_view.Size().map_err(|_|fail("OCR_FAILURE"))?{let w=words_view.GetAt(j).map_err(|_|fail("OCR_FAILURE"))?;let r=w.BoundingRect().map_err(|_|fail("OCR_FAILURE"))?;words.push(OcrWord{text:w.Text().map_err(|_|fail("OCR_FAILURE"))?.to_string_lossy(),bounds:OcrBounds{x:r.X as f64,y:r.Y as f64,width:r.Width as f64,height:r.Height as f64}})}lines.push(OcrLine{text:ln.Text().map_err(|_|fail("OCR_FAILURE"))?.to_string_lossy(),words})}
  let _=bitmap.Close();let _=stream.Close();Ok(OcrOutput{backend:"windows-media-ocr".into(),language,text,lines})
 }
}

#[cfg(not(target_os="windows"))]
mod imp {
 use super::*;
 pub fn status()->AdapterStatus{AdapterStatus{renderer_available:false,ocr_available:false,language:String::new(),error:"Native PDF/OCR adapter is currently Windows-only.".into(),backend:"unsupported-platform".into()}}
 pub fn page_count(_:&Path)->Result<u32>{Err("PDF_RENDERER_UNSUPPORTED".into())}
 pub fn page_count_bytes(_:&[u8])->Result<u32>{Err("PDF_RENDERER_UNSUPPORTED".into())}
 pub fn render_page(_:&Path,_:u32,_:u32)->Result<RenderedPage>{Err("PDF_RENDERER_UNSUPPORTED".into())}
 pub fn ocr_png(_:&[u8])->Result<OcrOutput>{Err("OCR_UNSUPPORTED".into())}
}
pub use imp::*;
