fn main() {
    tauri_build::try_build(tauri_build::Attributes::new().app_manifest(
        tauri_build::AppManifest::new().commands(&[
            "desktop_status", "save_checkpoint", "read_checkpoint", "choose_pdf",
            "read_pdf", "export_backup", "restore_backup"
        ])
    )).expect("desktop build manifest failed");
}
