#[path = "../src/pdf_ocr.rs"]
mod pdf_ocr;
#[path = "../src/store.rs"]
mod store;

#[cfg(target_os = "windows")]
mod windows_cert {
    use super::{pdf_ocr, store};
    use serde::Serialize;
    use serde_json::json;
    use std::{collections::BTreeMap, env, fs, path::PathBuf};
    use windows::Win32::System::WinRT::{RoInitialize, RoUninitialize, RO_INIT_MULTITHREADED};

    const PDF: &[u8] = include_bytes!("../../tests/fixtures/native-cert-two-page.pdf");
    const OCR_PNG: &[u8] = include_bytes!("../../tests/fixtures/native-cert-ocr.png");
    const NOT_PDF: &[u8] = include_bytes!("../../tests/fixtures/not-a-pdf.bin");

    #[derive(Serialize)]
    #[serde(rename_all = "camelCase")]
    struct Check {
        id: &'static str,
        status: &'static str,
        detail: String,
    }

    #[derive(Serialize)]
    #[serde(rename_all = "camelCase")]
    struct Report {
        schema_version: u32,
        phase: &'static str,
        adapter_version: &'static str,
        foundation_version: &'static str,
        platform: &'static str,
        architecture: &'static str,
        status: &'static str,
        ocr_language: String,
        checks: Vec<Check>,
    }

    struct WinRtGuard;
    impl Drop for WinRtGuard {
        fn drop(&mut self) {
            unsafe { RoUninitialize() };
        }
    }

    fn push(checks: &mut Vec<Check>, id: &'static str, ok: bool, detail: impl Into<String>) {
        checks.push(Check {
            id,
            status: if ok { "PASS" } else { "FAIL" },
            detail: detail.into(),
        });
    }

    fn blocked(checks: &mut Vec<Check>, id: &'static str, detail: impl Into<String>) {
        checks.push(Check { id, status: "BLOCKED", detail: detail.into() });
    }

    fn report_path() -> PathBuf {
        if let Ok(p) = env::var("CELE_CERT_REPORT") {
            return PathBuf::from(p);
        }
        PathBuf::from(env!("CARGO_MANIFEST_DIR"))
            .parent()
            .expect("foundation root")
            .join("release/native-certification/native-runtime-report.json")
    }

    fn write_report(checks: Vec<Check>, ocr_language: String) -> &'static str {
        let status = if checks.iter().any(|c| c.status == "FAIL") {
            "FAIL"
        } else if checks.iter().any(|c| c.status == "BLOCKED") {
            "BLOCKED"
        } else {
            "PASS"
        };
        let report = Report {
            schema_version: 1,
            phase: "v3.21.2-cloud-capable-native-runtime-certification",
            adapter_version: "3.21.0",
            foundation_version: env!("CARGO_PKG_VERSION"),
            platform: "windows",
            architecture: env::consts::ARCH,
            status,
            ocr_language,
            checks,
        };
        let path = report_path();
        if let Some(parent) = path.parent() {
            fs::create_dir_all(parent).expect("create certification report directory");
        }
        fs::write(&path, serde_json::to_vec_pretty(&report).expect("serialize certification report"))
            .expect("write certification report");
        status
    }

    #[test]
    fn native_runtime_certificate() {
        let mut checks = Vec::new();
        if unsafe { RoInitialize(RO_INIT_MULTITHREADED) }.is_err() {
            push(&mut checks, "winrt-initialize", false, "RoInitialize failed");
            let status = write_report(checks, String::new());
            panic!("native certification {status}");
        }
        let _winrt = WinRtGuard;
        push(&mut checks, "winrt-initialize", true, "Windows Runtime initialized on certification thread");

        let adapter = pdf_ocr::status();
        push(
            &mut checks,
            "adapter-backend",
            adapter.renderer_available && adapter.backend == "windows-data-pdf+windows-media-ocr",
            format!("backend={} rendererAvailable={}", adapter.backend, adapter.renderer_available),
        );

        match pdf_ocr::page_count_bytes(PDF) {
            Ok(2) => push(&mut checks, "pdf-page-count", true, "native page count returned exactly 2"),
            Ok(n) => push(&mut checks, "pdf-page-count", false, format!("expected 2 pages, got {n}")),
            Err(code) => push(&mut checks, "pdf-page-count", false, format!("native page count failed with {code}")),
        }
        push(
            &mut checks,
            "pdf-invalid-rejection",
            pdf_ocr::page_count_bytes(NOT_PDF).is_err(),
            "invalid fixture is rejected by Windows.Data.Pdf",
        );

        let temp = tempfile::tempdir().expect("native cert temp directory");
        let pdf_path = temp.path().join("source.pdf");
        fs::write(&pdf_path, PDF).expect("write pdf fixture");
        for (page, id) in [(1, "pdf-render-page-1"), (2, "pdf-render-page-2")] {
            match pdf_ocr::render_page(&pdf_path, page, 1200) {
                Ok(r) => {
                    let png = r.bytes.starts_with(b"\x89PNG\r\n\x1a\n");
                    push(
                        &mut checks,
                        id,
                        png && r.width == 1200 && r.height > 0 && r.page_count == 2,
                        format!("png={png} width={} height={} pageCount={}", r.width, r.height, r.page_count),
                    );
                }
                Err(code) => push(&mut checks, id, false, format!("render failed with {code}")),
            }
        }
        push(
            &mut checks,
            "pdf-page-range-rejection",
            matches!(pdf_ocr::render_page(&pdf_path, 3, 1200), Err(ref e) if e == "PDF_PAGE_OUT_OF_RANGE"),
            "page 3 of a 2-page fixture is rejected",
        );
        match pdf_ocr::render_page(&pdf_path, 1, 100) {
            Ok(r) => push(&mut checks, "pdf-render-width-bound", r.width == 900, format!("bounded width={}", r.width)),
            Err(code) => push(&mut checks, "pdf-render-width-bound", false, format!("render failed with {code}")),
        }

        let mut ocr_language = adapter.language.clone();
        if adapter.ocr_available {
            match pdf_ocr::ocr_png(OCR_PNG) {
                Ok(o) => {
                    ocr_language = o.language.clone();
                    let normalized = o.text.to_ascii_uppercase();
                    let text_ok = normalized.contains("CELE") && normalized.contains("2026") && normalized.contains("OCR");
                    push(&mut checks, "ocr-text", text_ok, format!("recognized {} characters", o.text.chars().count()));
                    let words: Vec<_> = o.lines.iter().flat_map(|l| l.words.iter()).collect();
                    let geometry_ok = !o.lines.is_empty()
                        && !words.is_empty()
                        && words.iter().all(|w| w.bounds.width > 0.0 && w.bounds.height > 0.0);
                    push(
                        &mut checks,
                        "ocr-spatial-geometry",
                        geometry_ok,
                        format!("lines={} words={}", o.lines.len(), words.len()),
                    );
                }
                Err(code) => {
                    push(&mut checks, "ocr-text", false, format!("OCR failed with {code}"));
                    push(&mut checks, "ocr-spatial-geometry", false, "OCR output unavailable");
                }
            }
        } else {
            let unavailable_contract = matches!(pdf_ocr::ocr_png(OCR_PNG), Err(ref e) if e == "OCR_LANGUAGE_UNAVAILABLE");
            push(
                &mut checks,
                "ocr-language-unavailable-contract",
                unavailable_contract,
                "host without a usable OCR language returns the stable adapter error code",
            );
            blocked(
                &mut checks,
                "ocr-runtime",
                "Windows OCR has no usable recognizer language on this host; install an OCR-capable language and rerun",
            );
        }

        let store_root = temp.path().join("store");
        match store::Store::open(store_root) {
            Ok(st) => {
                let r0 = st.revision().expect("initial revision");
                let mut learner = BTreeMap::new();
                learner.insert("learner-state/browser-localstorage.json".to_string(), br#"{"cele_topnotcher_os_v01":"{}"}"#.to_vec());
                let r1 = st.commit(&learner, Some(&r0)).expect("learner commit");
                let mut with_pdf = st.snapshot().expect("snapshot after learner commit");
                let pdf_hash = store::hash(PDF);
                with_pdf.insert(format!("source-pdfs/{pdf_hash}.pdf"), PDF.to_vec());
                let r2 = st.commit(&with_pdf, Some(&r1)).expect("pdf commit");
                let preserved = st.root.join("generations").join(&r1).is_dir() && st.root.join("generations").join(&r2).is_dir();
                push(&mut checks, "store-generation-retention", preserved, "pre-PDF and post-PDF generations both remain present");
                push(
                    &mut checks,
                    "store-stale-revision-rejection",
                    matches!(st.commit(&with_pdf, Some(&r1)), Err(ref e) if e == "STALE_REVISION"),
                    "expected-revision commit rejects a stale writer",
                );
                let snap = st.snapshot().expect("post-PDF snapshot");
                let source_ok = snap
                    .get(&format!("source-pdfs/{pdf_hash}.pdf"))
                    .map(|b| store::hash(b) == pdf_hash)
                    .unwrap_or(false);
                push(&mut checks, "store-source-sha256", source_ok, "content-addressed source PDF rehashes to its key");
                let encoded = store::encode(&snap).expect("encode backup");
                let roundtrip_ok = store::decode(&encoded).map(|x| x == snap).unwrap_or(false);
                push(&mut checks, "backup-roundtrip", roundtrip_ok, "native snapshot backup round-trips byte-for-byte");
                let mut damaged: serde_json::Value = serde_json::from_slice(&encoded).expect("backup json");
                damaged["files"][0]["sha256"] = json!("00".repeat(32));
                let corrupt = serde_json::to_vec(&damaged).expect("corrupt backup json");
                push(
                    &mut checks,
                    "backup-corruption-rejection",
                    matches!(store::decode(&corrupt), Err(ref e) if e == "HASH_MISMATCH"),
                    "tampered backup is rejected before store commit",
                );
            }
            Err(code) => {
                for id in [
                    "store-generation-retention",
                    "store-stale-revision-rejection",
                    "store-source-sha256",
                    "backup-roundtrip",
                    "backup-corruption-rejection",
                ] {
                    push(&mut checks, id, false, format!("native store could not open: {code}"));
                }
            }
        }

        let status = write_report(checks, ocr_language);
        if status == "FAIL" {
            panic!("native certification FAIL; inspect native-runtime-report.json");
        }
        if status == "BLOCKED" {
            eprintln!("native certification BLOCKED; inspect native-runtime-report.json");
        }
    }
}

#[cfg(not(target_os = "windows"))]
#[test]
fn native_runtime_certificate_requires_windows() {
    panic!("v3.21.1 native runtime certification must run on Windows");
}
