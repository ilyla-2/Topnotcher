Original geometric placeholder icon for foundation builds. Replace with approved product artwork before public release; preserve file names. No inherited source artwork is used.
