@echo off
setlocal
cd /d "%~dp0"
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "scripts\windows-certify-v3211.ps1"
set EXITCODE=%ERRORLEVEL%
echo.
if "%EXITCODE%"=="0" (
  echo Native adapter certification completed successfully.
) else (
  echo Certification did not approve the native adapter. Exit code: %EXITCODE%
  echo See release\native-certification\windows-certification-summary.json
)
exit /b %EXITCODE%
