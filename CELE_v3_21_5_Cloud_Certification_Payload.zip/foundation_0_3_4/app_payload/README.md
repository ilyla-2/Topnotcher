# Replaceable frontend slot

No authoritative frontend is bundled here. Keep final staging input elsewhere.
`python scripts/release_tool.py stage --source <reviewed-directory> --manifest <approved-manifest.json>`
imports exact reviewed files into generated `app/payload/`, preserving bytes.
See `docs/FRONTEND_HANDOFF_v3172.md`. Never paste the private v3.17.1 HTML into a public build.
