# CELE Topnotcher OS — Desktop Release Foundation

Separate Tauri 2 infrastructure, foundation version **0.3.4**. This is not v4.0 or a production installer. It preserves the v3.21.0 Windows native PDF/OCR adapter and adds the v3.21.3 Windows native-runtime certification harness; native approval still requires an actual Windows run. No private reviewer corpus is bundled.

Start with `docs/WINDOWS_NATIVE_CERTIFICATION_v3211.md`, `docs/MANUAL_WEBVIEW2_IPC_SMOKE_v3211.md`, `docs/FRONTEND_HANDOFF_v3210.md`, `docs/NATIVE_PDF_OCR_ADAPTER_v3210.md`, and `docs/IMPLEMENTATION_REPORT.md`.

## What is here

- Tauri window, narrow native commands, offline per-user NSIS configuration, macOS build layout.
- Windows-native PDF validation/page rendering (`Windows.Data.Pdf`) and OCR (`Windows.Media.Ocr`) command source, preserving the existing browser pipeline contract.
- Immutable native data generations, optimistic revisions, file locking, source-PDF IDs, bounded archive validation, transactional restore and fixed-code local logging.
- Content-free diagnostic page, replaceable payload slot and exact-file staging tool.
- Full source-package exclusion manifest with reasons and hashes; public inclusion boundary.
- Portable backup reference implementation and adversarial tests, browser export utility, release preflight, update template, documentation and native test gates.


## v3.21.3 certification command

For the first real Windows x64 certification run, keep the extracted public frontend beside this Foundation folder as `frontend_v3_21_0`, then double-click `RUN_WINDOWS_CERTIFICATION.cmd` or run:

```powershell
npm run certify:windows
```

The runner uses an isolated certification application identifier, stages the exact reviewed v3.21.0 payload, compiles Rust, runs native PDF/OCR/store tests, builds the Tauri release executable, performs launch → forced termination → relaunch smoke, and writes evidence under `release/native-certification/`. Even on PASS, final `nativeAdapterQA` stays pending until the real WebView2 → Tauri IPC/UI smoke is observed; installer/signing/redistribution remain separate gates.

## Commands

Run from this directory. Prerequisites: Python 3.11+, Node LTS, and (for native builds) Rust stable plus the target OS's Tauri prerequisites. No global npm package is needed.

```sh
npm ci
python scripts/release_tool.py verify
python -m unittest discover -s tests -v
npm run desktop:dev
```

On systems where `python` is named `python3`, use that command instead. npm's task runner handles Windows vs Unix Python names, including verify/test/clean shortcuts.

Native development is a diagnostic shell until a payload is staged. Builds initially require dependency downloads; installed operation has no cloud dependency. Offline Windows installer configuration embeds the WebView2 installer rather than fetching it at first use.

```sh
# Certification-only staging; preserves pending native/release gates and can never satisfy production preflight
python scripts/release_tool.py stage-certification --source /path/to/reviewed-frontend --manifest app_payload/v3_21_0.pending.json
# Release staging; requires every manifest review gate approved
python scripts/release_tool.py stage --source /path/to/reviewed-frontend --manifest /path/to/approved.json
# On Windows after native/signing/review release gates:
npm run build:windows
# On macOS after the same gates:
npm run build:macos
# Fixed generated build directories only; never user data:
python scripts/release_tool.py clean
```

**Native compile/run is still not certified in the authoring environment:** Rust/Cargo and native packaging prerequisites were unavailable. The v3.21.3 harness is therefore shipped pending its Windows execution. See the report for checks actually executed. Production commands intentionally refuse the placeholder frontend, unset publisher and missing release approvals. Do not bypass these gates to publish the current private application.


## Browser-only cloud certification

For restricted corporate devices, do not install Rust/Node/Visual Studio locally. Use the supplied GitHub Actions workflow with `CELE_v3_21_2_Cloud_Certification_Payload.zip`. The hosted Windows runner executes the static suite, Rust native PDF/OCR/store certificate, Tauri release build, and NSIS packaging. It intentionally does **not** certify interactive WebView2/Tauri IPC, native dialogs, scaling, or installed-app lifecycle. Those remain pending until an unrestricted Windows desktop is available.


## v3.21.3 cloud harness hardening

This revision does not modify the frozen v3.21.0 frontend. It fixes certification observability by persisting the full portable unittest output into `release/native-certification/portable-regression-output.txt`. Windows error 1314 during the reference-model symlink test is recorded as a skipped runner-capability check rather than a CELE product failure; final native adapter approval remains impossible from cloud CI alone.
