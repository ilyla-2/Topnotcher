"""Executable portable reference for the native archive contract; NOT an app sidecar."""
import base64,hashlib,json,os,re,stat,tempfile,uuid
from pathlib import Path
FILE_LIMIT=64*1024*1024;TOTAL_LIMIT=128*1024*1024;ARCHIVE_LIMIT=192*1024*1024
BUCKETS={'profile','learner-state','question-bank','source-pdfs','compiler','transactions'}
def safe_key(key):
 parts=key.split('/')
 if len(parts)!=2 or parts[0] not in BUCKETS:return False
 n=parts[1];stem=n.split('.')[0].upper()
 return bool(re.fullmatch(r'[A-Za-z0-9][A-Za-z0-9._-]{0,119}',n)) and '..' not in n and not n.endswith('.') and stem not in {'CON','PRN','AUX','NUL',*[f'COM{i}' for i in range(1,10)],*[f'LPT{i}' for i in range(1,10)]}
def validate(files):
 if len(files)>4096:raise ValueError('ENTRY_LIMIT')
 seen=set();total=0
 for p,b in files.items():
  if not safe_key(p) or p.lower() in seen:raise ValueError('INVALID_KEY')
  seen.add(p.lower());total+=len(b)
  if len(b)>FILE_LIMIT or total>TOTAL_LIMIT:raise ValueError('SIZE_LIMIT')
def encode(files):
 validate(files)
 return json.dumps({'format':'CELE-DESKTOP-BACKUP','schemaVersion':1,'dataSchema':1,'foundationVersion':'0.3.0','snapshotScope':'native-committed-only','files':[{'path':p,'size':len(b),'sha256':hashlib.sha256(b).hexdigest(),'data':base64.b64encode(b).decode()} for p,b in sorted(files.items())]},separators=(',',':')).encode()
def unique_object(pairs):
 d={}
 for k,v in pairs:
  if k in d:raise ValueError('DUPLICATE_JSON_FIELD')
  d[k]=v
 return d
def decode(raw):
 if len(raw)>ARCHIVE_LIMIT:raise ValueError('ARCHIVE_LIMIT')
 a=json.loads(raw,object_pairs_hook=unique_object)
 if set(a)!={'format','schemaVersion','dataSchema','foundationVersion','snapshotScope','files'}:raise ValueError('ARCHIVE_FIELDS')
 if a['format']!='CELE-DESKTOP-BACKUP' or type(a['schemaVersion'])!=int or a['schemaVersion']!=1 or a['dataSchema']!=1 or a['snapshotScope']!='native-committed-only':raise ValueError('UNSUPPORTED_ARCHIVE')
 if not isinstance(a['files'],list) or len(a['files'])>4096:raise ValueError('ENTRY_LIMIT')
 out={};total=0
 for e in a['files']:
  if set(e)!={'path','size','sha256','data'} or not safe_key(e['path']) or type(e['size'])!=int or not 0<=e['size']<=FILE_LIMIT or len(e['data'])>(FILE_LIMIT+2)//3*4:raise ValueError('INVALID_ENTRY')
  b=base64.b64decode(e['data'],validate=True);total+=len(b)
  if len(b)!=e['size'] or hashlib.sha256(b).hexdigest()!=e['sha256']:raise ValueError('HASH_MISMATCH')
  if total>TOTAL_LIMIT:raise ValueError('TOTAL_LIMIT')
  if e['path'] in out:raise ValueError('DUPLICATE_ENTRY')
  out[e['path']]=b
 validate(out);return out
class ReferenceStore:
 """Single-process test model. Native implementation additionally holds an OS lock."""
 def __init__(self,root):
  self.root=Path(root);self.root.mkdir(parents=True,exist_ok=True)
  if self.root.is_symlink():raise ValueError('SYMLINK')
  (self.root/'generations').mkdir(exist_ok=True)
  if not (self.root/'CURRENT').exists():self.commit({})
 def revision(self):
  p=self.root/'CURRENT'
  if p.is_symlink():raise ValueError('SYMLINK')
  s=p.read_text()
  if not re.fullmatch('[0-9a-f]{32}',s):raise ValueError('POINTER')
  return s
 def snapshot(self):
  p=self.root/'generations'/self.revision();out={}
  if p.is_symlink():raise ValueError('SYMLINK')
  for b in p.iterdir():
   if b.is_symlink() or b.name not in BUCKETS or not b.is_dir():raise ValueError('UNEXPECTED_DATA')
   for f in b.iterdir():
    if f.is_symlink() or not f.is_file() or f.stat().st_size>FILE_LIMIT:raise ValueError('INVALID_FILE')
    out[f'{b.name}/{f.name}']=f.read_bytes();validate(out)
  return out
 def commit(self,files,expected=None,fail_before_pointer=False):
  validate(files)
  if expected is not None and expected!=self.revision():raise ValueError('STALE_REVISION')
  ident=uuid.uuid4().hex;p=self.root/'generations'/ident;p.mkdir()
  for b in BUCKETS:(p/b).mkdir()
  for k,v in files.items():
   with (p/k).open('xb') as f:f.write(v);f.flush();os.fsync(f.fileno())
  if fail_before_pointer:raise OSError('SIMULATED_POWER_LOSS')
  fd,tmp=tempfile.mkstemp(dir=self.root)
  try:
   with os.fdopen(fd,'wb') as f:f.write(ident.encode());f.flush();os.fsync(f.fileno())
   os.replace(tmp,self.root/'CURRENT')
  finally:
   if os.path.exists(tmp):os.unlink(tmp)
  return ident
 def restore(self,raw):return self.commit(decode(raw),self.revision())
