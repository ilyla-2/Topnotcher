import sys,unittest,tempfile,json,base64,hashlib,shutil,os
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1];sys.path[:0]=[str(ROOT/'backup'),str(ROOT/'scripts')]
from reference import *
from release_tool import stage,inspect_payload,verify,clean
class BackupTests(unittest.TestCase):
 def setUp(self):self.temp=tempfile.TemporaryDirectory();self.s=ReferenceStore(Path(self.temp.name)/'data');self.files={'learner-state/browser-localstorage.json':b'{"cele_topnotcher_os_v01":"{\\"sessions\\":[]}"}','source-pdfs/demo.pdf':b'%PDF-1.4\nOriginal test-only bytes'}
 def tearDown(self):self.temp.cleanup()
 def test_roundtrip(self):self.assertEqual(decode(encode(self.files)),self.files)
 def test_valid_restore(self):self.s.restore(encode(self.files));self.assertEqual(self.s.snapshot(),self.files)
 def test_corruption_no_overwrite(self):
  old=self.s.revision();a=json.loads(encode(self.files));a['files'][0]['sha256']='0'*64
  with self.assertRaises(ValueError):self.s.restore(json.dumps(a).encode())
  self.assertEqual(self.s.revision(),old)
 def test_traversal(self):
  for p in ['../x','source-pdfs/../x','source-pdfs/a/b','source-pdfs/C:foo','source-pdfs/CON.pdf','source-pdfs/a.','source-pdfs/.x','source-pdfs/a\\b']:
   with self.subTest(path=p):self.assertFalse(safe_key(p))
 def test_case_collision(self):
  with self.assertRaises(ValueError):encode({'profile/A.json':b'{}','profile/a.json':b'{}'})
 def test_duplicate_archive_entry(self):
  a=json.loads(encode(self.files));a['files'].append(a['files'][0])
  with self.assertRaises(ValueError):decode(json.dumps(a).encode())
 def test_unsupported_schema(self):
  a=json.loads(encode(self.files));a['schemaVersion']=2
  with self.assertRaises(ValueError):decode(json.dumps(a).encode())
 def test_unlisted_field(self):
  a=json.loads(encode(self.files));a['extra']=1
  with self.assertRaises(ValueError):decode(json.dumps(a).encode())
 def test_bad_base64(self):
  a=json.loads(encode(self.files));a['files'][0]['data']='*invalid*'
  with self.assertRaises(ValueError):decode(json.dumps(a).encode())
 def test_declared_size(self):
  a=json.loads(encode(self.files));a['files'][0]['size']=FILE_LIMIT+1
  with self.assertRaises(ValueError):decode(json.dumps(a).encode())
 def test_power_loss_keeps_old_generation(self):
  old=self.s.revision()
  with self.assertRaises(OSError):self.s.commit(self.files,old,fail_before_pointer=True)
  self.assertEqual(self.s.revision(),old);self.assertEqual(self.s.snapshot(),{})
 def test_stale_revision(self):
  old=self.s.revision();self.s.commit(self.files,old)
  with self.assertRaises(ValueError):self.s.commit({},old)
 def test_rollback_generation_retained(self):
  old=self.s.revision();self.s.commit(self.files,old);self.assertTrue((self.s.root/'generations'/old).is_dir())
 def test_restart(self):self.s.commit(self.files);self.assertEqual(ReferenceStore(self.s.root).snapshot(),self.files)
 def test_symlink(self):
  f=self.s.root/'generations'/self.s.revision()/'profile/link.json'
  try:
   f.symlink_to(Path(self.temp.name)/'outside')
  except OSError as e:
   # Windows CI can deny symlink creation even when the application logic is correct.
   # Treat that runner capability as an explicit skip, never as a product PASS signal.
   if os.name=='nt' and getattr(e,'winerror',None)==1314:
    self.skipTest('Windows runner lacks symbolic-link creation privilege')
   raise
  with self.assertRaises(ValueError):self.s.snapshot()
class ReleaseTests(unittest.TestCase):
 def setUp(self):
  self.temp=tempfile.TemporaryDirectory();self.root=Path(self.temp.name);self.src=self.root/'source';self.src.mkdir();self.project=self.root/'project';self.project.mkdir();self.data=b'<!doctype html><title>Original empty test fixture</title>';(self.src/'index.html').write_bytes(self.data)
  self.m={'schemaVersion':1,'frontendVersion':'test','entry':'index.html','redistributionReview':'approved','cspReview':'approved','emptyBankQA':'approved','nativeAdapterQA':'approved','files':[{'path':'index.html','sha256':hashlib.sha256(self.data).hexdigest(),'reason':'Synthetic test fixture'}]};self.manifest=self.root/'m.json';self.write()
 def write(self):self.manifest.write_text(json.dumps(self.m))
 def tearDown(self):self.temp.cleanup()
 def test_stage_exact_bytes(self):stage(self.src,self.manifest,self.project);self.assertEqual((self.project/'app/payload/index.html').read_bytes(),self.data)
 def test_pending_review_blocked(self):
  self.m['emptyBankQA']='pending';self.write()
  with self.assertRaises(ValueError):stage(self.src,self.manifest,self.project)
 def test_certification_stage_allows_only_release_native_pending(self):
  self.m['redistributionReview']='pending';self.m['nativeAdapterQA']='pending';self.write();stage(self.src,self.manifest,self.project,certification=True);self.assertTrue((self.project/'app/payload/index.html').is_file())
 def test_hash_mismatch(self):
  (self.src/'index.html').write_text('changed')
  with self.assertRaises(ValueError):stage(self.src,self.manifest,self.project)
 def test_unlisted_private_file_not_copied(self):
  (self.src/'private.pdf').write_bytes(b'private');stage(self.src,self.manifest,self.project);self.assertFalse((self.project/'app/payload/private.pdf').exists())
 def test_embedded_bank_rejected(self):
  with self.assertRaises(ValueError):inspect_payload('index.html',b'const TRUSTED_V3141={questions:[]}')
 def test_pdf_rejected(self):
  with self.assertRaises(ValueError):inspect_payload('a.pdf',b'%PDF-1.4')
 def test_secret_rejected(self):
  with self.assertRaises(ValueError):inspect_payload('a.js',b'-----BEGIN PRIVATE KEY-----')
 def test_double_stage_refused(self):
  stage(self.src,self.manifest,self.project)
  with self.assertRaises(ValueError):stage(self.src,self.manifest,self.project)
 def test_clean_preserves_source(self):
  (self.project/'src-tauri/target').mkdir(parents=True);(self.project/'src-tauri/src').mkdir();(self.project/'src-tauri/src/keep.rs').write_text('keep');clean(self.project);self.assertTrue((self.project/'src-tauri/src/keep.rs').exists());self.assertFalse((self.project/'src-tauri/target').exists())
 def test_foundation_integrity(self):verify()
 def test_production_gate_blocks_missing_frontend(self):
  with self.assertRaises(AssertionError):verify(production=True)
if __name__=='__main__':unittest.main()
