import json,re,unittest,hashlib
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class NativeCertificationHarnessTests(unittest.TestCase):
 def test_foundation_version_and_gate_remain_pending_before_windows_evidence(self):
  pkg=json.loads((ROOT/'package.json').read_text())
  meta=json.loads((ROOT/'release/metadata.json').read_text())
  conf=json.loads((ROOT/'src-tauri/tauri.conf.json').read_text())
  self.assertEqual(pkg['version'],'0.3.3')
  self.assertEqual(meta['foundationVersion'],'0.3.3')
  self.assertEqual(conf['version'],'0.3.3')
  self.assertEqual(meta['nativeAdapterQA'],'pending')
  self.assertFalse(meta['nativeBuildValidated'])
 def test_certification_identity_is_isolated(self):
  prod=json.loads((ROOT/'src-tauri/tauri.conf.json').read_text())
  cert=json.loads((ROOT/'src-tauri/tauri.certification.conf.json').read_text())
  self.assertNotEqual(prod['identifier'],cert['identifier'])
  self.assertEqual(cert['identifier'],'local.cele.topnotcher.certification')
  self.assertEqual(cert['app']['windows'][0]['label'],'main')
 def test_windows_native_test_exercises_pdf_ocr_and_store(self):
  s=(ROOT/'src-tauri/tests/native_runtime_cert.rs').read_text()
  for token in ['RoInitialize','page_count_bytes','render_page','ocr_png','ocr-spatial-geometry','store-generation-retention','STALE_REVISION','backup-corruption-rejection','HASH_MISMATCH']:
   self.assertIn(token,s)
  self.assertIn('native-cert-two-page.pdf',s)
  self.assertIn('native-cert-ocr.png',s)
 def test_windows_runner_has_real_build_and_restart_gates(self):
  s=(ROOT/'scripts/windows-certify-v3211.ps1').read_text()
  for token in ['npm ci','cargo test','build --no-bundle','Start-Process','Stop-Process','restartLaunch','automatedNativeGatePassed','nativeAdapterQAEligibleForManualIPC','pending-manual-ipc']:
   self.assertIn(token,s)
  self.assertIn('local.cele.topnotcher.certification',s)
  self.assertIn("installerE2EValidated = $false",s)
  self.assertIn("signedInstallerValidated = $false",s)
  # Build success must be promoted in script scope, after Run-Step returns.
  self.assertRegex(s, r"Run-Step 'Build isolated Tauri release executable'[\s\S]*?\n  \$buildOk = \$true\n")
  build_block=s.split("Run-Step 'Build isolated Tauri release executable'",1)[1].split("$appExe = Find-AppExe",1)[0]
  self.assertNotIn("$buildOk = $true", build_block.split("}",1)[0])
 def test_fixture_hashes_are_fixed_and_pdf_has_two_pages_marker(self):
  expected={
   'native-cert-ocr.png':'d6265d23311c741c23eb9cd2c992f1254230ac872ff1989d27b1738c610f369f',
   'native-cert-two-page.pdf':'f2da9f346e5759428a5320d59c335f28a8cd5bf9ce44b85861a62b5743cdb927',
   'not-a-pdf.bin':'d6847430a1ab2313236ca06e928c7e8a90e2b859a09dbe9e7f37cd4626b8c5ee'
  }
  for name,h in expected.items():
   self.assertEqual(hashlib.sha256((ROOT/'tests/fixtures'/name).read_bytes()).hexdigest(),h)
 def test_frontend_manifest_is_still_v3210_and_compiler_frozen(self):
  m=json.loads((ROOT/'app_payload/v3_21_0.pending.json').read_text())
  self.assertEqual(m['frontendVersion'],'3.21.0')
  compiler=next(x for x in m['files'] if x['path']=='CELE_PDF_COMPILER_ENGINE_v1_6_1.js')
  self.assertEqual(compiler['sha256'],'3133e9ea5259afd12dfc8f2ba7b7cc3cdc8b4e2b089ad86bad40936e504d0ef5')
  self.assertEqual(m['nativeAdapterQA'],'pending')
 def test_winrt_feature_is_explicit(self):
  cargo=(ROOT/'src-tauri/Cargo.toml').read_text()
  self.assertIn('Win32_System_WinRT',cargo)

if __name__=='__main__': unittest.main()
