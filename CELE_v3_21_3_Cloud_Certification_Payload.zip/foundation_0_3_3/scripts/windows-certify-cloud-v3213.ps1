param(
  [string]$FrontendSource = "",
  [switch]$SkipInstallerBuild
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$KitRoot = Split-Path $Root -Parent
if ([string]::IsNullOrWhiteSpace($FrontendSource)) {
  $FrontendSource = Join-Path $KitRoot 'frontend_v3_21_0'
}
$FrontendSource = [System.IO.Path]::GetFullPath($FrontendSource)
$CertDir = Join-Path $Root 'release\native-certification'
$ArtifactDir = Join-Path $CertDir 'build-artifacts'
New-Item -ItemType Directory -Force -Path $CertDir,$ArtifactDir | Out-Null
$Transcript = Join-Path $CertDir 'cloud-windows-certification-transcript.txt'
$RuntimeReport = Join-Path $CertDir 'native-runtime-report.json'
$PortableLog = Join-Path $CertDir 'portable-regression-output.txt'
$PortableStatus = 'NOT_RUN'
$PortableExitCode = $null
$SummaryPath = Join-Path $CertDir 'cloud-windows-certification-summary.json'
$EnvPath = Join-Path $CertDir 'cloud-windows-environment.json'
$Manifest = Join-Path $Root 'app_payload\v3_21_0.pending.json'
$CertConfig = Join-Path $Root 'src-tauri\tauri.certification.conf.json'
$TauriCli = Join-Path $Root 'node_modules\@tauri-apps\cli\tauri.js'

function Require-Command([string]$Name) {
  $cmd = Get-Command $Name -ErrorAction SilentlyContinue
  if (-not $cmd) { throw "Required command is missing: $Name" }
  return $cmd.Source
}

function Run-Step([string]$Label, [scriptblock]$Action) {
  Write-Host "`n=== $Label ===" -ForegroundColor Cyan
  & $Action
}

function Sha256([string]$Path) {
  return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}

function Write-Utf8Json([string]$Path, $Value, [int]$Depth = 12) {
  $text = $Value | ConvertTo-Json -Depth $Depth
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($Path, $text + [Environment]::NewLine, $utf8NoBom)
}

function Find-AppExe {
  $candidates = @(
    (Join-Path $Root 'src-tauri\target\release\CELE-Topnotcher-OS-Certification.exe'),
    (Join-Path $Root 'src-tauri\target\release\CELE-Topnotcher-OS.exe'),
    (Join-Path $Root 'src-tauri\target\release\cele-topnotcher-desktop.exe')
  )
  foreach ($p in $candidates) { if (Test-Path -LiteralPath $p) { return $p } }
  $fallback = Get-ChildItem -LiteralPath (Join-Path $Root 'src-tauri\target\release') -Filter '*.exe' -File -ErrorAction SilentlyContinue |
    Where-Object { $_.DirectoryName -eq (Join-Path $Root 'src-tauri\target\release') } |
    Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
  if ($fallback) { return $fallback.FullName }
  throw 'Release executable was not found after Tauri build.'
}

if ($env:OS -ne 'Windows_NT') { throw 'v3.21.3 cloud certification must run on Windows.' }
if (-not [Environment]::Is64BitOperatingSystem) { throw 'Windows x64 is required for this certification pass.' }
if (-not (Test-Path -LiteralPath $FrontendSource -PathType Container)) { throw "Frontend source directory not found: $FrontendSource" }
if (-not (Test-Path -LiteralPath $Manifest -PathType Leaf)) { throw 'Pending v3.21.0 payload manifest is missing.' }

Start-Transcript -Path $Transcript -Force | Out-Null
$overallExit = 0
try {
  $node = Require-Command 'node'
  $npm = Require-Command 'npm'
  $python = Require-Command 'python'
  $cargo = Require-Command 'cargo'
  $rustc = Require-Command 'rustc'

  $os = Get-CimInstance Win32_OperatingSystem
  $envReport = [ordered]@{
    schemaVersion = 1
    phase = 'v3.21.3-cloud-windows-certification'
    timestampUtc = [DateTime]::UtcNow.ToString('o')
    githubActions = [bool]$env:GITHUB_ACTIONS
    runnerName = $env:RUNNER_NAME
    runnerImage = $env:ImageOS
    osCaption = $os.Caption
    osVersion = $os.Version
    osBuildNumber = $os.BuildNumber
    architecture = $env:PROCESSOR_ARCHITECTURE
    powershell = $PSVersionTable.PSVersion.ToString()
    node = (& $node --version | Out-String).Trim()
    npm = (& $npm --version | Out-String).Trim()
    rustc = (& $rustc -Vv | Out-String).Trim()
    cargo = (& $cargo --version | Out-String).Trim()
    frontendSourceShaManifest = (Sha256 $Manifest)
    certificationIdentifier = 'local.cele.topnotcher.certification'
    interactiveDesktopCertified = $false
    webView2IpcCertified = $false
  }
  Write-Utf8Json $EnvPath $envReport 8

  Run-Step 'Install exact Node/Tauri dependencies' {
    Push-Location $Root
    try { & $npm ci; if ($LASTEXITCODE -ne 0) { throw 'npm ci failed' } }
    finally { Pop-Location }
  }

  Run-Step 'Stage exact reviewed v3.21.0 frontend for cloud certification' {
    Push-Location $Root
    try {
      if (Test-Path -LiteralPath (Join-Path $Root 'app\payload')) {
        & $python scripts/release_tool.py clean-payload
        if ($LASTEXITCODE -ne 0) { throw 'clean-payload failed' }
      }
      & $python scripts/release_tool.py stage-certification --source $FrontendSource --manifest $Manifest
      if ($LASTEXITCODE -ne 0) { throw 'stage-certification failed' }
      & $python scripts/release_tool.py verify
      if ($LASTEXITCODE -ne 0) { throw 'foundation verification failed' }
    } finally { Pop-Location }
  }

  Run-Step 'Run portable/static regression suite' {
    Push-Location $Root
    try {
      $portableOutput = & $python -m unittest discover -s tests -v 2>&1
      $script:PortableExitCode = $LASTEXITCODE
      $portableText = ($portableOutput | ForEach-Object { $_.ToString() }) -join [Environment]::NewLine
      $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
      [System.IO.File]::WriteAllText($PortableLog, $portableText + [Environment]::NewLine, $utf8NoBom)
      $portableOutput | ForEach-Object { Write-Host $_ }
      if ($script:PortableExitCode -ne 0) {
        $script:PortableStatus = 'FAIL'
        throw "portable regression suite failed; see $PortableLog"
      }
      $script:PortableStatus = 'PASS'
    } finally { Pop-Location }
  }

  Run-Step 'Resolve and lock Rust dependencies' {
    Push-Location $Root
    try {
      if (-not (Test-Path -LiteralPath 'src-tauri\Cargo.lock')) {
        & $cargo generate-lockfile --manifest-path src-tauri/Cargo.toml
        if ($LASTEXITCODE -ne 0) { throw 'cargo generate-lockfile failed' }
      }
      $cargoMetadata = & $cargo metadata --manifest-path src-tauri/Cargo.toml --locked --format-version 1
      if ($LASTEXITCODE -ne 0) { throw 'cargo metadata failed' }
      $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
      [System.IO.File]::WriteAllText((Join-Path $CertDir 'cargo-metadata.json'), ($cargoMetadata -join [Environment]::NewLine) + [Environment]::NewLine, $utf8NoBom)
      Copy-Item -LiteralPath (Join-Path $Root 'src-tauri\Cargo.lock') -Destination (Join-Path $CertDir 'Cargo.lock') -Force
    } finally { Pop-Location }
  }

  $env:CELE_CERT_REPORT = $RuntimeReport
  Run-Step 'Compile Rust and execute Windows PDF/OCR/store runtime certificate' {
    Push-Location $Root
    try {
      & $cargo test --manifest-path src-tauri/Cargo.toml --locked --all-targets -- --nocapture
      if ($LASTEXITCODE -ne 0) { throw 'cargo test/native runtime certificate failed' }
    } finally { Pop-Location }
  }
  if (-not (Test-Path -LiteralPath $RuntimeReport)) { throw 'Native runtime report was not emitted.' }
  $native = Get-Content -Raw -LiteralPath $RuntimeReport | ConvertFrom-Json

  $buildOk = $false
  Run-Step 'Build isolated Tauri release executable (compile/link gate)' {
    Push-Location $Root
    try {
      & $node $TauriCli build --no-bundle --ci --config $CertConfig
      if ($LASTEXITCODE -ne 0) { throw 'Tauri release build failed' }
    } finally { Pop-Location }
  }
  $buildOk = $true

  $appExe = Find-AppExe
  Copy-Item -LiteralPath $appExe -Destination (Join-Path $ArtifactDir (Split-Path $appExe -Leaf)) -Force

  $installerBuilt = $false
  $installerPath = $null
  $installerSha = $null
  if (-not $SkipInstallerBuild) {
    Run-Step 'Build isolated NSIS certification installer' {
      Push-Location $Root
      try {
        & $node $TauriCli build --bundles nsis --ci --config $CertConfig
        if ($LASTEXITCODE -ne 0) { throw 'NSIS certification build failed' }
      } finally { Pop-Location }
    }
    $installer = Get-ChildItem -LiteralPath (Join-Path $Root 'src-tauri\target\release\bundle\nsis') -Filter '*.exe' -File -ErrorAction SilentlyContinue |
      Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
    if ($installer) {
      $installerBuilt = $true
      $installerPath = $installer.FullName
      $installerSha = Sha256 $installer.FullName
      Copy-Item -LiteralPath $installer.FullName -Destination (Join-Path $ArtifactDir $installer.Name) -Force
    }
  }

  $nativePass = ($native.status -eq 'PASS')
  $nativeBlocked = ($native.status -eq 'BLOCKED')
  $buildArtifactsOk = $buildOk -and ($SkipInstallerBuild -or $installerBuilt)
  $cloudStatus = if ($nativePass -and $buildArtifactsOk) { 'PASS' } elseif ($nativeBlocked -and $buildArtifactsOk) { 'BLOCKED' } else { 'FAIL' }

  $summary = [ordered]@{
    schemaVersion = 1
    phase = 'v3.21.3-cloud-windows-certification'
    timestampUtc = [DateTime]::UtcNow.ToString('o')
    frontendVersion = '3.21.0'
    foundationVersion = '0.3.3'
    portableRegressionStatus = $PortableStatus
    portableRegressionExitCode = $PortableExitCode
    nativeRuntimeStatus = $native.status
    nativeRuntimeReportSha256 = Sha256 $RuntimeReport
    cargoLockSha256 = Sha256 (Join-Path $Root 'src-tauri\Cargo.lock')
    tauriReleaseBuild = $buildOk
    executableSha256 = Sha256 $appExe
    nsisCertificationInstallerBuilt = $installerBuilt
    nsisCertificationInstallerSha256 = $installerSha
    cloudCertificationStatus = $cloudStatus
    cloudWindowsNativePrimitivesExecuted = $true
    interactiveExecutableLaunchValidated = $false
    webView2FrontendTauriIpcValidated = $false
    filePickerDialogsValidated = $false
    installerE2EValidated = $false
    displayScalingValidated = $false
    signedInstallerValidated = $false
    nativeAdapterQA = if ($cloudStatus -eq 'PASS') { 'pending-interactive-webview2-ipc' } else { 'pending' }
    nativeAdapterQAApproved = $false
    cloudRunnerLimitation = 'GitHub-hosted Windows certification is non-interactive. It cannot honestly approve WebView2 UI/IPC, native file dialogs, display scaling, or installed-app lifecycle.'
    remainingReleaseGates = @('interactive WebView2 -> Tauri IPC smoke', 'native file-picker/dialog smoke', 'installer install/upgrade/uninstall E2E', 'display scaling/manual UI checks', 'publisher identity and signing', 'redistribution review')
  }
  Write-Utf8Json $SummaryPath $summary 12

  if ($cloudStatus -eq 'PASS') {
    Write-Host "`nCLOUD WINDOWS GATE: PASS" -ForegroundColor Green
    Write-Host 'Native primitives and Windows build artifacts passed. nativeAdapterQA remains pending interactive WebView2/IPC certification.'
    $overallExit = 0
  } elseif ($cloudStatus -eq 'BLOCKED') {
    Write-Host "`nCLOUD WINDOWS GATE: BLOCKED BY RUNNER CAPABILITY" -ForegroundColor Yellow
    Write-Host 'Build completed, but the hosted Windows image could not exercise every native primitive (commonly OCR language availability). This is not adapter approval.'
    $overallExit = 31
  } else {
    Write-Host "`nCLOUD WINDOWS GATE: FAIL" -ForegroundColor Red
    $overallExit = 20
  }
} catch {
  $overallExit = 20
  $failure = [ordered]@{
    schemaVersion = 1
    phase = 'v3.21.3-cloud-windows-certification'
    timestampUtc = [DateTime]::UtcNow.ToString('o')
    cloudCertificationStatus = 'FAIL'
    portableRegressionStatus = $PortableStatus
    portableRegressionExitCode = $PortableExitCode
    portableRegressionLogPresent = (Test-Path -LiteralPath $PortableLog)
    error = $_.Exception.Message
    nativeAdapterQA = 'pending'
    nativeAdapterQAApproved = $false
  }
  Write-Utf8Json $SummaryPath $failure 8
  Write-Host "`nCLOUD CERTIFICATION FAILED: $($_.Exception.Message)" -ForegroundColor Red
} finally {
  Remove-Item Env:CELE_CERT_REPORT -ErrorAction SilentlyContinue
  Stop-Transcript | Out-Null
}
exit $overallExit
