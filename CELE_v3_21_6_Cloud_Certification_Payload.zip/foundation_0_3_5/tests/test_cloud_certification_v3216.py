import json, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class CloudCertificationHarnessTests(unittest.TestCase):
 def test_cloud_script_exists_and_never_claims_final_native_approval(self):
  s=(ROOT/'scripts/windows-certify-cloud-v3216.ps1').read_text()
  for token in ['cargo test','build --no-bundle','build --bundles nsis','cloudCertificationStatus','webView2FrontendTauriIpcValidated = $false','nativeAdapterQAApproved = $false','BLOCKED']:
   self.assertIn(token,s)
  self.assertNotIn('Start-Process',s)
  self.assertNotIn('Stop-Process',s)
 def test_cloud_script_preserves_frozen_frontend(self):
  s=(ROOT/'scripts/windows-certify-cloud-v3216.ps1').read_text()
  self.assertIn("v3_21_0.pending.json",s)
  self.assertIn('stage-certification --source',s)
  self.assertIn('foundation verification failed',s)
 def test_foundation_035_still_keeps_native_qa_pending_v3216(self):
  pkg=json.loads((ROOT/'package.json').read_text())
  meta=json.loads((ROOT/'release/metadata.json').read_text())
  self.assertEqual(pkg['version'],'0.3.5')
  self.assertEqual(meta['foundationVersion'],'0.3.5')
  self.assertEqual(meta['nativeAdapterQA'],'pending')
 def test_cloud_script_collects_reproducibility_evidence(self):
  s=(ROOT/'scripts/windows-certify-cloud-v3216.ps1').read_text()
  for token in ['Cargo.lock','cargo-metadata.json','nativeRuntimeReportSha256','executableSha256','nsisCertificationInstallerSha256','build-artifacts']:
   self.assertIn(token,s)
 def test_portable_failure_is_observable(self):
  s=(ROOT/'scripts/windows-certify-cloud-v3216.ps1').read_text()
  for token in ['portable-regression-output.txt','2>&1','portableRegressionStatus','portableRegressionExitCode']:
   self.assertIn(token,s)
 def test_windows_symlink_privilege_is_not_misclassified_as_product_failure(self):
  s=(ROOT/'tests/test_foundation.py').read_text()
  self.assertIn("winerror',None)==1314",s)
  self.assertIn('skipTest',s)

 def test_production_gate_regression_does_not_over_specify_exception_order(self):
  s=(ROOT/'tests/test_foundation.py').read_text()
  self.assertIn('assertRaises((AssertionError,ValueError))',s)
  self.assertIn('Any legitimate unapproved gate may block first',s)

 def test_windows_future_032_async_operations_use_join_not_removed_get(self):
  s=(ROOT/'src-tauri/src/pdf_ocr.rs').read_text()
  self.assertEqual(s.count('.get()'),0)
  self.assertEqual(s.count('.join()'),8)

 def test_cargo_compile_failures_are_persisted_in_evidence(self):
  s=(ROOT/'scripts/windows-certify-cloud-v3216.ps1').read_text()
  self.assertIn('cargo-test-output.txt',s)
  self.assertIn('$cargoExitCode',s)
  self.assertIn('2>&1',s)

 def test_page_count_bytes_closes_writer_before_winrt_reopen(self):
  s=(ROOT/'src-tauri/src/pdf_ocr.rs').read_text()
  start=s.index('pub fn page_count_bytes')
  end=s.index('pub fn render_page',start)
  body=s[start:end]
  self.assertIn('tempfile::tempdir()',body)
  self.assertIn('fs::write(&path,bytes)',body)
  self.assertIn('page_count(&path)',body)
  self.assertNotIn('temp_with(',body)

 def test_pdf_validation_fix_is_narrow_and_ocr_temp_path_unchanged(self):
  s=(ROOT/'src-tauri/src/pdf_ocr.rs').read_text()
  self.assertIn('let f=temp_with(bytes,".png","OCR_TEMP_FAILURE")?',s)
  self.assertIn('RenderWithOptionsToStreamAsync',s)
  self.assertIn('RecognizeAsync',s)

if __name__=='__main__': unittest.main()
