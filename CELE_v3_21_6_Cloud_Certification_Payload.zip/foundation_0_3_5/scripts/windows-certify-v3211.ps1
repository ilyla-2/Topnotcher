param(
  [string]$FrontendSource = "",
  [switch]$SkipInstallerBuild
)

$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest

$Root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$KitRoot = Split-Path $Root -Parent
if ([string]::IsNullOrWhiteSpace($FrontendSource)) {
  $FrontendSource = Join-Path $KitRoot 'frontend_v3_21_0'
}
$FrontendSource = [System.IO.Path]::GetFullPath($FrontendSource)
$CertDir = Join-Path $Root 'release\native-certification'
New-Item -ItemType Directory -Force -Path $CertDir | Out-Null
$Transcript = Join-Path $CertDir 'windows-certification-transcript.txt'
$RuntimeReport = Join-Path $CertDir 'native-runtime-report.json'
$SummaryPath = Join-Path $CertDir 'windows-certification-summary.json'
$EnvPath = Join-Path $CertDir 'windows-native-environment.json'
$Manifest = Join-Path $Root 'app_payload\v3_21_0.pending.json'
$CertConfig = Join-Path $Root 'src-tauri\tauri.certification.conf.json'
$TauriCli = Join-Path $Root 'node_modules\@tauri-apps\cli\tauri.js'

function Require-Command([string]$Name) {
  $cmd = Get-Command $Name -ErrorAction SilentlyContinue
  if (-not $cmd) { throw "Required command is missing: $Name" }
  return $cmd.Source
}

function Run-Step([string]$Label, [scriptblock]$Action) {
  Write-Host "`n=== $Label ===" -ForegroundColor Cyan
  & $Action
}

function Sha256([string]$Path) {
  return (Get-FileHash -Algorithm SHA256 -LiteralPath $Path).Hash.ToLowerInvariant()
}

function Write-Utf8Json([string]$Path, $Value, [int]$Depth = 10) {
  $text = $Value | ConvertTo-Json -Depth $Depth
  $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
  [System.IO.File]::WriteAllText($Path, $text + [Environment]::NewLine, $utf8NoBom)
}

function Find-AppExe {
  $candidates = @(
    (Join-Path $Root 'src-tauri\target\release\CELE-Topnotcher-OS-Certification.exe'),
    (Join-Path $Root 'src-tauri\target\release\CELE-Topnotcher-OS.exe'),
    (Join-Path $Root 'src-tauri\target\release\cele-topnotcher-desktop.exe')
  )
  foreach ($p in $candidates) { if (Test-Path -LiteralPath $p) { return $p } }
  $fallback = Get-ChildItem -LiteralPath (Join-Path $Root 'src-tauri\target\release') -Filter '*.exe' -File -ErrorAction SilentlyContinue |
    Where-Object { $_.DirectoryName -eq (Join-Path $Root 'src-tauri\target\release') } |
    Sort-Object LastWriteTimeUtc -Descending |
    Select-Object -First 1
  if ($fallback) { return $fallback.FullName }
  throw 'Release executable was not found after Tauri build.'
}

function Launch-Smoke([string]$Exe) {
  $result = [ordered]@{ firstLaunch = $false; forcedTermination = $false; restartLaunch = $false }
  $p1 = Start-Process -FilePath $Exe -PassThru
  Start-Sleep -Seconds 8
  $p1.Refresh()
  if ($p1.HasExited) { return $result }
  $result.firstLaunch = $true
  Stop-Process -Id $p1.Id -Force
  Start-Sleep -Seconds 2
  $result.forcedTermination = $true
  $p2 = Start-Process -FilePath $Exe -PassThru
  Start-Sleep -Seconds 8
  $p2.Refresh()
  if (-not $p2.HasExited) {
    $result.restartLaunch = $true
    Stop-Process -Id $p2.Id -Force
  }
  return $result
}

if ($env:OS -ne 'Windows_NT') { throw 'v3.21.1 native certification must run on Windows.' }
if (-not [Environment]::Is64BitOperatingSystem) { throw 'Windows x64 is required for this certification pass.' }
if (-not (Test-Path -LiteralPath $FrontendSource -PathType Container)) { throw "Frontend source directory not found: $FrontendSource" }
if (-not (Test-Path -LiteralPath $Manifest -PathType Leaf)) { throw 'Pending v3.21.0 payload manifest is missing.' }

Start-Transcript -Path $Transcript -Force | Out-Null
$overallExit = 0
try {
  $node = Require-Command 'node'
  $npm = Require-Command 'npm'
  $python = Require-Command 'python'
  $cargo = Require-Command 'cargo'
  $rustc = Require-Command 'rustc'

  $os = Get-CimInstance Win32_OperatingSystem
  $envReport = [ordered]@{
    schemaVersion = 1
    phase = 'v3.21.3-local-native-runtime-certification'
    timestampUtc = [DateTime]::UtcNow.ToString('o')
    osCaption = $os.Caption
    osVersion = $os.Version
    osBuildNumber = $os.BuildNumber
    architecture = $env:PROCESSOR_ARCHITECTURE
    powershell = $PSVersionTable.PSVersion.ToString()
    node = (& $node --version | Out-String).Trim()
    npm = (& $npm --version | Out-String).Trim()
    rustc = (& $rustc -Vv | Out-String).Trim()
    cargo = (& $cargo --version | Out-String).Trim()
    frontendSourceShaManifest = (Sha256 $Manifest)
    certificationIdentifier = 'local.cele.topnotcher.certification'
  }
  Write-Utf8Json $EnvPath $envReport 8

  Run-Step 'Install exact Node/Tauri dependencies' {
    Push-Location $Root
    try { & $npm ci; if ($LASTEXITCODE -ne 0) { throw 'npm ci failed' } }
    finally { Pop-Location }
  }

  Run-Step 'Stage exact reviewed v3.21.0 frontend for certification' {
    Push-Location $Root
    try {
      if (Test-Path -LiteralPath (Join-Path $Root 'app\payload')) {
        & $python scripts/release_tool.py clean-payload
        if ($LASTEXITCODE -ne 0) { throw 'clean-payload failed' }
      }
      & $python scripts/release_tool.py stage-certification --source $FrontendSource --manifest $Manifest
      if ($LASTEXITCODE -ne 0) { throw 'stage-certification failed' }
      & $python scripts/release_tool.py verify
      if ($LASTEXITCODE -ne 0) { throw 'foundation verification failed' }
    } finally { Pop-Location }
  }

  Run-Step 'Run portable/static regression suite' {
    Push-Location $Root
    try { & $python -m unittest discover -s tests -v; if ($LASTEXITCODE -ne 0) { throw 'portable regression suite failed' } }
    finally { Pop-Location }
  }

  Run-Step 'Resolve and lock Rust dependencies' {
    Push-Location $Root
    try {
      if (-not (Test-Path -LiteralPath 'src-tauri\Cargo.lock')) {
        & $cargo generate-lockfile --manifest-path src-tauri/Cargo.toml
        if ($LASTEXITCODE -ne 0) { throw 'cargo generate-lockfile failed' }
      }
      $cargoMetadata = & $cargo metadata --manifest-path src-tauri/Cargo.toml --locked --format-version 1
      if ($LASTEXITCODE -ne 0) { throw 'cargo metadata failed' }
      $utf8NoBom = New-Object System.Text.UTF8Encoding($false)
      [System.IO.File]::WriteAllText((Join-Path $CertDir 'cargo-metadata.json'), ($cargoMetadata -join [Environment]::NewLine) + [Environment]::NewLine, $utf8NoBom)
    } finally { Pop-Location }
  }

  $env:CELE_CERT_REPORT = $RuntimeReport
  Run-Step 'Compile Rust and execute Windows PDF/OCR/store runtime certificate' {
    Push-Location $Root
    try {
      & $cargo test --manifest-path src-tauri/Cargo.toml --locked --all-targets -- --nocapture
      if ($LASTEXITCODE -ne 0) { throw 'cargo test/native runtime certificate failed' }
    } finally { Pop-Location }
  }
  if (-not (Test-Path -LiteralPath $RuntimeReport)) { throw 'Native runtime report was not emitted.' }
  $native = Get-Content -Raw -LiteralPath $RuntimeReport | ConvertFrom-Json

  $buildOk = $false
  Run-Step 'Build isolated Tauri release executable' {
    Push-Location $Root
    try {
      & $node $TauriCli build --no-bundle --ci --config $CertConfig
      if ($LASTEXITCODE -ne 0) { throw 'Tauri release build failed' }
    } finally { Pop-Location }
  }
  $buildOk = $true

  $appExe = Find-AppExe
  $launch = Run-Step 'Launch, force-stop, and relaunch certification executable' { Launch-Smoke $appExe }
  $launchOk = $launch.firstLaunch -and $launch.forcedTermination -and $launch.restartLaunch

  $installerBuilt = $false
  $installerPath = $null
  $installerSha = $null
  if (-not $SkipInstallerBuild) {
    Run-Step 'Build isolated NSIS certification installer' {
      Push-Location $Root
      try {
        & $node $TauriCli build --bundles nsis --ci --config $CertConfig
        if ($LASTEXITCODE -ne 0) { throw 'NSIS certification build failed' }
      } finally { Pop-Location }
    }
    $installer = Get-ChildItem -LiteralPath (Join-Path $Root 'src-tauri\target\release\bundle\nsis') -Filter '*.exe' -File -ErrorAction SilentlyContinue |
      Sort-Object LastWriteTimeUtc -Descending | Select-Object -First 1
    if ($installer) {
      $installerBuilt = $true
      $installerPath = $installer.FullName
      $installerSha = Sha256 $installer.FullName
    }
  }

  $nativePass = ($native.status -eq 'PASS')
  $automatedGate = $nativePass -and $buildOk -and $launchOk
  $summary = [ordered]@{
    schemaVersion = 1
    phase = 'v3.21.3-local-native-runtime-certification'
    timestampUtc = [DateTime]::UtcNow.ToString('o')
    frontendVersion = '3.21.0'
    foundationVersion = '0.3.5'
    nativeRuntimeStatus = $native.status
    nativeRuntimeReportSha256 = Sha256 $RuntimeReport
    cargoLockSha256 = Sha256 (Join-Path $Root 'src-tauri\Cargo.lock')
    tauriReleaseBuild = $buildOk
    executableSha256 = Sha256 $appExe
    launchSmoke = $launch
    nsisCertificationInstallerBuilt = $installerBuilt
    nsisCertificationInstallerSha256 = $installerSha
    installerE2EValidated = $false
    signedInstallerValidated = $false
    automatedNativeGatePassed = $automatedGate
    nativeAdapterQAEligibleForManualIPC = $automatedGate
    nativeAdapterQA = if ($automatedGate) { 'pending-manual-ipc' } else { 'pending' }
    remainingReleaseGates = @('installer install/upgrade/uninstall E2E', 'display scaling/manual UI checks', 'publisher identity and signing', 'redistribution review')
  }
  Write-Utf8Json $SummaryPath $summary 10

  if ($automatedGate) {
    Write-Host "`nAUTOMATED NATIVE GATE: PASS" -ForegroundColor Green
    Write-Host "nativeAdapterQA remains PENDING until the real WebView2 -> Tauri IPC/UI smoke is completed."
    Write-Host "Evidence: $SummaryPath"
  } else {
    Write-Host "`nAUTOMATED NATIVE GATE: NOT PASSED" -ForegroundColor Yellow
    Write-Host "nativeAdapterQA remains PENDING."
    Write-Host "Evidence: $SummaryPath"
    $overallExit = 30
  }
} catch {
  $overallExit = 20
  $failure = [ordered]@{
    schemaVersion = 1
    phase = 'v3.21.3-local-native-runtime-certification'
    timestampUtc = [DateTime]::UtcNow.ToString('o')
    status = 'FAIL'
    error = $_.Exception.Message
    nativeAdapterQA = 'pending'
  }
  Write-Utf8Json $SummaryPath $failure 6
  Write-Host "`nCERTIFICATION FAILED: $($_.Exception.Message)" -ForegroundColor Red
} finally {
  Remove-Item Env:CELE_CERT_REPORT -ErrorAction SilentlyContinue
  Stop-Transcript | Out-Null
}
exit $overallExit
