import json, unittest
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]

class CloudCertificationHarnessTests(unittest.TestCase):
 def test_cloud_script_exists_and_never_claims_final_native_approval(self):
  s=(ROOT/'scripts/windows-certify-cloud-v3212.ps1').read_text()
  for token in ['cargo test','build --no-bundle','build --bundles nsis','cloudCertificationStatus','webView2FrontendTauriIpcValidated = $false','nativeAdapterQAApproved = $false','BLOCKED']:
   self.assertIn(token,s)
  self.assertNotIn('Start-Process',s)
  self.assertNotIn('Stop-Process',s)
 def test_cloud_script_preserves_frozen_frontend(self):
  s=(ROOT/'scripts/windows-certify-cloud-v3212.ps1').read_text()
  self.assertIn("v3_21_0.pending.json",s)
  self.assertIn('stage-certification --source',s)
  self.assertIn('foundation verification failed',s)
 def test_foundation_032_still_keeps_native_qa_pending(self):
  pkg=json.loads((ROOT/'package.json').read_text())
  meta=json.loads((ROOT/'release/metadata.json').read_text())
  self.assertEqual(pkg['version'],'0.3.2')
  self.assertEqual(meta['foundationVersion'],'0.3.2')
  self.assertEqual(meta['nativeAdapterQA'],'pending')
 def test_cloud_script_collects_reproducibility_evidence(self):
  s=(ROOT/'scripts/windows-certify-cloud-v3212.ps1').read_text()
  for token in ['Cargo.lock','cargo-metadata.json','nativeRuntimeReportSha256','executableSha256','nsisCertificationInstallerSha256','build-artifacts']:
   self.assertIn(token,s)

if __name__=='__main__': unittest.main()
