CELE Topnotcher OS v3.21.2 — Browser-Only GitHub Actions Certification
=====================================================================

This payload is designed for a restricted corporate computer. Nothing in this ZIP
needs to be installed or executed locally.

Upload the ZIP itself to the root of a private GitHub repository. Then create
.github/workflows/cele-native-certification.yml using the supplied workflow file.
Run the workflow from GitHub's Actions tab.

The workflow expands this payload only inside GitHub's disposable Windows runner.
It tests the frozen v3.21.0 frontend against Foundation 0.3.2, compiles and runs the
native Windows PDF/OCR/store certificate, builds the Tauri release executable and
NSIS certification installer, then uploads the machine-readable evidence.

A cloud PASS does NOT approve nativeAdapterQA. Interactive WebView2 -> Tauri IPC,
file dialogs, display scaling, installed-app lifecycle, and signing remain pending
until an unrestricted Windows desktop is available.

Frozen compiler SHA-256:
3133e9ea5259afd12dfc8f2ba7b7cc3cdc8b4e2b089ad86bad40936e504d0ef5
